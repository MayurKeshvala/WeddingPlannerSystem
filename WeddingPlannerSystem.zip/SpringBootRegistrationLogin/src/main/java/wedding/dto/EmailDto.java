package wedding.dto;

public class EmailDto {

	private Integer userID;

	private String email;

	public EmailDto() {
		
	}

	public EmailDto(Integer userID, String email) {
		
		this.userID = userID;
		
		this.email = email;
		
	}

	public Integer getUserID() {
		
		return userID;
		
	}

	public void setUserID(Integer userID) {
		
		this.userID = userID;
		
	}

	public String getEmail() {
		
		return email;
		
	}

	public void setEmail(String email) {
		
		this.email = email;
		
	}



}
