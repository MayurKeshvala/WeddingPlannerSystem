package wedding.dto;

import wedding.model.User;

public final class EntityToDtoConverter {

	private EntityToDtoConverter() {
		
	}

	public static EmailDto convertUserEntityToDto(final User user) {
		
		return new EmailDto(user.getUserID(), user.getEmail());
		
	}
	
}
