package wedding.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "order_details")
public class OrderDetail extends IdBasedEntity {
	private String productName;
	private int quantity;
	private float shippingCost;
	private Double unitPrice;
	private double subtotal;
	
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;
	
	@ManyToOne
	@JoinColumn(name = "order_id")
	private Order order;

	public int getQuantity() {
		
		return quantity;
		
	}

	public void setQuantity(int quantity) {
		
		this.quantity = quantity;
		
	}

	public float getShippingCost() {
		
		return shippingCost;
		
	}

	public void setShippingCost(float shippingCost) {
		
		this.shippingCost = shippingCost;
		
	}

	public Double getUnitPrice() {
		
		return unitPrice;
		
	}

	public void setUnitPrice(Double double1) {
		
		this.unitPrice = double1;
		
	}

	public double getSubtotal() {
		
		return subtotal;
		
	}

	public void setSubtotal(double d) {
		
		this.subtotal = d;
		
	}

	public Product getProduct() {
		
		return product;
		
	}

	public void setProduct(Product product) {
		
		this.product = product;
		
	}

	public Order getOrder() {
		
		return order;
		
	}

	public void setOrder(Order order) {
		
		this.order = order;
		
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	
}
