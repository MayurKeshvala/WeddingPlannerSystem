package wedding.model;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "notification")
public class Notification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Integer id;
	
	@Column
	private String headLine;
	
	@Column
	private String message;
	
	@Column
	private Date date;
	
	@OneToOne
	private User user_sender;
	
	@OneToOne
	private User user_contact;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
	  name = "user_notifications", 
	  joinColumns = {@JoinColumn(name = "notification_id")},  
	  inverseJoinColumns = {@JoinColumn(name = "user_ID")})
    private Set<User> user = new HashSet<>();

	
	@Column
	private boolean status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHeadLine() {
		return headLine;
	}

	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Set<User> getUser() {
		return user;
	}

	public void setUser(Set<User> user) {
		this.user = user;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public User getUser_sender() {
		return user_sender;
	}

	public void setUser_sender(User user_sender) {
		this.user_sender = user_sender;
	}

	public User getUser_contact() {
		return user_contact;
	}

	public void setUser_contact(User user_contact) {
		this.user_contact = user_contact;
	}




	
	
}
