package wedding.model;

import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "questions")
public class Question{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "question_id")
	private Integer questionId;
	
	private String questionHeader;
	
	@Column(nullable = true)
	private Date questionTime;
	
	private String questionText;
	
	private String questionResponse;
	
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	
    @OneToMany(mappedBy="question", cascade = CascadeType.REMOVE, orphanRemoval = true)
	private Set <Answer> answer;
	

	public String getQuestionHeader() {
		
		return questionHeader;
		
	}

	public void setQuestionHeader(String questionHeader) {
		
		this.questionHeader = questionHeader;
		
	}

	public String getQuestionText() {
		
		return questionText;
		
	}

	public void setQuestionText(String questionText) {
		
		this.questionText = questionText;
		
	}

	public String getQuestionResponse() {
		
		return questionResponse;
		
	}

	public void setQuestionResponse(String questionResponse) {
		
		this.questionResponse = questionResponse;
		
	}

	public Product getProduct() {
		
		return product;
		
	}

	public void setProduct(Product product) {
		
		this.product = product;
		
	}

	public User getUser() {
		
		return user;
		
	}

	public void setUser(User user) {
		
		this.user = user;
		
	}

	public Integer getQuestionId() {
		
		return questionId;
		
	}

	public void setQuestionId(Integer questionId) {
		
		this.questionId = questionId;
		
	}

	public Date getQuestionTime() {
		
		return questionTime;
		
	}

	public void setQuestionTime(Date questionTime) {
		
		this.questionTime = questionTime;
		
	}

	public Set<Answer> getAnswer() {
		
		return answer;
		
	}

	public void setAnswer(Set<Answer> answer) {
		
		this.answer = answer;
		
	}
	
}
