package wedding.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "answers")
public class Answer{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "answer_id")
	private Integer answerId;
	
	private String answer;
	
	private Date answerDate;
	
    @ManyToOne
    private Answer parentAnswer;

    @OneToMany(mappedBy = "parentAnswer", fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    private Set<Answer> subAnswer = new HashSet<>();
	
	@ManyToOne
	@JoinColumn(name = "question_id")
	private Question question;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	
	public String getAnswer() {
		
		return answer;
		
	}

	public void setAnswer(String answer) {
		
		this.answer = answer;
		
	}

	public Question getQuestion() {
		
		return question;
		
	}

	public void setQuestion(Question question) {
		
		this.question = question;
		
	}

	public User getUser() {
		
		return user;
		
	}

	public void setUser(User user) {
		
		this.user = user;
		
	}

	public Date getAnswerDate() {
		
		return answerDate;
		
	}

	public void setAnswerDate(Date answerDate) {
		
		this.answerDate = answerDate;
		
	}

	public Integer getAnswerId() {
		
		return answerId;
		
	}

	public void setAnswerId(Integer answerId) {
		
		this.answerId = answerId;
		
	}

	public Answer getParentAnswer() {
		
		return parentAnswer;
		
	}

	public void setParentAnswer(Answer parentAnswer) {
		
		this.parentAnswer = parentAnswer;
		
	}

	public Set<Answer> getSubAnswer() {
		
		return subAnswer;
		
	}

	public void setSubAnswer(Set<Answer> subAnswer) {
		
		this.subAnswer = subAnswer;
		
	}

}
