package wedding.model;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "users")
public class User extends AbstractAddress{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
	private Integer userID;
	
	@Column(name = "email", nullable = false, length = 45)
	private String email;
	
	private boolean checkNotification;
	
    @Column(name = "reset_password_token")
    private String resetPasswordToken;
	
	@Column(nullable = false, length = 64)
	private String Password;
	
	@Column(length = 64)
	private String photos;
	
	@ManyToMany(mappedBy = "respondee", fetch = FetchType.LAZY)
	private List<User> contacted;
	
	@ManyToMany
	@JoinTable(
			  name = "users_contacted", 
			  joinColumns = {@JoinColumn(name = "contact_id")},  
			  inverseJoinColumns = {@JoinColumn(name = "respondee_id")})
	private List<User> respondee;
	
	@Column
	private boolean helpRequired;
	
//	@ManyToMany(cascade = CascadeType.ALL)
//	@JoinTable(
//	  name = "user_notifications", 
//	  joinColumns = @JoinColumn(name = "user_id"), 
//	  inverseJoinColumns = @JoinColumn(name = "notification_id"))
//    Set<Notification> notifications = new HashSet<>();
	
    @ManyToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private Set<Notification> notification = new HashSet<>();
	
	@OneToOne
	private Suspension suspension;
	
	@Column(length = 64)
	private int noProduct;
	
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
            )
    
    private Set<Roles> roles = new HashSet<>();
    
    
    
    public boolean hasRole(String roleName) {
    	
        Iterator<Roles> iterator = this.roles.iterator();
        
        while (iterator.hasNext()) {
        	
            Roles role = iterator.next();
            
            if (role.getName().equals(roleName)) {
            	
                return true;
                
            }
            
        }
         
        return false;
        
    }
    
	public User() {
	}

	public User(Integer userID) {
		this.userID = userID;
	}
    
    public void addRole(Roles role) {
    	
        this.roles.add(role);
        
}

	public Integer getUserID() {
		
		return userID;
		
	}

	public void setUserID(Integer userID) {
		
		this.userID = userID;
		
	}

	public String getPassword() {
		
		return Password;
		
	}

	public void setPassword(String password) {
		
		Password = password;
		
	}

	public Set<Roles> getRoles() {
		
		return roles;
	
	}

	public void setRoles(Set<Roles> roles) {
		
		this.roles = roles;
		
	}

	public String getEmail() {
		
		return email;
		
	}

	public void setEmail(String email) {
		
		this.email = email;
		
	}
	
	
	
	public Set<Notification> getNotification() {
		return notification;
	}

	public void setNotification(Set<Notification> notification) {
		this.notification = notification;
	}



	private boolean enabled;

	public String getResetPasswordToken() {
		
		return resetPasswordToken;
		
	}

	
	
	public void setResetPasswordToken(String resetPasswordToken) {
		
		this.resetPasswordToken = resetPasswordToken;
		
	}

	public String getPhotos() {
		
		return photos;
		
	}

	public void setPhotos(String photos) {
		
		this.photos = photos;
		
	}
	
	
	
	public boolean isCheckNotification() {
		return checkNotification;
	}

	public void setCheckNotification(boolean checkNotification) {
		this.checkNotification = checkNotification;
	}

	public boolean isEnabled() {
		
		return enabled;
		
	}

	public void setEnabled(boolean enabled) {
		
		this.enabled = enabled;
		
	}

	@Transient
	public String getPhotosImagePath() {
		
		if (userID == null || photos == null) return "/images/default-user.png";
		
		return "/user-photos/" + this.userID + "/" + this.photos;

	}

	public int getNoProduct() {
		
		return noProduct;
		
	}

	








	public List<User> getContacted() {
		return contacted;
	}

	public void setContacted(List<User> contacted) {
		this.contacted = contacted;
	}

	public boolean isHelpRequired() {
		return helpRequired;
	}
	
	

	public List<User> getRespondee() {
		return respondee;
	}

	public void setRespondee(List<User> respondee) {
		this.respondee = respondee;
	}

	public void setHelpRequired(boolean helpRequired) {
		this.helpRequired = helpRequired;
	}

	public Suspension getSuspension() {
		return suspension;
	}

	public void setSuspension(Suspension suspension) {
		this.suspension = suspension;
	}

	public void setNoProduct(int noProduct) {
		
	}
	
	@Transient
	public String getFullName() {
		
		return firstName + " " + lastName;
		
	}

	@Override
	public String toString() {
		
		String addressFormat = firstName;
		
		if (lastName != null && !lastName.isEmpty()) addressFormat += " " + lastName;
		
		if (!addressLine.isEmpty()) addressFormat += ", " + addressLine;
		
		if (!city.isEmpty()) addressFormat += ", " + city;
		
		addressFormat += ", " + country;
		
		if (!postalCode.isEmpty()) addressFormat += ". Postal Code: " + postalCode;
		
		if (!phoneNumber.isEmpty()) addressFormat += ". Phone Number: " + phoneNumber;
		
		return addressFormat;
		
	}	
	
}
