package wedding.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;


public class GeoCoder {
	
    private Gson gson = new Gson();

    private volatile long lastRequest = 0L;

    public GeocodeResponse getLocation(String... allAddress) throws JsonSyntaxException, JsonIOException, MalformedURLException,
            IOException {
       
    	StringBuilder buildString = new StringBuilder();
        
    	for (String string : allAddress) {
        
    		if (buildString.length() > 0) {
            
    			buildString.append('+');

    		}
    
    		buildString.append(URLEncoder.encode(string.replace(' ', '+'), "UTF-8"));
        
    	}
        String url = "https://maps.googleapis.com/maps/api/geocode/json?sensor=false&address=" + buildString.toString() + "&key=AIzaSyDiw8v_-H-CnpgaN29SMbWJlesBPRdE2TY";
       
        
        synchronized (this) {
      
        	try {
            
        		long time = System.currentTimeMillis() - lastRequest;
                
        		if (time < 100) {
                
        			try {
                    
        				Thread.sleep(100 - time);
                    } catch (InterruptedException e) {
     
                    }
                
        		}
               
        		return gson.fromJson(new BufferedReader(new InputStreamReader(new URL(url).openStream())), GeocodeResponse.class);
            } finally {
               
            	lastRequest = System.currentTimeMillis();
            
            }
        
        }
    
    }

}
