package wedding.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "cart_items")
public class CartItem extends IdBasedEntity {
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne
	@JoinColumn(name = "product_id")	
	private Product product;
	
	private int quantity;
	
	private String date;
	
	@Transient
	private float shippingCost;
	
	public CartItem() {
		
	}


	public User getUser() {
		
		return user;
		
	}



	public void setUser(User user) {
		
		this.user = user;
		
	}



	public Product getProduct() {
		
		return product;
		
	}

	public void setProduct(Product product) {
		
		this.product = product;
		
	}

	public int getQuantity() {
		
		return quantity;
		
	}

	public void setQuantity(int quantity) {
		
		this.quantity = quantity;
		
	}

	@Override
	public String toString() {
		
		return "CartItem [id=" + id + ", customer=" + user.getFullName() + ", product=" + product.getShortName() + ", quantity=" + quantity
				+ "]";
	
	}

	@Transient
	public double getSubtotal() {
		
		return product.getPrice() * quantity;
		
	}

	@Transient
	public float getShippingCost() {
		
		return shippingCost;
		
	}

	public void setShippingCost(float shippingCost) {
		
		this.shippingCost = shippingCost;
		
	}


	public String getDate() {
		
		return date;
		
	}


	public void setDate(String date) {
		
		this.date = date;
		
	}
		
}
