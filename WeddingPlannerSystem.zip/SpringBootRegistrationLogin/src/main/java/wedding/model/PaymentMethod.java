package wedding.model;

public enum PaymentMethod {
	
	CREDIT_CARD, PAYPAL
	
}
