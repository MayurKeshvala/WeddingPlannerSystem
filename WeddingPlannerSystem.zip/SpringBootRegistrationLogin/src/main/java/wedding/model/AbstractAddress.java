package wedding.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractAddress{

	@Column(name = "first_name")
	protected String firstName;
	
	@Column(name = "last_name")
	protected String lastName;

	@Column(name = "DoB")
	private String dob;
	
	@Column(name = "Address")
	protected String addressLine;
	
	@Column(name = "city")
	protected String city;
	
	@Column(name = "phone_number")
	protected String phoneNumber;
	
	@Column(name = "postal_code")
	protected String postalCode;
    
	@Column(name = "country")
	protected String country;


	public String getFirstName() {
		
		return firstName;
		
	}

	public void setFirstName(String firstName) {
		
		this.firstName = firstName;
		
	}

	public String getLastName() {
		
		return lastName;
		
	}

	public void setLastName(String lastName) {
		
		this.lastName = lastName;
		
	}

	public String getDob() {
		
		return dob;
		
	}

	public void setDob(String dob) {
		
		this.dob = dob;
		
	}

	public String getAddressLine() {
		
		return addressLine;
		
	}

	public void setAddressLine(String addressLine) {
		
		this.addressLine = addressLine;
		
	}

	public String getCity() {
		
		return city;
		
	}

	public void setCity(String city) {
		
		this.city = city;
		
	}

	public String getPhoneNumber() {
		
		return phoneNumber;
		
	}

	public void setPhoneNumber(String phoneNumber) {
		
		this.phoneNumber = phoneNumber;
		
	}

	public String getPostalCode() {
		
		return postalCode;
		
	}

	public void setPostalCode(String postalCode) {
		
		this.postalCode = postalCode;
		
	}

	public String getCountry() {
		
		return country;
		
	}

	public void setCountry(String country) {
		
		this.country = country;
		
	}

	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
