package wedding.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;



@Entity
@Table(name = "orders")
public class Order extends AbstractAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
	private Integer orderID;
	
	private Date orderTime;
	
	private float shippingCost;
	
	private float subtotal;
	
	private float total;
	
	private int deliverDays;
	private Date deliverDate;
	
	@Enumerated(EnumType.STRING)
	private PaymentMethod paymentMethod;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
	private Set<OrderDetail> orderDetails = new HashSet<>();
	
	public String getCountry() {
		
		return country;
		
	}

	public void setCountry(String country) {
		
		this.country = country;
		
	}

	public Date getOrderTime() {
		
		return orderTime;
		
	}

	public void setOrderTime(Date orderTime) {
		
		this.orderTime = orderTime;
		
	}

	public float getShippingCost() {
		
		return shippingCost;
		
	}

	public void setShippingCost(float shippingCost) {
		
		this.shippingCost = shippingCost;
		
	}


	public float getSubtotal() {
		
		return subtotal;
		
	}

	public void setSubtotal(float subtotal) {
		
		this.subtotal = subtotal;
		
	}


	public float getTotal() {
		
		return total;
		
	}

	public void setTotal(float total) {
		
		this.total = total;
		
	}

	public int getDeliverDays() {
		
		return deliverDays;
		
	}

	public void setDeliverDays(int deliverDays) {
		
		this.deliverDays = deliverDays;
		
	}

	public Date getDeliverDate() {
		
		return deliverDate;
		
	}

	public void setDeliverDate(Date deliverDate) {
		
		this.deliverDate = deliverDate;
		
	}

	public PaymentMethod getPaymentMethod() {
		
		return paymentMethod;
		
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		
		this.paymentMethod = paymentMethod;
		
	}



	public User getuser() {
		
		return user;
		
	}

	public void setuser(User user) {
		
		this.user = user;
		
	}

	public Set<OrderDetail> getOrderDetails() {
		
		return orderDetails;
		
	}

	public void setOrderDetails(Set<OrderDetail> orderDetails) {
		
		this.orderDetails = orderDetails;
		
	}
	
	public void copyAddressFromuser() {
		
		setFirstName(user.getFirstName());
		
		setLastName(user.getLastName());
		
		setPhoneNumber(user.getPhoneNumber());
		
		setAddressLine(user.getAddressLine());;
		
		setCity(user.getCity());
		
		setCountry(user.getCountry());
		
		setPostalCode(user.getPostalCode());
		
	}

	@Override
	public String toString() {
		
		return "Order [id=" + orderID + ", subtotal=" + subtotal + ", paymentMethod=" + paymentMethod + 
				", user=" + user.getFullName() + "]";
	
	}

	public void copyShippingAddress(Address address) {
		
		setFirstName(address.getFirstName());
		
		setLastName(address.getLastName());
		
		setPhoneNumber(address.getPhoneNumber());
		
		setAddressLine(address.getAddressLine());
		
		setCountry(address.getCountry());
		
		setCity(address.getCity());
		
		setPostalCode(address.getPostalCode());
		
	}

	public Integer getOrderID() {
		
		return orderID;
		
	}

	public void setOrderID(Integer orderID) {
		
		this.orderID = orderID;
		
	}

	public User getUser() {
		
		return user;
		
	}

	public void setUser(User user) {
		
		this.user = user;
		
	}



	@Transient
	public String getShippingAddress() {
		String address = firstName;
		
		if (lastName != null && !lastName.isEmpty()) address += " " + lastName;
		
		if (!addressLine.isEmpty()) address += ", " + addressLine;
		
		
		if (!city.isEmpty()) address += ", " + city;
		
		
		address += ", " + country;
		
		if (!postalCode.isEmpty()) address += ". Postal Code: " + postalCode;
		
		if (!phoneNumber.isEmpty()) address += ". Phone Number: " + phoneNumber;
		
		return address;
	}	

	@Transient
	public String getProductNames() {
		
		String productNames = "";
		
		productNames = "<ul>";
		
		for (OrderDetail detail : orderDetails) {
			productNames += "<li>" + detail.getProduct().getShortName() + "</li>";			
		}
		
		productNames += "</ul>";
		
		return productNames;
		
	}	
	
}
