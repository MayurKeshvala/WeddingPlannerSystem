package wedding.model;

public enum SettingCategory {
	
	CURRENCY, MAIL_SERVER, MAIL_TEMPLATES,  PAYMENT, GENERAL
	
}
