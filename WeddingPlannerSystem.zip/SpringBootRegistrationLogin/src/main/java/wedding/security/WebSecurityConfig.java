package wedding.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import wedding.service.CustomUserDetailsService;
import wedding.utility.LoginSuccessHandler;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public UserDetailsService userDetailsService() {
		return new CustomUserDetailsService();
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService());
		authProvider.setPasswordEncoder(passwordEncoder());
		
		return authProvider;
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
	    web.ignoring().antMatchers("static/**");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.csrf() 
		.disable()
		.authorizeRequests()
		.antMatchers("/").permitAll() 
			.antMatchers("/register").permitAll()
			 .antMatchers("/addQuestions").hasAnyAuthority("User", "Admin")
			 .antMatchers("/editOptions").hasAnyAuthority("Admin")
			 .antMatchers("/editQuestions").hasAnyAuthority("Admin")
			 .antMatchers("/delete/{id}").hasAnyAuthority("Admin")
			 .antMatchers("/deleteOption/{id}").hasAnyAuthority("Admin")
			 .antMatchers("/edit/{id}").hasAnyAuthority("Admin")
			 .antMatchers("/pickOption/{id}").hasAnyAuthority("User", "Admin")
			 .antMatchers("/cart/remove/{productId}").hasAnyAuthority("Customer")
			 .anyRequest().permitAll()
			.and()
            .formLogin()
            .loginPage("/login")
            .usernameParameter("email")
            .successHandler(loginSuccessHandler)
            .permitAll()
			.and().logout().permitAll()
			.and()
				.rememberMe()
					.key("AbcDefgHijKlmnOpqrs_1234567890")
					.tokenValiditySeconds(7 * 24 * 60 * 60);
					;
			
	}
	
    private PersistentTokenRepository persistentTokenRepository() {
		// TODO Auto-generated method stub
		return null;
	}

	@Autowired 
    private LoginSuccessHandler loginSuccessHandler;
}	

