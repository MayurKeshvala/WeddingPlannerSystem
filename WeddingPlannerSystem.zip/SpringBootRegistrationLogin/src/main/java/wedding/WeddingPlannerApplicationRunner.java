package wedding;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import wedding.model.Address;
import wedding.model.Answer;
import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.Currency;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
//import wedding.model.Category;
import wedding.model.Roles;
import wedding.model.Sales;
import wedding.model.Setting;
import wedding.model.SettingCategory;
import wedding.model.ShippingRate;
import wedding.model.User;
import wedding.repo.AddressRepository;
import wedding.repo.AnswerRepository;
import wedding.repo.CartItemRepository;
import wedding.repo.CategoryRepository;
import wedding.repo.CurrencyRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.ReviewRepository;
//import wedding.repo.CategoryRepository;
import wedding.repo.RolesRepository;
import wedding.repo.SalesRepository;
import wedding.repo.SettingRepository;
import wedding.repo.ShippingRateRepository;
import wedding.repo.UserRepository;



@SpringBootApplication
public class WeddingPlannerApplicationRunner implements ApplicationRunner{
	
	@Autowired
	private UserRepository uRepo;
	
	@Autowired 
	private ProductRepository pRepo;
	
	@Autowired
	private RolesRepository rolesRepo;
	
	@Autowired
	private ReviewRepository revRepo;
	
	@Autowired
	private CategoryRepository cRepo;
	
	@Autowired
	private SalesRepository salesRepo;
	
	@Autowired
	private CurrencyRepository curRepo;
	
	@Autowired
	private AddressRepository adRepo;
	
	@Autowired
	private SettingRepository setRepo;
	
	@Autowired
	private ShippingRateRepository srRepo;
	
	@Autowired
	private QuestionRepository qRepo;
	
	@Autowired
	private CartItemRepository cartRepo;
	
	@Autowired
	private AnswerRepository aRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(WeddingPlannerApplicationRunner.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {

		
		BCryptPasswordEncoder passwordE = new BCryptPasswordEncoder();



        String user1Password = "Hello";



        String encodePassword = passwordE.encode(user1Password);


        Roles r1;
        r1 = new Roles();
        r1.setName("Admin");
        rolesRepo.save(r1);
        
        Roles r2;
        r2 = new Roles();
        r2.setName("Customer");
        rolesRepo.save(r2);
        
        Roles r3;
        r3 = new Roles();
        r3.setName("Supplier");
        rolesRepo.save(r3);
		
		User u1;
		u1 = new User();
		u1.setCity("Leicester");
		u1.setCountry("United Kingdom");
		u1.setDob("01/01/1998");
		u1.setPostalCode("LE5 7GY");
		u1.setLastName("Davidson");
		u1.addRole(r1);
		u1.setEnabled(true);
		u1.setPhoneNumber("07947264927");
		u1.setAddressLine("31 London Road");
		u1.setEmail("WeddingPlannerSystemUOL@gmail.com");
		u1.setPassword(encodePassword);
		u1.setFirstName("Yi");
		u1 = uRepo.save(u1);
	
		User u2;
		u2 = new User();
		u2.setCity("London");
		u2.setCountry("United Kingdom");
		u2.setDob("28/05/2000");
		u2.setPostalCode("LE3 9HO");
		u2.setLastName("Cat");
		u2.addRole(r3);
		u2.setEnabled(true);
		u2.setPhoneNumber("07395827482");
		u2.setAddressLine("12 Lakers Street");
		u2.setEmail("SupplierWeddingPlannerSystemUOL@gmail.com");
		u2.setPassword(encodePassword);
		u2.setFirstName("Doja");
		u2 = uRepo.save(u2);
		
		User u3;
		u3 = new User();
		u3.setCity("Milton Keynes");
		u3.setCountry("United Kingdom");
		u3.setDob("02/08/1997");
		u3.setPostalCode("LE5 7GY");
		u3.setLastName("Dark");
		u3.addRole(r2);
		u3.setEnabled(true);
		u3.setPhoneNumber("07938274839");
		u3.setAddressLine("62 Zoo Lane");
		u3.setEmail("CustomerWeddingPlannerSystemUOL@gmail.com");
		u3.setPassword(encodePassword);
		u3.setFirstName("Reyna");
		u3 = uRepo.save(u3);
		
		Setting set;
		set = new Setting();
		set.setValue("Ae_tgWIeSFQDqDyfdl7bi0oBiTZ-yd8NKXP5PE-VxXZ2UWc4rScCE49nk9Sxgg7II-ildiIYyIh4L2D7");
		set.setKey("PAYPAL_API_CLIENT_ID");
		set.setCategory(SettingCategory.PAYMENT);
		set = setRepo.save(set);
		
		Setting set2;
		set2 = new Setting();
		set2.setValue("EOvECy7iEkeEG9wPsmX2MvrGa71UeYkFLEatjACcqPWTxTi4xJAispUVvzxL2aoHlPlvBKGxwStyGto8");
		set2.setKey("PAYPAL_API_CLIENT_SECRET");
		set2.setCategory(SettingCategory.PAYMENT);
		set2 = setRepo.save(set2);
		
		Setting set3;
		set3 = new Setting();
		set3.setValue("https://api-m.sandbox.paypal.com");
		set3.setKey("PAYPAL_API_BASE_URL");
		set3.setCategory(SettingCategory.PAYMENT);
		set3 = setRepo.save(set3);
		
		Setting smtpServer = new Setting("MAIL_HOST", "smtp.gmail.com", SettingCategory.MAIL_SERVER);
		
		Setting portNumber = new Setting("MAIL_PORT", "587", SettingCategory.MAIL_SERVER);
		
		Setting emailUsername = new Setting("MAIL_USERNAME", "WeddingPlannerSystemUOL@gmail.com", SettingCategory.MAIL_SERVER);
		
		Setting emailPassword = new Setting("MAIL_PASSWORD", "Wedding123!", SettingCategory.MAIL_SERVER);
		
		Setting serverAuth = new Setting("SMTP_AUTH", "true", SettingCategory.MAIL_SERVER);
		
		Setting serverConnection = new Setting("SMTP_SECURED", "true", SettingCategory.MAIL_SERVER);
		
		Setting fromEmail = new Setting("MAIL_FROM", "WeddingPlannerSystemUOL@gmail.com", SettingCategory.MAIL_SERVER);
		
		Setting senderName = new Setting("MAIL_SENDER_NAME", "UoLWeddingPlanner", SettingCategory.MAIL_SERVER);

		setRepo.saveAll(List.of(smtpServer, portNumber, emailUsername, emailPassword, 
				serverAuth, serverConnection, fromEmail, senderName));
		
		
		Setting orderContent = new Setting("ORDER_CONFIRMATION_CONTENT", "Dear [[name]], you have made a recent purchase which cost [[total]], with [[paymentMethod]], at [[orderTime]]. Your purchase will arrive at [[shippingAddress]]. Thank you, very much, for shopping at UoLWeddingPlanner, we wish you a happy wedding! ", SettingCategory.MAIL_TEMPLATES);
		
		Setting supplierContent = new Setting("SUPPLIER_CONFIRMATION_CONTENT", "[[strQuantity]] sales of your [[name]] made a profit of [[subtotal]] at: [[orderTime]] ", SettingCategory.MAIL_TEMPLATES);
		
		Setting confirmEmail = new Setting("CUSTOMER_VERIFY_SUBJECT", "Welcome, [[name]], to WeddingPlannerSystem", SettingCategory.MAIL_TEMPLATES);Setting userRevokeContent = new Setting("USER_SUSPENSION_CONTENT", "Upon investigation, we have chosen to [[status]] your account. The reason for your suspension is/was: [[reason]].", SettingCategory.MAIL_TEMPLATES);
		
		Setting confirmContent = new Setting("CUSTOMER_VERIFY_CONTENT", "We are delighted that you, [[name]], are using our website to plan your memorable wedding. We provide a range of proudcts and services, provided by the most diverse and reliable suppliers, with integrity protected by our astute admins!", SettingCategory.MAIL_TEMPLATES);
		
		Setting orderEmail = new Setting("ORDER_CONFIRMATION_SUBJECT", "[[orderId]]: UoLWeddingPlanner Purchase", SettingCategory.MAIL_TEMPLATES);
		
		Setting supplierEmail = new Setting("SUPPLIER_CONFIRMATION_SUBJECT", "Successful sale of: [[name]]", SettingCategory.MAIL_TEMPLATES);
		
		Setting userRevokeEmail = new Setting("USER_SUSPENSION_SUBJECT", "Dear [[name]], your account status has been changed.", SettingCategory.MAIL_TEMPLATES);
		
		setRepo.saveAll(List.of(confirmEmail, confirmContent, orderEmail, userRevokeEmail, userRevokeContent, orderContent, supplierEmail, supplierContent));
		
		Currency cur;
		
		cur = new Currency();
		cur.setName("Pound");
		cur.setSymbol("£");
		cur.setCode("GBP");
		cur = curRepo.save(cur);
		
		Setting symbolPosition = new Setting("CURRENCY_SYMBOL_POSITION", "before", SettingCategory.CURRENCY);
		
		Setting decimalPointType = new Setting("DECIMAL_POINT_TYPE", "POINT", SettingCategory.CURRENCY);
		
		Setting thousandsPointType = new Setting("THOUSANDS_POINT_TYPE", "COMMA", SettingCategory.CURRENCY);
		
		Setting currencyId = new Setting("CURRENCY_ID", "1", SettingCategory.CURRENCY);
		
		Setting symbol = new Setting("CURRENCY_SYMBOL", "£", SettingCategory.CURRENCY);
		
		Setting decimalDigits = new Setting("DECIMAL_DIGITS", "2", SettingCategory.CURRENCY);
		
		
		setRepo.saveAll(List.of(currencyId, symbol, symbolPosition, decimalPointType, 
				decimalDigits, thousandsPointType));

		
		ShippingRate sR;
		sR = new ShippingRate();
		sR.setRate((float) 8.95);
		sR.setDays(7);
		sR.setWeight(4.40925);
		sR.setCodSupported(true);
		sR = srRepo.save(sR);
		
		ShippingRate sR2;
		sR2 = new ShippingRate();
		sR2.setRate((float) 11.95);
		sR2.setDays(7);
		sR2.setWeight(44.0925);
		sR2.setCodSupported(true);
		sR2 = srRepo.save(sR2);
		
		ShippingRate sR3;
		sR3 = new ShippingRate();
		sR3.setRate((float) 14.95);
		sR3.setDays(7);
		sR3.setWeight(66.1387);
		sR3.setCodSupported(true);
		sR3 = srRepo.save(sR3);
		
		Category c1;
		c1 = new Category();
		c1.setName("Flowers");
		c1.setEnabled(true);
		c1.setPhotos(null);
		c1 = cRepo.save(c1);

		Category c2;
		c2 = new Category();
		c2.setName("Venues");
		c2.setService(true);
		c2.setEnabled(true);
		c2.setPhotos(null);
		c2 = cRepo.save(c2);
		
		Product p1;
		p1 = new Product();
		p1.setName("Purple Lily");
		p1.setDimWeight(7.19f);
		p1.setPrice(10.00);
		p1.setInStock(true);
		p1.setShortDescription("Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. Lilies are a group of flowering plants which are important in culture and literature in much of the world. Most species are native to the northern hemisphere and their range is temperate climates and extends into the subtropics. Many other plants have \"lily\" in their common names, but do not belong to the same genus and are therefore not true lilies.");
		p1.setFullDescription("Lilies are tall perennials ranging in height from 2–6 ft (60–180 cm). They form naked or tunicless scaly underground bulbs which are their organs of perennation. In some North American species the base of the bulb develops into rhizomes, on which numerous small bulbs are found. Some species develop stolons. Most bulbs are buried deep in the ground, but a few species form bulbs near the soil surface. Many species form stem-roots. With these, the bulb grows naturally at some depth in the soil, and each year the new stem puts out adventitious roots above the bulb as it emerges from the soil. These roots are in addition to the basal roots that develop at the base of the bulb.\n"
				+ "\n"
				+ "\n"
				+ "Lily, petal\n"
				+ "The flowers are large, often fragrant, and come in a wide range of colors including whites, yellows, oranges, pinks, reds and purples. Markings include spots and brush strokes. The plants are late spring- or summer-flowering. Flowers are borne in racemes or umbels at the tip of the stem, with six tepals spreading or reflexed, to give flowers varying from funnel shape to a \"Turk's cap\". The tepals are free from each other, and bear a nectary at the base of each flower. The ovary is 'superior', borne above the point of attachment of the anthers. The fruit is a three-celled capsule.[3]\n"
				+ "\n"
				+ "\n"
				+ "stamen of lilium\n"
				+ "Seeds ripen in late summer. They exhibit varying and sometimes complex germination patterns, many adapted to cool temperate climates.\n"
				+ "\n"
				+ "Most cool temperate species are deciduous and dormant in winter in their native environment. But a few species native to areas with hot summers and mild winters (Lilium candidum, Lilium catesbaei, Lilium longiflorum) lose their leaves and enter a short dormant period in summer or autumn, sprout from autumn to winter, forming dwarf stems bearing a basal rosette of leaves until, after they have received sufficient chilling, the stem begins to elongate in warming weather.");
p1.setCategory(c1);	
p1.setHeight(10);
p1.setWeight(3);
p1.setLength(10);
p1.setWidth(10);
p1.setEnabled(true);
p1.setQuantity(40);
p1.setUser(u2);
p1.addDetail("Colour", "Purple");
p1.addDetail("Type", "Lily");
p1.addDetail("Size", "Large");
p1.addDetail("Quantity per vase", "10");
p1.setAverageRating(5);
p1.addExtraImage("Flower.png");
p1.setMainImage("Lily.png");
p1.setShippingrate(sR2);
p1 = pRepo.save(p1);

Question q1;
q1 = new Question();
q1.setQuestionHeader("Flower and Colours");
q1.setQuestionText("Are the flowers real or artificial? If it is real, how long does it live and does it require any special treatment? Also, does the case come in any other colours?");
q1.setQuestionTime(new Date());
q1.setProduct(p1);
q1.setUser(u1);
q1 = qRepo.save(q1);


Answer a2;
a2 = new Answer();
a2.setAnswerDate(new Date());
a2.setAnswer("Thank you, the flowers look amazing!");
a2.setUser(u1);

a2.setQuestion(null);
a2.setSubAnswer(null);
a2 = aRepo.save(a2);

Answer a1;
a1 = new Answer();
a1.setAnswerDate(new Date());
a1.setAnswer("The flowers are artificial, so they will never die or require special treatment. At the moment, the vase comes in cream, however we will expand in the future.");
a1.setUser(u2);
a1.setQuestion(q1);
Set<Answer> subAnswer = new HashSet<>();
subAnswer.add(a2);
a1.setSubAnswer(subAnswer);
a1 = aRepo.save(a1);

a2.setParentAnswer(a1);
a2 = aRepo.save(a2);

for(Answer a : a1.getSubAnswer()) {
System.out.println(a.getAnswer());	
}



Product p2;
p2 = new Product();
p2.setName("Nelumbo Nucifera");
p2.setPrice(20.30);
p2.setInStock(true);
p2.setShortDescription("The lotus is often confused with the true water lilies of genus Nymphaea, in particular N. caerulea, the \"blue lotus\". In fact, several older systems, such as the Bentham & Hooker system (which is widely used in the Indian subcontinent) refer to the lotus by its old synonym of Nymphaea nelumbo.[citation needed]");
p2.setFullDescription("Nelumbo nucifera, also known as Indian lotus, sacred lotus,[1] or simply lotus, is one of two extant species of aquatic plant in the family Nelumbonaceae. It is sometimes colloquially called a water lily, though this more often refers to members of the family Nymphaeaceae.[2]\n"
		+ "\n"
		+ "Lotus plants are adapted to grow in the flood plains of slow-moving rivers and delta areas. Stands of lotus drop hundreds of thousands of seeds every year to the bottom of the pond. While some sprout immediately, and most are eaten by wildlife, the remaining seeds can remain dormant for an extensive period of time as the pond silts in and dries out. During flood conditions, sediments containing these seeds are broken open, and the dormant seeds rehydrate and begin a new lotus colony.\n"
		+ "\n"
		+ "Under favorable circumstances, the seeds of this aquatic perennial may remain viable for many years, with the oldest recorded lotus germination being from seeds 1,300 years old recovered from a dry lakebed in northeastern China.[3] Therefore, the Chinese regard the plant as a symbol of longevity.\n"
		+ "\n"
		+ "It has a very wide native distribution, ranging from central and northern India (at altitudes up to 1,400 m or 4,600 ft in the southern Himalayas[4]), through northern Indochina and East Asia (north to the Amur region; the Russian populations have sometimes been referred to as \"Nelumbo komarovii\"), with isolated locations at the Caspian Sea.[5] Today the species also occurs in southern India, Sri Lanka, virtually all of Southeast Asia, New Guinea and northern and eastern Australia, but this is probably the result of human translocations.[5] It has a very long history (c. 3,000 years) of being cultivated for its edible seeds,[5] and it is commonly cultivated in water gardens.[4] It is the national flower of India and Vietnam.");
p2.setCategory(c1);	
p2.setHeight(10);
p2.setWeight(3);
p2.setQuantity(10);
p2.setLength(10);
p2.setWidth(10);
p2.setEnabled(true);
p2.setShippingrate(sR);
p2.setUser(u2);
p2.addDetail("Colour", "Pink");
p2.addDetail("Type", "Lotus");
p2.addDetail("Size", "Medium");
p2.addDetail("Quantity per vase", "5");
p2.setAverageRating(3.5);
p2.addExtraImage("Lotus_smaller.jpg");
p2.setMainImage("Lotus.jpg");
p2 = pRepo.save(p2);

	
Product p3;
p3 = new Product();
p3.setName("Floral Wedding");
p3.setPrice(6000.00);
p3.setInStock(true);
p3.setAddress("Leicester");
p3.setShortDescription("An exclusive use venue in a beautiful setting, located in its own 360 acre valley of rolling Warwickshire countryside, farmland, woodland and landscaped grounds. With just one wedding per day you can relax and enjoy the day.\n"
		+ "The barn style venue can accommodate up to 150 guests throughout your day (& eve) but is also ideal for smaller weddings with less than 50 guests. The venue is licensed for indoor or outdoor weddings so you can choose a location to suit yourselves.");
p3.setFullDescription("You want the wedding of your dreams without compromise. A ceremony expressing the heart. Food which is delicious and tempts seconds. Styling where guests go wow. A room which allows you to celebrate.\n"
		+ "\n"
		+ "At Warwickshire Weddings we want to capture your dream and remove the stress so you can truly enjoy the day with your guests and family.\n"
		+ "\n"
		+ "We don’t want you to wait for information, to compromise your dream, to apologise to family and friends for the quality of ceremony music or the food not being delicious.\n"
		+ "\n"
		+ "You need one partner who can work with you to bring your dream to life and have everyone talking about the amazing wedding you planned and dreamed of.\n"
		+ "\n"
		+ "At Tailrace we are passionate about creating beautiful, stress free events. We’ve done over 400 weddings and know that planning a wedding doesn’t have to be a stressful experience.\n"
		+ "\n"
		+ "Sharon and Nicole are here to help guide you through the process and help you figure out what you want your wedding day to be.");
p3.setCategory(c2);	
p3.setEnabled(true);
p3.setService(true);
List<String> Dates = new ArrayList<String>();
Dates.add("2022-02-08");
Dates.add("2022-03-28");
Dates.add("2022-03-15");
Dates.add("2022-05-19");
p3.setDate(Dates);
p3.setUser(u2);
p3.addDetail("Venue size", "150");
p3.addDetail("Type", "Floral");
p3.addDetail("Location", "Warwickshire");
p3.addDetail("Food service", "Provided");
p3.addDetail("Furniture", "Provided");
p3.addDetail("White Linens", "Provided");
p3.addDetail("Contact email", "WarwickshireWedding@hotmail.co.uk");
p3.addDetail("Contact phone number", "07394820495");
p3.setAverageRating(3.5);
p3.setMainImage("outside_venue.jpeg");
p3.addExtraImage("inside_venue.jpg");
p3.addExtraImage("garden_venue.webp");
p3 = pRepo.save(p3);

Product p4;
p4 = new Product();
p4.setName("Beach Wedding");
p4.setPrice(6000.00);
p4.setInStock(true);
p4.setAddress("Cornwall");
p4.setShortDescription("Beach weddings are alluring for more reasons than one; and being out in the open, in a romantic oceanfront setting while the wind and waves sing their praises over your union, is one of those. They are far from the typical traditional wedding, which is often hosted within a church, or another elaborate indoor setting. That is not to say there aren’t other outdoor wedding types that aren’t appealing, like the garden wedding for example, but beach weddings are definitely in a category of their own.");
p4.setFullDescription("There are a few things you’ll need to find out before walking down the aisle at your beach wedding. Many people overlook the accessibility factor once they’ve found and fallen in love with a beach wedding location. Don’t forget to think about your guests’ convenience, and how easy or difficult it is going to be to make it to the location, from a main road. This can also affect the ease of setting up and transporting chairs, tables, and even food delivery. Make sure your site isn’t too out of the way, and if it is, ensure you make the right preparations.");
p4.setCategory(c2);	
p4.setEnabled(true);
p4.setService(true);
List<String> Dates2 = new ArrayList<String>();
Dates2.add("2022-05-22");
Dates2.add("2022-07-26");
Dates2.add("2022-08-14");
p4.setDate(Dates2);
p4.setUser(u2);
p4.addDetail("Venue size", "500");
p4.addDetail("Type", "Beach");
p4.addDetail("Location", "Cornwall");
p4.addDetail("Catering service", "Provided");
p4.addDetail("Furniture", "Provided");
p4.addDetail("Bar", "Provided");
p4.addDetail("Contact email", "CornwallWedding@hotmail.co.uk");
p4.addDetail("Contact phone number", "07938475628");
p4.setAverageRating(5);
p4.setMainImage("beach_bride.jpg");
p4.addExtraImage("bar.jpg");
p4.addExtraImage("ocean.jpg");
p4.addExtraImage("wide-view.jpg");
p4 = pRepo.save(p4);

Sales sa1;
sa1 = new Sales();
sa1.setLastSold(new Date());
sa1.setProduct(p1);
sa1.setTotalSales(35);
sa1.setTotalProfit(160.00);
sa1.setUser(u2);
sa1 = salesRepo.save(sa1);


Sales sa2;
sa2 = new Sales();
sa2.setLastSold(new Date());
sa2.setProduct(p2);
sa2.setTotalSales(15);
sa2.setTotalProfit(50.00);
sa2.setUser(u2);
sa2 = salesRepo.save(sa2);

Sales sa3;
sa3 = new Sales();
sa3.setLastSold(new Date());
sa3.setProduct(p2);
sa3.setTotalSales(50);
sa3.setTotalProfit(200.00);
sa3.setUser(u2);
sa3 = salesRepo.save(sa3);

Sales sa4;
sa4 = new Sales();
sa4.setLastSold(new Date());
sa4.setProduct(p3);
sa4.setTotalSales(1);
sa4.setTotalProfit(6000.00);
sa4.setUser(u2);
sa4 = salesRepo.save(sa4);

CartItem ca1;
ca1 = new CartItem();
ca1.setProduct(p1);
ca1.setUser(u2);
ca1.setQuantity(1);
ca1 = cartRepo.save(ca1);

Address ad1;
ad1 = new Address();
ad1.setPostalCode("LE7 8YH");
ad1.setCountry("England");
ad1.setPhoneNumber("0792857438");
ad1.setCity("Leicester");
ad1.setFirstName("Tanner");
ad1.setLastName("Ink");
ad1.setAddressLine("42 Ice Street");
ad1.setDob("01/02/22");
ad1.setDefaultForShipping(true);
ad1.setUser(u1);
ad1 = adRepo.save(ad1);

Review rev1;
rev1 = new Review();
rev1.setComment("I love the flowers!");
rev1.setHeadline("Beautiful!<3");
rev1.setRating(5);
rev1.setReviewTime(new Date());
rev1.setProduct(p1);
rev1.setUser(u1);
rev1 = revRepo.save(rev1);
	
	}
	

	
}
