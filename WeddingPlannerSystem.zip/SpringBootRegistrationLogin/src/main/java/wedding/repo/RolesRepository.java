package wedding.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import wedding.model.Roles;

public interface RolesRepository extends JpaRepository<Roles, Integer> {
	
	@Query("SELECT r FROM Roles r WHERE r.name = ?1")
	public Roles findByName(String name);
	
	@Query("SELECT r.id FROM Roles r WHERE r.name = ?1")
	public String findIdByName(String name);
	
}
