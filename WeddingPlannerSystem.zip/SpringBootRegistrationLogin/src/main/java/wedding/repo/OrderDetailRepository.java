package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import wedding.model.Order;
import wedding.model.OrderDetail;



public interface OrderDetailRepository extends JpaRepository<OrderDetail, Integer> {
	
	@Query("SELECT COUNT(d) FROM OrderDetail d WHERE d.product.id = ?1 AND d.order.user.id = ?2")
	public Long countByProductAndCustomerAndOrderStatus(Integer productId, Integer customerId);

	@Query("SELECT d FROM OrderDetail d WHERE d.product.id = ?1")
	public List<OrderDetail> findAllOrderDetailByProduct(Integer id);
	



}
