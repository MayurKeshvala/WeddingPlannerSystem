package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import wedding.model.Order;
import wedding.model.OrderDetail;
import wedding.model.User;



public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	@Query("SELECT o FROM Order o WHERE o.user.userID = ?1")
	public Page<Order> findAll(Integer userId, Pageable pageable);
	
	@Query("SELECT o FROM Order o WHERE o.user.userID = ?1")
	public List<Order> findAllOrderByUserId(Integer id);
	
	public Order findByOrderIDAndUser(Integer order_id, User user);
		
	@Query("SELECT DISTINCT o FROM Order o JOIN o.orderDetails od JOIN od.product p "+ "WHERE o.user.userID = ?2 "+ "AND (p.name LIKE %?1%)")
	public Page<Order> findAll(String keyWord, Integer userId, Pageable pageable);

}
