package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;



public interface QuestionRepository extends JpaRepository<Question, Integer> {

	public Page<Question> findByProduct(Product product, Pageable pageable);

    @Modifying
    @Query("DELETE Question q WHERE q.questionId = ?1")
    void deleteByIdWithJPQL(int id);
	
    @Query("SELECT q FROM Question q WHERE q.questionId = ?1")
    public Question findQuestionById(Integer id);
    
	@Query("SELECT q FROM Question q WHERE q.user.userID = ?1")
	public Page<Question> findByuser(Integer userId, Pageable pageable);
	
	@Query("SELECT q FROM Question q WHERE q.user.userID = ?1 AND ("
			+ "q.questionHeader LIKE %?2% OR q.questionText LIKE %?2% OR q.product.name LIKE %?2%)")
	public Page<Question> findByuser(Integer userId, String keyword, Pageable pageable);
	
	@Query("SELECT COUNT(q) FROM Question q WHERE q.product.id = ?1")
	public long countAllQuestionsById(Integer productId);
	
	   @Query("SELECT q FROM Question q WHERE q.product.id = ?1")
		public List<Question> findAllQuestionByProductId(Integer id);

	   @Query("SELECT q FROM Question q WHERE q.user.userID = ?1")
		public List<Question> findAllQuestionByUserId(Integer id);
}
