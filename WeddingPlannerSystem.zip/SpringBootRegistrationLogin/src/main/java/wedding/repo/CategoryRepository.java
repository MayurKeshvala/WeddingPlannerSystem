package wedding.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import wedding.model.Category;
import wedding.model.Product;

public interface CategoryRepository extends PagingAndSortingRepository<Category, Integer> {

	@Query("SELECT c FROM Category c WHERE c.id  = ?1")
	public Category findCategoryById(Integer id);
	
	@Query("SELECT c FROM Category c WHERE CONCAT(c.id, ' ', c.name) LIKE %?1%")
	public Page<Category> findAll(String keyword, Pageable pageable);
	
	@Query("SELECT c FROM Category c WHERE c.enabled = true")
	public List<Category> findAllEnabled();
		
	@Query("UPDATE Category c SET c.enabled = ?2 WHERE c.id = ?1")
	@Modifying
	public void updateEnabledStatus(Integer id, boolean enabled);

	@Query("SELECT c FROM Category c WHERE c.service  = true")
	public List<Category> findAllByService();
	
	@Query("SELECT c FROM Category c WHERE c.service  = false")
	public List<Category> findAllByProduct();

	@Query("SELECT c FROM Category c WHERE c.id  = ?1")
	public List<Category> findAllCategory(Integer id);

}
