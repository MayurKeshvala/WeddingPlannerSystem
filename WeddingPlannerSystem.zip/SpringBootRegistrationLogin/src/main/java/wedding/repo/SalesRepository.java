package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import wedding.model.Product;
import wedding.model.Sales;
import wedding.model.Sales;

public interface SalesRepository extends JpaRepository<Sales, Integer> {

    @Query("SELECT s FROM Sales s WHERE (s.user.userID = ?1)")
    public List<Sales> findSalesByUserId(Integer id);
    
	@Query("SELECT s FROM Sales s WHERE (s.user.userID = ?1)")
	public Page<Sales> findByuser(Integer userId, Pageable pageable);
	
	@Query("SELECT s FROM Sales s WHERE s.user.userID = ?1 AND ("
			+ "s.product.name LIKE %?2% OR s.lastSold LIKE %?2% OR s.product.id LIKE %?2%)")
	public Page<Sales> findByuser(Integer userId, String keyword, Pageable pageable);

	@Query("SELECT sum(totalProfit) FROM Sales s WHERE s.product.id = ?1")
    public Integer sumQuantities(Integer id);
	
	@Query("SELECT sum(totalSales) FROM Sales s WHERE s.product.id = ?1")
    public Integer sumSales(Integer id);
	
    @Query("SELECT s FROM Sales s WHERE (s.product.id = ?1)")
    public List<Sales> findAllSalesByProductId(Integer id);
    
    @Query("SELECT s FROM Sales s WHERE (s.user.userID = ?1)")
    public List<Sales> findAllSalesByUserId(Integer id);
}
