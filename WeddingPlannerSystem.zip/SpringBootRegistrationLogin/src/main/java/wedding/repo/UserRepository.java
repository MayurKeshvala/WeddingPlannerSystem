package wedding.repo;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import wedding.model.Notification;
import wedding.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {	
	
 
	Optional<User> findUserByEmail(final String email);
	
    @Query("SELECT u FROM User u WHERE u.id = ?1")
    public User findUserById(Integer id);
	
    @Query("SELECT u FROM User u WHERE u.email = :email")
    public User getUserByEmail(@Param("email") String email);

    @Query("SELECT u FROM User u WHERE u.email = ?1")
    public User findByEmail(String email);
    
    public User findByResetPasswordToken(String token);
    
	public Long countByuserID(Integer userID);
	
	@Query("SELECT u FROM User u WHERE CONCAT(u.userID, ' ', u.email, ' ', u.firstName, ' ', u.lastName, ' ', u.addressLine, ' ',"
			+ " u.dob) LIKE %?1%")
	public Page<User> findAll(String keyword, Pageable pageable);
	
	@Query("UPDATE User u SET u.enabled = ?2 WHERE u.userID = ?1")
	@Modifying
	public void updateEnabledStatus(Integer id, boolean enabled);

//	@Query("SELECT u FROM User u WHERE u.helpRequired = true AND u.contacted ")
//	@Query(value =  "SELECT u. * FROM users u INNER JOIN users_contacted c ON u.user_id = c.user_user_id WHERE c.user_user_id = CASE WHEN c.user_user_id = ?1 THEN c.contacted_user_id END" ,  nativeQuery=true)
//	@Query(value =  "SELECT * FROM users_contacted c WHERE c.user_user_id = ?1",  nativeQuery=true)	
//	@Query("SELECT u FROM User u WHERE u.contacted.user_user_id IN ?1")
//	@Query(value =  "SELECT u. * FROM users u INNER JOIN users_contacted c ON u.user_id = c.user_user_id WHERE u.user_id IN ?1" ,  nativeQuery=true)
//	@Query("SELECT u FROM User u WHERE u.userID IN ?1")
//	@Query(value =  "SELECT DISTINCT u. * FROM users u JOIN users_contacted c ON u.user_id = c.respondee_id WHERE u.user_id = c.respondee_id AND c.contact_id = ?1" ,  nativeQuery=true)
	@Query(value =  "SELECT DISTINCT u. * FROM users u JOIN users_contacted c ON u.user_id = c.respondee_id OR u.user_id = c.contact_id WHERE (u.user_id = c.respondee_id AND c.contact_id = ?1) OR (c.respondee_id = ?1 AND u.user_id != ?1)" ,  nativeQuery=true)
	Page<User> findHelpByuser(Integer id, Pageable pageable);
//	@Query("SELECT s FROM Service s WHERE ?1 member of s.jobs")
}

