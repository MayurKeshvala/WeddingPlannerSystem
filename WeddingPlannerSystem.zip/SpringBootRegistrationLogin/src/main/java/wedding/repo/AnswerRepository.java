package wedding.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import wedding.model.Answer;


public interface AnswerRepository extends JpaRepository<Answer, Integer> {

	 @Query("SELECT a FROM Answer a WHERE a.answerId = ?1")
	    public Answer findAnswerById(Integer id);
	 
	 @Query("SELECT a FROM Answer a WHERE a.user.userID = ?1")
	    public List<Answer> findAnswerByUserId(Integer id);
}
