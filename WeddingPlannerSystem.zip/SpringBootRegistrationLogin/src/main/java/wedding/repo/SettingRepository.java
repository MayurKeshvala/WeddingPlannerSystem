package wedding.repo;

import java.util.List;


import org.springframework.data.repository.CrudRepository;
import wedding.model.Setting;
import wedding.model.SettingCategory;


public interface SettingRepository extends CrudRepository<Setting, String> {
	public List<Setting> findByCategory(SettingCategory category);
	
	public Setting findByKey(String key);
	
}
