package wedding.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import wedding.model.Suspension;


public interface SuspensionRepository extends JpaRepository<Suspension, Integer> {

    @Query("SELECT s FROM Suspension s WHERE s.id = ?1")
    public Suspension findSuspensionById(Integer id);
    
    @Query("SELECT s FROM Suspension s WHERE s.user.id = ?1")
    public Suspension findSuspensionReasonById(Integer id);
}
