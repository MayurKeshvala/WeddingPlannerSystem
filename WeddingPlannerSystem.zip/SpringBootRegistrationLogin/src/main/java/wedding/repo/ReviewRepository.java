package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import wedding.model.CartItem;
import wedding.model.Product;
import wedding.model.Review;



public interface ReviewRepository extends JpaRepository<Review, Integer> {
	
	@Query("SELECT r FROM Review r WHERE r.user.id = ?1")
	public Page<Review> findByuser(Integer userId, Pageable pageable);
	
	@Query("SELECT r FROM Review r WHERE r.id = ?1")
	public Review findReviewById(Integer reviewId);
	
	@Query("SELECT r FROM Review r WHERE r.user.id = ?1 AND ("
			+ "r.headline LIKE %?2% OR r.comment LIKE %?2% OR "
			+ "r.product.name LIKE %?2%)")
	public Page<Review> findByuser(Integer userId, String keyword, Pageable pageable);
	
	@Query("SELECT r FROM Review r WHERE r.user.id = ?1 AND r.id = ?2")
	public Review findByuserAndId(Integer userId, Integer reviewId);
	
	public Page<Review> findByProduct(Product product, Pageable pageable);
	
	@Query("SELECT COUNT(r.id) FROM Review r WHERE r.user.id = ?1 AND "
			+ "r.product.id = ?2")
	public Long countByuserAndProduct(Integer userId, Integer productId);
	
	@Query("SELECT r.votes FROM Review r WHERE r.id = ?1")
	public Integer getVoteCount(Integer reviewId);
	
    @Query("SELECT r FROM Review r WHERE r.product.id = ?1")
	public List<Review> findAllReviewByReviewId(Integer id);
    
    @Query("SELECT r FROM Review r WHERE r.user.userID = ?1")
	public List<Review> findAllReviewsByUserId(Integer id);
}
