package wedding.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import wedding.model.CartItem;
import wedding.model.Product;
import wedding.model.User;

public interface CartItemRepository extends CrudRepository<CartItem, Integer> {
	
    @Query("SELECT c FROM CartItem c WHERE c.user.id = ?1")
	public List<CartItem> findAllCartItemById(Integer userId);
	
    @Query("SELECT c FROM CartItem c WHERE c.product.id = ?1")
	public List<CartItem> findAllCartItemByProductId(Integer id);
    
    @Query("SELECT c FROM CartItem c WHERE c.user.userID = ?1")
	public List<CartItem> findAllCartItemByUserID(Integer id);
    
	@Modifying
	@Query("UPDATE CartItem c SET c.quantity = ?1 WHERE c.user.id = ?2 AND c.product.id = ?3")
	public void updateQuantity(Integer quantity, Integer userId, Integer productId);
	
	public CartItem findByUserAndProduct(User user, Product product);
	
	@Modifying
	@Query("DELETE CartItem c WHERE c.user.id = ?1")
	public void deleteByUser(Integer userId);	
	
	@Modifying
	@Query("DELETE FROM CartItem c WHERE c.user.id = ?1 AND c.product.id = ?2")
	public void deleteByUserAndProduct(Integer userId, Integer productId);
}
