package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import wedding.model.CartItem;
import wedding.model.Notification;
import wedding.model.Product;
import wedding.model.Sales;
import wedding.model.User;

public interface NotificationRepository extends CrudRepository<Notification, Integer> {

//	@Query("SELECT n FROM Notification n WHERE n.user.userID = ?1 AND ("
//			+ "n.headline LIKE %?2% OR n.message LIKE %?2% OR n.date LIKE %?2%)")
//	Page<Notification> findByuser(Integer userID, String keyword, Pageable pageable);

//	@Query("SELECT n FROM Notification n INNER JOIN user_notifications n2 ON n.id = n2.notification_id WHERE (nid.userID = ?1)")
//	public Page<Notification> findByuser(Integer userId, Pageable pageable);
//
//	@Query("SELECT n FROM Notification n INNER JOIN user_notifications n2 ON n.id = n2.notification_id WHERE (nid.userID = ?1)")
//	Page<Notification> findByuser(Integer userID, String keyword, Pageable pageable);

//	@Query(value = "SELECT n. * FROM notification n INNER JOIN user_notifications u ON n.notification_identity = u.notification_id WHERE u.user_id = ?1", nativeQuery=true)
//	@Query("SELECT n FROM Notification n WHERE n.user_sender = ?1")	
//	@Query(value =  "SELECT n. * FROM notification n INNER JOIN users_contacted c ON n.user_sender_user_id = c.contacted_user_id WHERE (c.user_user_id = ?1 AND c.contacted_user_id = ?2) OR  (c.user_user_id = ?2 AND c.contacted_user_id = ?1) " ,  nativeQuery=true)
//	@Query(value =  "SELECT DISTINCT n. * FROM notification n  JOIN user_notifications a ON a.notification_id = n.id JOIN users_contacted c ON a.user_id = c.respondee_id WHERE c.contact_id = ?1 AND c.respondee_id = ?2 OR c.contact_id = ?2 AND c.respondee_id = ?1" ,  nativeQuery=true)
//	@Query(value =  "SELECT DISTINCT n. * FROM notification n  JOIN user_notifications a ON a.notification_id = n.id JOIN users_contacted c ON a.user_id = c.contact_id OR a.user_id = c.respondee_id WHERE c.contact_id = ?1 AND c.respondee_id = ?2 OR c.contact_id = ?2 AND c.respondee_id = ?1" ,  nativeQuery=true)
//	@Query(value =  "	SELECT DISTINCT n. * FROM notification n JOIN user_notifications a ON a.notification_id = n.id JOIN users_contacted c ON a.user_id WHERE (n.user_sender_user_id = ?2 AND n.user_contact_user_id = ?1) OR (n.user_sender_user_id = ?1 AND n.user_contact_user_id = ?2)" ,  nativeQuery=true)
	@Query(value =  "SELECT n FROM Notification n WHERE (n.user_sender.userID = ?1 AND n.user_contact.userID = ?2) OR (n.user_contact.userID = ?1 AND n.user_sender.userID = ?2)")
	public Page<Notification> findByuser(Integer id, Integer id2, Pageable pageable);


	
}