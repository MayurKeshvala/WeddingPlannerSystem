package wedding.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import wedding.model.ShippingRate;
import wedding.model.User;


public interface ShippingRateRepository extends CrudRepository<ShippingRate, Integer> {
	
    @Query("SELECT s FROM ShippingRate s WHERE s.id = ?1")
    public ShippingRate findShippingRateById(Integer id);
}
