package wedding.repo;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import wedding.model.Currency;


public interface CurrencyRepository extends CrudRepository<Currency, Integer> {
	
	public List<Currency> findAllByOrderByNameAsc();
	
}
