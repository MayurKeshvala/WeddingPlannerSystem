package wedding.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import wedding.model.Address;


public interface AddressRepository extends CrudRepository<Address, Integer> {
	
	@Query("SELECT a FROM Address a WHERE a.user.id = ?1")
	public List<Address> findAllAddressById(Integer user);
	
	@Query("DELETE FROM Address a WHERE a.id = ?1 AND a.user.id = ?2")
	@Modifying
	public void deleteByIdAnduser(Integer addressId, Integer userId);
	
	@Query("SELECT a FROM Address a WHERE a.id = ?1 AND a.user.id = ?2")
	public Address findByIdAnduser(Integer addressId, Integer userId);
		
	@Query("UPDATE Address a SET a.defaultForShipping = true WHERE a.id = ?1")
	@Modifying
	public void setDefaultAddress(Integer id);
	
	@Query("SELECT a FROM Address a WHERE a.user.id = ?1 AND a.defaultForShipping = true")
	public Address findDefaultByuser(Integer userId);
	
	@Query("UPDATE Address a SET a.defaultForShipping = false" + " WHERE a.id != ?1 AND a.user.id = ?2")
	@Modifying
	public void setNonDefaultForOthers(Integer defaultAddressId, Integer userId);
		
}
