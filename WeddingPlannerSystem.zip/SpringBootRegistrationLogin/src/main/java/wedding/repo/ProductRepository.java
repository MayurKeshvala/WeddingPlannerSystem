package wedding.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import wedding.model.Product;

public interface ProductRepository extends PagingAndSortingRepository<Product, Integer> {

	@Query("SELECT p FROM Product p WHERE p.category.id = ?1 AND " + "(p.category.id = ?1) " + "AND (p.enabled = true)" + " AND (p.category.enabled = true) AND" + " (p.user.enabled = true)")
	public Page<Product> listByCategory(Integer categoryId, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE p.category.id = ?1")
	public Page<Product> listByCategoryAdmin(Integer categoryId, String categoryIDMatch, Pageable pageable);
   
	
	
	@Query("SELECT p FROM Product p WHERE p.user.userID = ?1")
	public List<Product> listProductByUser(Integer id);
	
	
	@Query("SELECT p FROM Product p WHERE p.service = true")
	public List<Product> listService();
	
	@Query("SELECT p FROM Product p WHERE (p.name LIKE %?1% " 
			+ "OR p.shortDescription LIKE %?1% "
			+ "OR p.fullDescription LIKE %?1% "
			+ "OR p.user.firstName LIKE %?1% "
			+ "OR p.user.lastName LIKE %?1% "
			+ "OR p.category.name LIKE %?1%) "
			+ "AND (p.enabled = true)"
			+ "AND (p.user.enabled = true)")
	public Page<Product> search(String keyword, Pageable pageable);

	public Product findByName(String name);
	
	@Query("UPDATE Product p SET p.enabled = ?2 WHERE p.id = ?1")
	@Modifying
	public void updateEnabledStatus(Integer id, boolean enabled);
	
	public Long countById(Integer id);

	@Query("SELECT p FROM Product p WHERE p.id = ?1 ")
	public Product findByProductId(Integer id);
	
	@Query("SELECT p FROM Product p WHERE p.user.userID = ?1 ")
	public List<Product> findAllByUser(Integer id);
	
	//Used in admin to find all products with keywords, regardless of category
	@Query("SELECT p FROM Product p WHERE p.name LIKE %?1% " 
			+ "OR p.shortDescription LIKE %?1% "
			+ "OR p.user.firstName LIKE %?1% "
			+ "OR p.user.lastName LIKE %?1% "
			+ "OR p.fullDescription LIKE %?1% "
			+ "OR p.category.name LIKE %?1%")
	public Page<Product> findAll(String keyword, Pageable pageable);

	
	@Query("SELECT p FROM Product p WHERE (p.name LIKE %?1% " 
			+ "OR p.shortDescription LIKE %?1% "
			+ "OR p.user.firstName LIKE %?1% "
			+ "OR p.user.lastName LIKE %?1% "
			+ "OR p.fullDescription LIKE %?1% "
			+ "OR p.category.name LIKE %?1%) "
			+ "AND (p.enabled = true)"
			+ "AND (p.user.enabled = true)")
	public Page<Product> findAllProductUser(String keyword, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE (p.name LIKE %?1% " 
			+ "OR p.shortDescription LIKE %?1% "
			+ "OR p.user.firstName LIKE %?1% "
			+ "OR p.user.lastName LIKE %?1% "
			+ "OR p.fullDescription LIKE %?1% "
			+ "OR p.category.name LIKE %?1%)")
	public Page<Product> findAllProductAdmin(String keyword, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE CONCAT (p.name, ' ', p.date, ' ', p.shortDescription, ' ', p.fullDescription, ' ', p.user.firstName , ' ', p.user.lastName , ' ', " + " p.category.name) LIKE %?1% AND " + " (p.user.id = ?2)")		
	public Page<Product> findAllSupplier(String keyword, Integer ide, Pageable pageable);
	
	//Used by customers to find a product regardless of category.
	@Query("SELECT p FROM Product p WHERE CONCAT (p.name, ' ', p.shortDescription, ' ', p.fullDescription, ' ', p.user.firstName , ' ', p.user.lastName ,' ', " + " p.category.name) LIKE %?1% AND " + " (p.category.id = ?2)")		
	public Page<Product> findAllCategoryByProd(String keyword, Integer ide, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE p.category.id = ?1 ")	
	public List<Product> findProductByCategory(Integer categoryId);
	
	@Query("SELECT p FROM Product p WHERE p.enabled = true")	
	public Page<Product> findProductByEnabled(Pageable pageable);
	
	@Query("SELECT p FROM Product p ORDER BY p.name ASC")	
	public Page<Product> findAllProduct(Pageable pageable);
	
	//Used by customers to find all products in all category.
	@Query("SELECT p FROM Product p WHERE (p.category.id = ?1) " + "AND (p.enabled = true)" + " AND (p.category.enabled = true) AND" + " (p.user.enabled = true)")	
	public Page<Product> findAllInCategory(Integer categoryId, Pageable pageable);
	
	//Used by customers to find all products in all category.
	@Query("SELECT p FROM Product p WHERE (p.enabled = true" + " AND p.category.enabled = true AND" + " p.user.enabled = true)")	
	public Page<Product> findAllCategory(Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE p.enabled = true " + "AND (p.user.userID = ?2)" + "AND (p.category.id = ?1)")
	public Page<Product> findAllInCategoryUser(Integer categoryId, Integer userId, 
			Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE p.enabled = true " + "AND (p.user.userID = ?1)")
	public Page<Product> findAllByUser(Integer userId, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE p.enabled = true" + " AND p.category.enabled = true AND" + " p.user.enabled = true")
	public Page<Product> findAllProducts(Pageable pageable);
	
	//this is used in admin, check against multiple fields for keyword.
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.date, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + " (p.category.id = ?1)")		
	public Page<Product> searchInCategory(Integer categoryId, 
			String keyword, Pageable pageable);

	
	//this is used in customer, check against multiple fields for keyword with category accounted for.
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + " (p.category.id = ?1) AND " + " (p.enabled = true)")		
	public Page<Product> searchInCategoryUser(Integer categoryId, 
			String keyword, Pageable pageable);
	
	//this is used in customer, check against multiple fields for keyword with category accounted for.
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + " (p.category.id = ?1)")		
	public Page<Product> searchInCategoryAdmin(Integer categoryId, 
			String keyword, Pageable pageable);	
	
	//this is used in customer, check against multiple fields for keyword with category and date accounted for.
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + "(p.id IN ?3 AND p.id IN ?4) AND " + "(p.category.id = ?1) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true)")	
	public Page<Product> searchInCategoryServiceUser(Integer categoryId, 
			String keyword, List<Integer> listId, List<Integer> viableVenue, Pageable pageable);
	
	//this is used in customer, check against multiple fields for keyword with category and date accounted for.
	@Query("SELECT p FROM Product p WHERE (p.id IN ?1) AND " + " (p.id IN ?2) AND" + "(p.enabled = true) AND " + " (p.user.enabled = true)")	
	public Page<Product> listByServiceDateUser(List <Integer> listID, List <Integer> venueList, Pageable pageable);
	
//	//this is used in customer, check against multiple fields with category and date accounted for.
//	@Query("SELECT p FROM Product p WHERE CONCAT(p.date) LIKE %?1% AND " + " (p.enabled = true) AND " + " (p.category.id = ?2) AND " + " (p.user.enabled = true)")	
//	public Page<Product> listByServiceDateandKeyUser(String serviceDate, Integer categoryId, Pageable pageable);
	
	//this is used in customer, check against multiple fields with category and date accounted for.
//	@Query("SELECT p FROM Product p WHERE (p.date BETWEEN cast(?1 as string) AND cast(?2 as string)) AND p.id IN ?3")
//	public Page<Product> listAllDateinCategory(String one, String two, List<Integer> listId, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE (p.id IN ?1 AND p.id IN ?2) AND " +  "(p.id IN ?2) AND " + "(p.category.id = ?3) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true)")
	public Page<Product> listAllDateinCategory(List<Integer> listId, List<Integer> listVenue, Integer categoryId, Pageable pageable);
	
	
	@Query("Update Product p SET p.averageRating = COALESCE((SELECT AVG(r.rating) FROM Review r WHERE r.product.id = ?1), 0)," + " p.reviewCount = (SELECT COUNT(r.id) FROM Review r WHERE r.product.id =?1) " + "WHERE p.id = ?1")
	@Modifying
	public void updateReviewCountAndAverageRating(Integer productId);
	
	
	@Query("SELECT p FROM Product p WHERE p.date BETWEEN '2023-12-01' AND '2023-12-09'")
	public List<Product> listAllDate();
	
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?1% AND " + "(p.id IN ?2) AND " + "(p.id IN ?3) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true) AND" + "(p.service = true)")	
	public Page<Product> findAllProductKeyWordAndDateAndViableVenue(String keyWord, List <Integer> idList, List <Integer> venue, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE p.price BETWEEN ?1 AND ?2")
	public Page<Product> findAllBetweenPrice(Double fromPrice, Double toPrice, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?3% AND " + " (p.enabled = true) AND " + " (p.user.enabled = true) AND" + "(p.price BETWEEN ?1 AND ?2)")	
	public Page<Product> findAllBetweenPriceWithKeyword(Double fromPrice, Double toPrice, String keyWord, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?3% AND " + "(p.id IN ?4 AND p.id IN ?5) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true) AND" + "(p.price BETWEEN ?1 AND ?2) AND" + "(p.service = true)")	
	public Page<Product> findAllBetweenPriceWithKeywordWithServiceDate(Double fromPrice, Double toPrice, String keyWord, List <Integer> idList, List <Integer> viableVenue, Pageable pageable);
	
	@Query("SELECT p FROM Product p WHERE (p.category.id = ?1) AND " + " (p.enabled = true) AND " + " (p.category = true) AND" +  "(p.user.enabled = true) AND" + "(p.price BETWEEN ?2 AND ?3)")
	public Page<Product> findAllinCategoryBetweenPrice(Integer categoryId, Double fromPrice, Double toPrice, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + "(p.id IN ?3 AND p.id IN ?6) AND " + "(p.category.id = ?1) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true) AND " + " (p.category.enabled = true) AND" + " (p.price BETWEEN ?4 AND ?5)")	
	public Page<Product> searchInCategoryServiceUserPrice(Integer categoryId, String keyword, List<Integer> listId, Double fromPrice, Double toPrice, List<Integer> viableVenue, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE CONCAT(p.category.id, ' ', p.user.firstName, ' ', p.user.lastName, ' ', p.name,' ', p.shortDescription, ' ', p.fullDescription, ' ',"
			+ " p.category.name) LIKE %?2% AND " + "(p.category.id = ?1) AND " + " (p.enabled = true) AND " + " (p.user.enabled = true) AND " + " (p.category.enabled = true) AND" + " (p.price BETWEEN ?3 AND ?4)")	
	public Page<Product> searchInCategoryUserPrice(Integer categoryId, String keyword, Double fromPrice, Double toPrice, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE (p.id IN ?1) AND p.category.id = ?2")	
	public Page<Product> searchViableVenue(List<Integer> viableVenue, Integer catId, Pageable pageable);

	@Query("SELECT p FROM Product p WHERE p.id IN ?4 AND " + "(p.category.id = ?1) AND " + " (p.enabled = true) AND " + " (p.category = true) AND" +  "(p.user.enabled = true) AND" + "(p.price BETWEEN ?2 AND ?3)")
	public Page<Product> findAllinCategoryBetweenPriceAndViable(Integer categoryId, Double fromPrice, Double toPrice, List<Integer> viableVenue,  Pageable pageable);
}
