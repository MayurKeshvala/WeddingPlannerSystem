package wedding.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import wedding.exception.ProductNotFoundException;
import wedding.model.*;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import wedding.repo.ProductRepository;

@Service
public class ProductService {
	public static final int PRODUCTS_PER_PAGE = 10;

	
	@Autowired private ProductRepository repo;
	
	public Page<Product> listByCategory(int pageNum, Integer categoryId) {

		Pageable pageable = PageRequest.of(pageNum - 1, PRODUCTS_PER_PAGE);
		
		return repo.listByCategory(categoryId, pageable);
	}
	

	
	
	public List<Product> listAll() {
		return (List<Product>) repo.findAll();
	}
	public Page<Product> listByPageAdmin(int pageNum, String sortChosenField, String sortDirection, 
			String keyWord, Integer categoryId) {
		Sort sort = Sort.by(sortChosenField);
		
		sort = sortDirection.equals("asc") ? sort.ascending() : sort.descending();
				
		Pageable pageable = PageRequest.of(pageNum - 1, PRODUCTS_PER_PAGE, sort);
		

		
		if (keyWord != null && !keyWord.isEmpty()) {
			if (categoryId != null && categoryId > 0) {

				
				return repo.searchInCategoryAdmin(categoryId, keyWord, pageable);
			}
			
			return repo.findAllProductAdmin(keyWord, pageable);
		}
		
		if (categoryId != null && categoryId > 0) {
			String categoryIdMatch = "-" + String.valueOf(categoryId) + "-";
			return repo.listByCategoryAdmin(categoryId, categoryIdMatch, pageable);
		}
		
		if (categoryId == 0) {

			
			return repo.findAll(pageable);	
		}
		
		return repo.findAll(pageable);		
	}	
	

	@SuppressWarnings("unused")
	public Page<Product> listByPageCustomer(int pageNum, String sortChosenField, String sortDirection, 
			String keyWord, Integer categoryId, String serviceDate, String serviceDate2, List<Integer> idList, Double fromPrice, Double toPrice, List<Integer> viableVenue) {
		Sort sort = Sort.by(sortChosenField);
		
		sort = sortDirection.equals("asc") ? sort.ascending() : sort.descending();
				
		Pageable pageable = PageRequest.of(pageNum - 1, PRODUCTS_PER_PAGE, sort);
		
		String test = serviceDate;
		
		if (keyWord != null && !keyWord.isEmpty()) {//			
			
			if (categoryId != null && categoryId > 0) {//
				
				
				if (serviceDate == null) {//
						
					if(fromPrice != null) {//
						
						return repo.searchInCategoryUserPrice(categoryId, keyWord, fromPrice, toPrice,  pageable);
					
				}
					return repo.searchInCategoryServiceUser(categoryId, keyWord, idList, viableVenue,  pageable);
		
			}
				
				if (serviceDate != null && !serviceDate.isEmpty()) {//
				System.out.println("it goes here mizz");
					if(fromPrice != null) {//
					
						return repo.searchInCategoryServiceUserPrice(categoryId, keyWord, idList, fromPrice, toPrice, viableVenue, pageable);	
					}
					
					return repo.findAllProductKeyWordAndDateAndViableVenue(keyWord, idList, viableVenue, pageable);
				
				}
				
				return repo.searchInCategoryUser(categoryId, keyWord, pageable);
			}
			
			if (serviceDate != null) {//
				
				return repo.findAllProductKeyWordAndDateAndViableVenue(keyWord, idList, viableVenue, pageable);
			}
			
			return repo.findAllProductUser(keyWord, pageable);
		}
		
		
		
		
		
		
		
		if (categoryId != null && categoryId > 0) {///
		
			if(fromPrice != null) {///
				
				if(keyWord != null) {///
					
			return repo.searchInCategoryUserPrice(categoryId, keyWord, fromPrice, toPrice, pageable);
			
				}
				
			return repo.findAllinCategoryBetweenPrice(categoryId, fromPrice, toPrice, pageable);
			
			}
			
			if (serviceDate != null) {//
				
				System.out.println("yuh, its me, mayo");
	
				return repo.listAllDateinCategory(idList, viableVenue, categoryId, pageable);
			
			}
			
			return repo.listByCategory(categoryId,  pageable);	
		
		}
			
		if (categoryId == 0) { // ALL ID -> PRICE -> KEYWORD -> SERVICE DATE, ALL ID -> PRICE -> KEYWORD, ALL ID -> PRICE
			
			if(fromPrice != null) {
				
				if(keyWord != null) {
					
					
					if (serviceDate != null) {
						
						return repo.findAllBetweenPriceWithKeywordWithServiceDate(fromPrice, toPrice, keyWord, idList, viableVenue, pageable);
						
					}
					
					return repo.findAllBetweenPriceWithKeyword(fromPrice, toPrice, keyWord, pageable);
				
				}
				
				return repo.findAllBetweenPrice(fromPrice, toPrice, pageable);
			
			}
				if(keyWord != null) { // ALL ID -> KEYWORD, ALL ID -> KEYWORD -> SERVICE DATE
					
					if (serviceDate != null) {
						
						System.out.println("yolo");
						
						return repo.findAllProductKeyWordAndDateAndViableVenue(keyWord, idList, viableVenue, pageable);
					
					}
					return repo.findAllProductUser(keyWord, pageable);
					
			}
			
//			if(keyWord != null) {
//				
//				if (serviceDate != null) {
//				
//					return repo.findAllProductKeyWordAndDateAndViableVenue(keyWord, idList, viableVenue, pageable);
//				
//				}
//			
//				return repo.findAllProductUser(keyWord, pageable);	
//		
//			}
			
			if (serviceDate != null) { //ALL ID -> SERVICE DATE + LOCATION

				System.out.println("it goes here, mayo you can do this<3");
				return repo.listByServiceDateUser(idList, viableVenue, pageable);
		
			}
			
			return repo.findAllCategory(pageable);
	
		}
		
		return repo.findAllCategory(pageable);		
	
	}	
	
	
	public Product save(Product product) {
		if (product.getId() == null) {
			product.setCreatedTime(new Date());
		}
		

		product.setUpdatedTime(new Date());
		
		return repo.save(product);
	}
	
	public void saveProductPrice(Product productInForm) {
		Product productInDB = repo.findById(productInForm.getId()).get();
		productInDB.setPrice(productInForm.getPrice());
		
		repo.save(productInDB);
	}
	
	
	public void updateProductEnabledStatus(Integer id, boolean enabled) {
		repo.updateEnabledStatus(id, enabled);
	}
	
	public void delete(Integer id) throws ProductNotFoundException {
		Long countById = repo.countById(id);
		
		if (countById == null || countById == 0) {
			throw new ProductNotFoundException("Could not find any product with ID " + id);			
		}
		
		repo.deleteById(id);
	}	
	
	public Product get(Integer id) throws ProductNotFoundException {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException ex) {
			throw new ProductNotFoundException("Could not find any product with ID " + id);
		}
	}
	
	public Page<Product> listByPageUser(int pageNum, String sortChosenField, String sortDirection, 
			String keyWord, Integer categoryId, Integer userId) {
		Sort sort = Sort.by(sortChosenField);
		
		sort = sortDirection.equals("asc") ? sort.ascending() : sort.descending();
				
		Pageable pageable = PageRequest.of(pageNum - 1, PRODUCTS_PER_PAGE, sort);
		

		
		if (keyWord != null && !keyWord.isEmpty()) {
			
			if (categoryId != null && categoryId > 0) {

				
				return repo.searchInCategory(categoryId, keyWord, pageable);
			}
			
			return repo.findAllSupplier(keyWord, userId, pageable);
		}
		
		if (categoryId != null && categoryId > 0) {

			
			return repo.findAllInCategoryUser(categoryId, userId, pageable);
		}
		
		if (categoryId == 0) {

		
			return repo.findAllByUser(userId, pageable);
		}
		
		return repo.findAll(pageable);		
	}	


public Page<Product> listByPageCustomer(int pageNum, String sortChosenField, String sortDirection, 
		String keyWord, Integer categoryId, Integer ide) {
	Sort sort = Sort.by(sortChosenField);
	
	sort = sortDirection.equals("asc") ? sort.ascending() : sort.descending();
			
	Pageable pageable = PageRequest.of(pageNum - 1, PRODUCTS_PER_PAGE, sort);
	
	System.out.println(categoryId);
	System.out.println(ide);
	
	if (keyWord != null && !keyWord.isEmpty()) {
		if (categoryId != null && categoryId > 0) {
			
			return repo.searchInCategoryUser(categoryId, keyWord, pageable);
		}
		
		return repo.findAllCategoryByProd(keyWord, ide, pageable);
	}
	
	if (ide != null && ide > 0) {


		return repo.findAllInCategory(ide, pageable);
	}
	
	if (ide == 0) {

		return repo.findAllCategory(pageable);
	}
	
	return repo.findAllProducts(pageable);		
}	
}
