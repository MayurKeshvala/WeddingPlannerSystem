package wedding.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import wedding.exception.PayPalApiException;
import wedding.model.PayPalOrderResponse;
import wedding.model.PaymentSettingBag;



@Component
public class PayPalService {
	private static final String GET_ORDER_API = "/v2/checkout/orders/";
	
	@Autowired private SettingService settingService;
	
	public boolean validateOrder(String orderId) throws PayPalApiException {

		PayPalOrderResponse response = getOrderDetails(orderId);
		
		return response.validate(orderId);
	
	}

	private PayPalOrderResponse getOrderDetails(String orderId) throws PayPalApiException {
	
		ResponseEntity<PayPalOrderResponse> ppResponse = makeRequest(orderId);
		
		HttpStatus code = ppResponse.getStatusCode();
		
		if (!code.equals(HttpStatus.OK)) {
		
			throwExceptionForNonOKResponse(code);
		
		}
		
		return ppResponse.getBody();
	
	}

	private ResponseEntity<PayPalOrderResponse> makeRequest(String orderId) {
	
		PaymentSettingBag paymentSettings = settingService.getAllPaymentSettings();
		
		String baseURL = paymentSettings.getURL();
		
		String requestURL = baseURL + GET_ORDER_API + orderId;
		
		String clientId = paymentSettings.getClientID();
		
		String clientSecret = paymentSettings.getClientSecret();
		
		HttpHeaders headers = new HttpHeaders();
		
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		headers.add("Accept-Language", "en_US");
		
		headers.setBasicAuth(clientId, clientSecret);
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headers);
		
		RestTemplate restTemplate = new RestTemplate();
		
		return restTemplate.exchange(
				requestURL, HttpMethod.GET, request, PayPalOrderResponse.class);
	}

	private void throwExceptionForNonOKResponse(HttpStatus code) throws PayPalApiException {
	
		String responseMessage = null;
		
		switch (code) {
		
		case NOT_FOUND: 
		
			responseMessage = "Order ID not found";
			
		case BAD_REQUEST:
		
			responseMessage = "Bad Request to PayPal Checkout API";
			
		case INTERNAL_SERVER_ERROR:
		
			responseMessage = "PayPal server error";
			
		default:
			
			responseMessage = "PayPal returned non-OK status code";
	
		}
		
		throw new PayPalApiException(responseMessage);
	
	}

}
