package wedding.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import wedding.exception.ShoppingCartException;
import wedding.model.CartItem;
import wedding.model.Product;
import wedding.model.User;
import wedding.repo.CartItemRepository;
import wedding.repo.ProductRepository;

@Service
@Transactional
public class ShoppingCartService {

	@Autowired private CartItemRepository cRepo;
	@Autowired private ProductRepository productRepo;
	
	public Integer addUserProduct(Integer productId, Integer quantity, User user) throws ShoppingCartException {
		Integer updatedQuantity = quantity;
		Product product = new Product(productId);
		
		CartItem cartItem = cRepo.findByUserAndProduct(user, product);
		
		if (cartItem != null) {
			updatedQuantity = cartItem.getQuantity() + quantity;
			
			if (updatedQuantity > 40) {
				throw new ShoppingCartException("Could not add more " + quantity + " item(s)"
						+ " because there's already " + cartItem.getQuantity() + " item(s) "
						+ "in your shopping cart. Maximum allowed quantity is 40.");
			}
		} else {
			cartItem = new CartItem();
			cartItem.setUser(user);
			cartItem.setProduct(product);
		}
		
		cartItem.setQuantity(updatedQuantity);
		
		cRepo.save(cartItem);
		
		return updatedQuantity;
	}
	
	
	public String addService(Integer productId, String date, User user) 
			throws ShoppingCartException {
		Product product = new Product(productId);
		
		List<CartItem> allCartItem = cRepo.findAllCartItemByUserID(user.getUserID());
		
		System.out.println("goes wrong here");
		
		Product checkProduct = productRepo.findByProductId(productId);
		
		for(CartItem c : allCartItem) {
			if(c.getDate() != null) {
			if(c.getDate().equals(date) && c.getProduct().getId() == productId) {
				System.out.println(c.getDate());
				System.out.println(date);
				System.out.println(c.getProduct().getId());
				System.out.println(productId);
				return null;
			}
			}
		}
		
		System.out.println("goes wrong here2");
		
		System.out.println(checkProduct.isService());
		
		if(!checkProduct.isService()) {
		CartItem cartItem = cRepo.findByUserAndProduct(user, product);
		
			cartItem = new CartItem();
			cartItem.setUser(user);
			cartItem.setProduct(product);
			cartItem.setDate(date);
		
		
		cRepo.save(cartItem);
		}
		
		if(checkProduct.isService()) {
			CartItem cartItem = new CartItem();
			cartItem.setUser(user);
			cartItem.setProduct(product);
			cartItem.setDate(date);
		
		
		cRepo.save(cartItem);
		}
		System.out.println("goes wrong here3");
		String productName = null;
		
		Iterable<Product> allProd = productRepo.findAll();
		 for(Product p : allProd) {
			 if(p.getId() == productId) {
				productName = p.getName(); 
			 }
		 }
		
		return productName;
	}
	
	public List<CartItem> listCartItems(Integer userId) {
		
		return cRepo.findAllCartItemById(userId);
		
	}
	
	public double updateQuantity(Integer productId, Integer quantity, User user) {
		
		cRepo.updateQuantity(quantity, user.getUserID(), productId);
		
		Product product = productRepo.findById(productId).get();
		
		double subtotal = product.getPrice() * quantity;
		
		return subtotal;
		
	}
	
	public void removeUserProduct(Integer productId, Integer user) {
		
		cRepo.deleteByUserAndProduct(user, productId);
		
	}
	
	public void deleteByUser(Integer user) {
		
		cRepo.deleteByUser(user);
		
	}
	
}
