package wedding.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import wedding.exception.CategoryNotFoundException;
import wedding.exception.UserNotFoundException;
import wedding.model.Category;
import wedding.model.User;
import wedding.repo.CategoryRepository;

@Service
@Transactional
public class CategoryService {
	
	@Autowired
	private CategoryRepository cRepo;
	
	public static final int CATEGORY_PER_PAGE = 10;
	
	public Page<Category> listByCategoryPage(String keyWord, String sortChosenField, String sortDirection, int currentpageNumber) {
		
		Sort sortField = Sort.by(sortChosenField);
		
		sortField = sortDirection.equals("asc") ? sortField.ascending() : sortField.descending();
				
		Pageable pageableContent = PageRequest.of(currentpageNumber - 1, CATEGORY_PER_PAGE, sortField);
		
		if (keyWord != null) {
			
			return cRepo.findAll(keyWord, pageableContent);
			
		}
		
		return cRepo.findAll(pageableContent);
	}
	
	public void updateCategoryEnabledStatus(Integer id, boolean enabled) {
		
		cRepo.updateEnabledStatus(id, enabled);
		
	}
}
