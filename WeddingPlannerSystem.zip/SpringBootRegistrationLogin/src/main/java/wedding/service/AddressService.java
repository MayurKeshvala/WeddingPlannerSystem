package wedding.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import wedding.model.Address;
import wedding.model.User;
import wedding.repo.AddressRepository;




@Service
@Transactional
public class AddressService {
	
	@Autowired private AddressRepository repo;
	
	public List<Address> listAddressBook(Integer user) {
		
		return repo.findAllAddressById(user);
		
	}

	public void save(Address address) {
		
		repo.save(address);
		
	}
	
	public Address get(Integer addressId, Integer userId) {
		
		return repo.findByIdAnduser(addressId, userId);
		
	}
	
	public void delete(Integer addressId, Integer userId) {
		
		repo.deleteByIdAnduser(addressId, userId);
		
	}
	
	public void setDefaultAddress(Integer defaultAddressId, Integer userId) {
		
		if (defaultAddressId > 0) {
			
			repo.setDefaultAddress(defaultAddressId);
			
		}
		
		repo.setNonDefaultForOthers(defaultAddressId, userId);
	}
	
	public Address getDefaultAddress(Integer user) {
		
		return repo.findDefaultByuser(user);
		
	}
	
}
