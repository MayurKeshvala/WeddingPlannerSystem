package wedding.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import wedding.model.CartItem;
import wedding.model.CheckoutInfo;
import wedding.model.Product;
import wedding.model.ShippingRate;
import wedding.repo.ShippingRateRepository;

@Service
public class CheckoutService {

	@Autowired
	ShippingRateRepository srRepo;
	
	public CheckoutInfo prepareCheckout(List<CartItem> cartItems, ShippingRate shippingRate) {
		CheckoutInfo checkoutInfo = new CheckoutInfo();
		
		
		float productTotal = calculateProductTotal(cartItems);
		
		float shippingCostTotal = 0;
		
		if(shippingRate != null) {
			
		shippingCostTotal = shippingRate.getRate();
		
		}
		
		float paymentTotal = productTotal + shippingCostTotal;
		
		checkoutInfo.setProductTotal(productTotal);
		
		checkoutInfo.setShippingCostTotal(shippingCostTotal);
		
		checkoutInfo.setPaymentTotal(paymentTotal);
		
		if(shippingRate != null) {
		
			checkoutInfo.setDeliverDays(shippingRate.getDays());
		}
	
		return checkoutInfo;
	
	}


	private float calculateProductTotal(List<CartItem> cartItems) {
		float total = 0.0f;
		
		for (CartItem item : cartItems) {
			
			if(item.getProduct().isService() == true) {
			
				total += item.getProduct().getPrice();
			
			}else if(item.getProduct().isService() == false) {
			
				total += item.getSubtotal();
			
			}
		
		}
		
		return total;
	}

}
