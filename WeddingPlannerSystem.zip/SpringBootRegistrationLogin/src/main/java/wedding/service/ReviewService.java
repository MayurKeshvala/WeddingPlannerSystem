package wedding.service;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import wedding.exception.ReviewNotFoundException;
import wedding.model.Product;
import wedding.model.Review;
import wedding.model.User;
import wedding.repo.OrderDetailRepository;
import wedding.repo.ProductRepository;
import wedding.repo.ReviewRepository;

@Service
@Transactional
public class ReviewService {
	public static final int REVIEWS_PER_PAGE = 5;
	
	@Autowired private ReviewRepository rRepo;
	@Autowired private OrderDetailRepository odRepo;
	@Autowired private ProductRepository productRepo;

	public Page<Review> listByuserByPage(User user, String keyword, int pageNumber, 
			String sortChosenField, String sortDirection) {
		Sort sortyBy = Sort.by(sortChosenField);
		sortyBy = sortDirection.equals("asc") ? sortyBy.ascending() : sortyBy.descending();
		
		Pageable pageable = PageRequest.of(pageNumber - 1, REVIEWS_PER_PAGE, sortyBy);
		
		if (keyword != null) {
			return rRepo.findByuser(user.getUserID(), keyword, pageable);
		}
		
		return rRepo.findByuser(user.getUserID(), pageable);
	}
	
	public Review getByuserAndId(User user, Integer reviewId) throws ReviewNotFoundException {
		Review review = rRepo.findByuserAndId(user.getUserID(), reviewId);
		if (review == null) 
			throw new ReviewNotFoundException("user doesn not have any reviews with ID " + reviewId);
		
		return review;
	}
	
	public Page<Review> list3MostVotedReviewsByProduct(Product product) {
		Sort sortyBy = Sort.by("votes").descending();
		Pageable pageable = PageRequest.of(0, 3, sortyBy);
		
		return rRepo.findByProduct(product, pageable);		
	}
	
	public Page<Review> listByProduct(Product product, int pageNumber, String sortChosenField, String sortDirection) {
		
		Sort sortyBy = Sort.by(sortChosenField);
		
		sortyBy = sortDirection.equals("asc") ? sortyBy.ascending() : sortyBy.descending();
		
		Pageable pageable = PageRequest.of(pageNumber - 1, REVIEWS_PER_PAGE, sortyBy);
		
		return rRepo.findByProduct(product, pageable);
	}

	public boolean diduserReviewProduct(User user, Integer productId) {
		
		Long count = rRepo.countByuserAndProduct(user.getUserID(), productId);
		
		return count > 0;
		
	}
	
	public boolean canUserReviewProduct(User user, Integer productId) {
		Long count = odRepo.countByProductAndCustomerAndOrderStatus(productId, user.getUserID());
		return count > 0;
	}
	
	public Review save(Review review) {
		
		review.setReviewTime(new Date());
		
		Review savedReview = rRepo.save(review);
		
		Integer productId = savedReview.getProduct().getId();
		
		productRepo.updateReviewCountAndAverageRating(productId);
		
		return savedReview;
	}
	
	public void updateRating(Integer productId) {
			
		productRepo.updateReviewCountAndAverageRating(productId);
	
	}
}
