package wedding.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import wedding.model.ShippingRate;
import wedding.repo.ShippingRateRepository;

@Service
public class ShippingRateService {

	@Autowired private ShippingRateRepository repo;
	
	public ShippingRate getShippingRateById(Integer id) {
		return repo.findShippingRateById(id);
		
	}

}
