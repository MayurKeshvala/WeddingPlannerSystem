package wedding.service;

import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import wedding.dto.EmailDto;
import wedding.dto.EntityToDtoConverter;
import wedding.exception.UserNotFoundException;
import wedding.model.EmailSettingBag;
import wedding.model.Roles;
import wedding.model.User;
import wedding.repo.RolesRepository;
import wedding.repo.UserRepository;
import wedding.utility.Utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepository;

    @Autowired 
    private RolesRepository roleRepo;
	
	@Autowired 
	private PasswordEncoder passwordEncoder;
	
	@Autowired 
	private SettingService settingService;
	
	public static final int USERS_PER_PAGE = 4;
	
	public Page<User> listByPage(int pageNum, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
				
		Pageable pageable = PageRequest.of(pageNum - 1, USERS_PER_PAGE, sort);
		
		if (keyword != null) {
			return userRepository.findAll(keyword, pageable);
		}
		
		return userRepository.findAll(pageable);
	}
	
	
	
	 public void updateResetPasswordToken(String randomToken, String email) throws UserNotFoundException {
	        User user = userRepository.findByEmail(email);
	        if (user != null) {
	            user.setResetPasswordToken(randomToken);
	            userRepository.save(user);
	        } else {
	            throw new UserNotFoundException("Could not find any customer with the email " + email);
	        }
	    }
	     
	    public User getByResetPasswordToken(String randomToken) {
	        return userRepository.findByResetPasswordToken(randomToken);
	    }
	     
	    public void updatePassword(User user, String newPassword) {
	        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	        String encodedPassword = passwordEncoder.encode(newPassword);
	        user.setPassword(encodedPassword);
	         
	        user.setResetPasswordToken(null);
	        userRepository.save(user);
	    }
	
	public EmailDto getUserByEmail(final String email) {
		Optional<User> user = userRepository.findUserByEmail(email);

		if (user.isPresent()) {
			return EntityToDtoConverter.convertUserEntityToDto(user.get());
		}

		throw new RuntimeException("No user available for the given user name");
	}
	
	public void updateUserEnabledStatus(Integer id, boolean enabled) {
		userRepository.updateEnabledStatus(id, enabled);
	}
	

	
	public List<User> listAll() {
		return userRepository.findAll();
	}


	
	public List<Roles> listRoles() {
		return roleRepo.findAll();
	}
	
	public User save(User user) {
		boolean isUpdatingUser = (user.getUserID() != null);
		
		if (isUpdatingUser) {
			User existingUser = userRepository.findById(user.getUserID()).get();
			
			if (user.getPassword().isEmpty()) {
				user.setPassword(existingUser.getPassword());
			} else {
				encodePassword(user);
			}
			
		} else {		
			encodePassword(user);
		}
		
		return userRepository.save(user);
	}
	
	public User get(Integer id) throws UserNotFoundException {
		try {
			return userRepository.findById(id).get();
		} catch (NoSuchElementException ex) {
			throw new UserNotFoundException("Could not find any user with ID " + id);
		}
	}
	

	public void sendUserNotification(User user, String userStatus, String reason) throws MessagingException, UnsupportedEncodingException {
		
		EmailSettingBag emailSettings = settingService.getAllEmailSettings();
		
		JavaMailSenderImpl mailSender = Utility.prepareMailSender(emailSettings);
		
		mailSender.setDefaultEncoding("utf-8");

		String toAddress = user.getEmail();
		
		String subject = emailSettings.getSuspensionConfirmationSubject();
		
		subject = subject.replace("[[name]]", user.getFullName());
		
		String content = emailSettings.getSuspensionConfirmationContent();
		   
		MimeMessage message = mailSender.createMimeMessage();
		
		MimeMessageHelper helper = new MimeMessageHelper(message);
		
		helper.setFrom(emailSettings.getFromAddress(), emailSettings.getSenderName());
		
		helper.setSubject(subject);
		
		helper.setTo(toAddress);	
			
		content = content.replace("[[name]]", user.getFullName());
		
		content = content.replace("[[status]]", userStatus);
		
		content = content.replace("[[reason]]", reason);
		
		helper.setText(content, true);
		
		mailSender.send(message);	
		
	}
	
	public void delete(Integer id) throws UserNotFoundException {
		
		Long countById = userRepository.countByuserID(id);
		
		if (countById == null || countById == 0) {
			
			throw new UserNotFoundException("Could not find any user with ID " + id);
			
		}
		
		userRepository.deleteById(id);
	}
	
	private void encodePassword(User user) {
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);		
	}
}
