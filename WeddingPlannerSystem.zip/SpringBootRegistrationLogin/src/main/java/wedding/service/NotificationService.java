package wedding.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import wedding.model.Notification;
import wedding.model.Sales;
import wedding.model.User;
import wedding.repo.NotificationRepository;
import wedding.repo.SalesRepository;
import wedding.repo.UserRepository;

@Service
@Transactional
public class NotificationService {
	public static final int NOTIFICATION_PER_PAGE = 3;
	
	
	@Autowired private NotificationRepository nRepo;
	@Autowired private UserRepository uRepo;

	public Page<Notification> listByUserByPage(Integer id, User user2, String keyword, int pageNumber, 
			String sortChosenField, String sortDirection) {
		
		System.out.println("over here!");
		 
		Sort sortyBy = Sort.by(sortChosenField);
		
		sortyBy = sortDirection.equals("asc") ? sortyBy.ascending() : sortyBy.descending();
		
		Pageable pageable = PageRequest.of(pageNumber - 1, NOTIFICATION_PER_PAGE, sortyBy);
		
//		if (keyword != null) {
//			return nRepo.findByuserkeyword(user.getUserID(), keyword, pageable);
//		}
		System.out.println("it reaches here " + id + " " + user2.getUserID());
		
		
		
		User user = uRepo.findUserById(id);
		
		return nRepo.findByuser(id, user2.getUserID(), pageable);
	}

	public Page<User> listByNotificationListByPage(Integer userId, String keyWord, int pageNumber,
			String sortChosenField, String sortDirection) {
	
		System.out.println("over here!");
		 
		Sort sortyBy = Sort.by("user_id");
		
		sortyBy = sortDirection.equals("asc") ? sortyBy.ascending() : sortyBy.descending();
		
		Pageable pageable = PageRequest.of(pageNumber - 1, NOTIFICATION_PER_PAGE, sortyBy);
		
//		if (keyword != null) {
//			return nRepo.findByuserkeyword(user.getUserID(), keyword, pageable);
//		}
		System.out.println("it reaches here" + userId);
		
		User user = uRepo.findUserById(userId);
		
		List <Integer> id = new ArrayList<>();
		
		for(User u : user.getContacted()) {
			id.add(u.getUserID());
			System.out.println(u.getFirstName() + "<----------");
		}
		
//		if(user.getContacted().isEmpty()) {
//			return uRepo.findHelpByuser(id, pageable);
//		}
		List<User> listUser = uRepo.findAll();
		
		List<Integer> allUserId = new ArrayList<>();
		
		for(User u : listUser) {
			allUserId.add(u.getUserID());
		}
//		
		return uRepo.findHelpByuser(userId, pageable);
		
	}
	
}
