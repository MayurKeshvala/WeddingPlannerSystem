package wedding.service;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Sales;
import wedding.model.User;
import wedding.repo.QuestionRepository;
import wedding.repo.SalesRepository;

@Service
@Transactional
public class SalesService {
	public static final int SALES_PER_PAGE = 5;
	
	
	@Autowired private SalesRepository sRepo;
	

	
//	public Page<Sales> listByProduct(Product product, int pageNum, String sortField, String sortDir) {
//		Sort sort = Sort.by(sortField);
//		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending(); 
//		Pageable pageable = PageRequest.of(pageNum - 1, SALES_PER_PAGE, sort);
//		
//		return sRepo.findByProduct(product, pageable);
//	}
//	
	public Page<Sales> listByUserByPage(User user, String keyword, int pageNumber, 
			String sortChosenField, String sortDirection) {
		
		Sort sortyBy = Sort.by(sortChosenField);
		
		sortyBy = sortDirection.equals("asc") ? sortyBy.ascending() : sortyBy.descending();
		
		Pageable pageable = PageRequest.of(pageNumber - 1, SALES_PER_PAGE, sortyBy);
		
		if (keyword != null) {
			return sRepo.findByuser(user.getUserID(), keyword, pageable);
		}
		
		return sRepo.findByuser(user.getUserID(), pageable);
	}
	
}
