package wedding.utility;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

public class FileUploadUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadUtil.class);

	//Save the file
	public static void saveFile(String uploadDirectory, String fileName, MultipartFile multiFile) throws IOException {

		Path uploadFilePath = Paths.get(uploadDirectory);

		if (!Files.exists(uploadFilePath)) {

			Files.createDirectories(uploadFilePath);

		}

		try (InputStream inputFileStream = multiFile.getInputStream()) {

			Path filePath = uploadFilePath.resolve(fileName);
			
			Files.copy(inputFileStream, filePath, StandardCopyOption.REPLACE_EXISTING);

		} catch (IOException ex) {

			throw new IOException("Could not save file: " + fileName, ex);

		}
	}

	//Remove files inside directory 
	public static void cleanDirectory(String directory) {

		Path directoryPath = Paths.get(directory);

		try {

			Files.list(directoryPath).forEach(file -> {

				if (!Files.isDirectory(file)) {

					try {

						Files.delete(file);

					} catch (IOException ex) {

						LOGGER.error("Could not delete file: " + file);

					}

				}
				
			});
			
		} catch (IOException ex) {
			
			LOGGER.error("Could not list directory: " + directoryPath);
			
		}
		
	}

	//Remove directory
	public static void removeDirectory(String directory) {
		
		cleanDirectory(directory);

		try {
			
			Files.delete(Paths.get(directory));
			
		} catch (IOException e) {
			
			LOGGER.error("Could not remove directory: " + directory);
			
		}

	}
}
