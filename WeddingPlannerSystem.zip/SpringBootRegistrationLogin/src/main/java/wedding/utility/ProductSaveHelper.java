package wedding.utility;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import wedding.model.Product;
import wedding.model.ProductImage;


public class ProductSaveHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductSaveHelper.class);
	
	public static void deleteExtraImagesWeredRemovedOnForm(Product product) {
	
		String imageExtraDirectory = "../product-product-images/" + product.getId() + "/extras";
		
		Path directoryPath = Paths.get(imageExtraDirectory);
		
		try {
			
			Files.list(directoryPath).forEach(file -> {
			
				String filename = file.toFile().getName();
				
				if (!product.containsImageName(filename)) {
				
					try {
					
						Files.delete(file);
						
						LOGGER.info("Deleted extra image: " + filename);
						
					} catch (IOException e) {
	
						LOGGER.error("Could not delete extra image: " + filename);
					
					}
				
				}
				
			});
	
		} catch (IOException ex) {
		
			LOGGER.error("Could not list directory: " + directoryPath);
		
		}
	
	}

	public static void setExistingExtraImageNames(String[] idOfImage, String[] imageNames, 
			Product product) {
	
		if (idOfImage == null || idOfImage.length == 0) return;
		
		Set<ProductImage> productImages = new HashSet<>();
		
		for (int i = 0; i < idOfImage.length; i++) {
		
			Integer id = Integer.parseInt(idOfImage[i]);
			
			String name = imageNames[i];
			
			productImages.add(new ProductImage(id, name, product));
		
		}
		
		product.setImages(productImages);
		
	}

	public static void setProductDetails(String[] detailIDs, String[] detailNames, 
			String[] detailValues, Product product) {
	
		if (detailNames == null || detailNames.length == 0) return;
		
		for (int i = 0; i < detailNames.length; i++) {
		
			String name = detailNames[i];
			
			String value = detailValues[i];
			
			Integer id = Integer.parseInt(detailIDs[i]);
			
			if (id != 0) {
			
				product.addDetail(id, name, value);
			
			} else if (!name.isEmpty() && !value.isEmpty()) {
			
				product.addDetail(name, value);
			
			}
		
		}
	
	}

	public static void saveUploadedImages(MultipartFile mainImage, 
			MultipartFile[] imageExtras, Product savedProduct) throws IOException {
		
		System.out.println("something aint right..");
		
		if (!mainImage.isEmpty()) {
		
			String nameOfFile = StringUtils.cleanPath(mainImage.getOriginalFilename());
			
			String directoryUpload = "../product-images/" + savedProduct.getId();
			
			FileUploadUtil.cleanDirectory(directoryUpload);
			
			FileUploadUtil.saveFile(directoryUpload, nameOfFile, mainImage);		
		
		}
		
		if (imageExtras.length > 0) {
	
			String directoryUpload = "../product-images/" + savedProduct.getId() + "/extras";
			
			for (MultipartFile multiFile : imageExtras) {
			
				if (multiFile.isEmpty()) continue;
				
				String nameOfFile = StringUtils.cleanPath(multiFile.getOriginalFilename());
				
				FileUploadUtil.saveFile(directoryUpload, nameOfFile, multiFile);
			
			}
		
		}
		
	}

	public static void setNewExtraImageNames(MultipartFile[] imageExtras, Product product) {
		
		if (imageExtras.length > 0) {
		
			for (MultipartFile multiFile : imageExtras) {
			
				if (!multiFile.isEmpty()) {
				
					String nameOfFile = StringUtils.cleanPath(multiFile.getOriginalFilename());
					
					if (!product.containsImageName(nameOfFile)) {
	
						product.addExtraImage(nameOfFile);
					
					}

				}
			
			}
		
		}
	
	}

	public static void setMainImageName(MultipartFile mainImage, Product product) {
	
		if (!mainImage.isEmpty()) {
		
			String nameOfFile = StringUtils.cleanPath(mainImage.getOriginalFilename());
			
			product.setMainImage(nameOfFile);
		
		}
	}
}
