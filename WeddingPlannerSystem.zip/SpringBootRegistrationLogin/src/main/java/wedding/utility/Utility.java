package wedding.utility;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.security.authentication.RememberMeAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;

import wedding.model.CurrencySettingBag;
import wedding.model.EmailSettingBag;



public class Utility {
    public static String getSiteURL(HttpServletRequest request) {
        String siteURL = request.getRequestURL().toString();
        
        return siteURL.replace(request.getServletPath(), "");
        
    }
    
	
	public static JavaMailSenderImpl prepareMailSender(EmailSettingBag emailSettings) {
		JavaMailSenderImpl sendMail = new JavaMailSenderImpl();
		
		sendMail.setHost(emailSettings.getHost());
		
		sendMail.setPort(emailSettings.getPort());
		
		sendMail.setUsername(emailSettings.getUsername());
		
		sendMail.setPassword(emailSettings.getPassword());
		
		Properties properties = new Properties();
		
		properties.setProperty("mail.smtp.auth", emailSettings.getSmtpAuth());
		
		properties.setProperty("mail.smtp.starttls.enable", emailSettings.getSmtpSecured());
		
		sendMail.setJavaMailProperties(properties);
		
		return sendMail;
	}
	
	public static String formatCurrency(float amount, CurrencySettingBag emailSettings) {
		String symbol = emailSettings.getSymbol();
		
		int decimalDigits = emailSettings.getDecimalDigits();
		
		String decimalPointType = emailSettings.getDecimalPointType();
		
		String thousandPointType = emailSettings.getThousandPointType();
		
		String symbolPosition = emailSettings.getSymbolPosition();
		
		String currencyPattern = symbolPosition.equals("before") ? symbol : "";
		
		currencyPattern += "###,###";
		
		if (decimalDigits > 0) {
		
			currencyPattern += ".";
		
			for (int i = 1; i <= decimalDigits; i++) currencyPattern += "#";
		
		}
		
		currencyPattern += symbolPosition.equals("after") ? symbol : "";
		
		char thousandSeparator = thousandPointType.equals("POINT") ? '.' : ',';
		
		char decimalSeparator = decimalPointType.equals("POINT") ? '.' : ',';
		
		DecimalFormatSymbols dFS = DecimalFormatSymbols.getInstance();
		
		dFS.setDecimalSeparator(decimalSeparator);
		
		dFS.setGroupingSeparator(thousandSeparator);
		
		DecimalFormat formatter = new DecimalFormat(currencyPattern, dFS);
		
		return formatter.format(amount);
	}
}
