package wedding.input;

public class UserInput {

	private String email;

	private String snicode;
	
	public String getEmail() {
		
		return email;
		
	}

	public void setEmail(String email) {
		
		this.email = email;
		
	}

	public String getSnicode() {
		
		return snicode;
		
	}

	public void setSnicode(String snicode) {
		
		this.snicode = snicode;
		
	}

}
