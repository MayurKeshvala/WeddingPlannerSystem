package wedding.restcontroller;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sun.mail.iap.Response;

import wedding.model.Answer;
import wedding.model.Question;
import wedding.model.Suspension;
import wedding.model.User;
import wedding.repo.AnswerRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.SuspensionRepository;
import wedding.repo.UserRepository;
import wedding.service.UserService;
import wedding.utility.CustomUserDetails;

@RestController
public class UserSuspensionRestController {
	
	@Autowired
	private UserRepository uRepo;
	
	@Autowired
	private SuspensionRepository sRepo;

	@Autowired
	private UserService service;
	
	@PostMapping("/user/suspension")
	public List<String> confirmSuspension(Integer id, String headline, String reason, boolean status) throws UnsupportedEncodingException, MessagingException {
		
		
		Suspension suspension = new Suspension();
		
		User user = uRepo.findUserById(id);
	
		
		
		suspension.setHeading(headline);
		
		suspension.setUser(user);
		
		suspension.setReason(reason);
		
		suspension.setUser(user);
		
		
		
		LocalDate localDate = LocalDate.now();
		
		suspension.setDateTime(localDate);
		
		sRepo.save(suspension);
		
		user.setSuspension(suspension);
		
		uRepo.save(user);
		
		String userStatus = "suspended";
				
		service.sendUserNotification(user, userStatus, reason);
		
		service.updateUserEnabledStatus(id, status);
		
		List<String> response =  new ArrayList<String>();
		
		String addStatus = null;
		if(status == true) {
			addStatus = "true";
		}
		
		if(status == false) {
			addStatus = "false";
		}
		
		response.add(id.toString());
		response.add(addStatus);

		
		return response;
		
	}	
	
}
