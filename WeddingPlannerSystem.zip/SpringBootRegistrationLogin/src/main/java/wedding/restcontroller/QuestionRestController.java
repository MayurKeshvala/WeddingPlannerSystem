package wedding.restcontroller;

import java.util.Date;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import wedding.model.Answer;
import wedding.model.Question;
import wedding.model.User;
import wedding.repo.AnswerRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.UserRepository;
import wedding.utility.CustomUserDetails;

@RestController
public class QuestionRestController {
	
	@Autowired
	private UserRepository uRepo;
	
	@Autowired
	private AnswerRepository aRepo;
	
	@Autowired
	private QuestionRepository qRepo;
	
	@PostMapping("/question/add_comment")
	public String addComment(Integer id, String comment, String url, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		System.out.println("it reaches here");
		System.out.println(id);
		System.out.println(comment);
		Question question = qRepo.findQuestionById(id);
		Answer answer = new Answer();
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		answer.setAnswer(comment);
		answer.setAnswerDate(new Date());
		answer.setUser(user);
		answer.setQuestion(question);
		aRepo.save(answer);
		
		

		Set<Answer> answerSet = question.getAnswer();
		answerSet.add(answer);
		question.setAnswer(answerSet);
		qRepo.save(question);
		System.out.println(question.getAnswer());
		for(Answer answers : question.getAnswer()) {
			System.out.println(answers);
			System.out.println(answers.getAnswer());
			System.out.println(answers.getAnswerDate());
			System.out.println(answers.getUser().getFullName());
		}
		
		return "OK";
		
	}	
	
	@PostMapping("/answer/add_comment")
	public String addSubComment(Integer id, String comment, Integer qId, String url, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		System.out.println("it reaches here");
		System.out.println(id);
		System.out.println(comment);
		Answer answer = aRepo.findAnswerById(id);
		Answer answers = new Answer();
		
		
		User user = uRepo.findUserById(userDetails.getUserId());
		Question question = qRepo.findQuestionById(qId);
		
		answers.setAnswer(comment);
		answers.setAnswerDate(new Date());
		answers.setUser(user);
		answers.setParentAnswer(answer);
		answers.setQuestion(question);
		
		aRepo.save(answers);
		
		Set<Answer> answerSet = answer.getSubAnswer();
		answerSet.add(answers);
		answer.setSubAnswer(answerSet);
		aRepo.save(answer);

		
//		answerSet.add(answer);
//		question.setAnswer(answerSet);
//		qRepo.save(question);
//		System.out.println(question.getAnswer());
//		for(Answer answers : question.getAnswer()) {
//			System.out.println(answers);
//			System.out.println(answers.getAnswer());
//			System.out.println(answers.getAnswerDate());
//			System.out.println(answers.getUser().getFullName());
//		}
		
		return "OK";
		
	}	
}
