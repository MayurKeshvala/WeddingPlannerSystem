package wedding.restcontroller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


import wedding.exception.ShoppingCartException;
import wedding.exception.UserNotFoundException;
import wedding.model.User;
import wedding.repo.UserRepository;
import wedding.service.ShoppingCartService;
import wedding.service.UserService;
import wedding.utility.CustomUserDetails;
import wedding.utility.Utility;

@RestController
public class ShoppingCartRestController {
	
	@Autowired 
	private ShoppingCartService cService;
	
	@Autowired 
	private UserRepository uRepo;
	
	
	@PostMapping("/cart/add/{productId}/{quantity}")
	public String addProductToCart(@PathVariable("productId") Integer productId,@PathVariable("quantity") Integer quantity, @AuthenticationPrincipal CustomUserDetails userDetails) throws UserNotFoundException {
		
		try {
			
			User user = uRepo.getUserByEmail(userDetails.getEmail());
			
			Integer updatedQuantity = cService.addUserProduct(productId, quantity, user);
			
			return updatedQuantity + " item(s) of this product were added to your shopping cart.";
		
		} catch (ShoppingCartException ex) {
			
			return ex.getMessage();
			
		}
		
	}
	
	@PostMapping("/cart/addService/{productId}/{date}")
	public String addServiceToCart(@PathVariable("productId") Integer productId, @PathVariable("date") String date, @AuthenticationPrincipal CustomUserDetails userDetails) throws UserNotFoundException, ShoppingCartException {
		
//		String newDate = date.replaceAll("-", "/");
		
			User user = uRepo.getUserByEmail(userDetails.getEmail());
			
		
			System.out.println("goes wrong here" + date);
			
				String productName = cService.addService(productId, date, user);
				
				if (productName == null) {
					return "You have already added this service, with the same date, to your shopping cart";
				}
				List<String> returnItem = new ArrayList<String>();
				
				returnItem.add(date);
				
				String message =  " " + productName + " was added to your shopping cart.";
				
				System.out.println(date);
				
				returnItem.add(message);
				
				return message;
				
			
	
	}
	
	@PostMapping("/cart/update/{productId}/{quantity}")
	public String updateProductQuantity(@PathVariable("productId") Integer productId, @PathVariable("quantity") Integer quantity, @AuthenticationPrincipal CustomUserDetails userDetails) throws UserNotFoundException {
		
		User user = uRepo.getUserByEmail(userDetails.getEmail());
		
		double subtotal = cService.updateQuantity(productId, quantity, user);
		
		return String.valueOf(subtotal);	
	}
	
	@DeleteMapping("/cart/remove/{productId}")
	public String removeUserProduct(@PathVariable("productId") Integer productId,
			HttpServletRequest request, @AuthenticationPrincipal CustomUserDetails userDetails) throws UserNotFoundException {

		System.out.println("reaches here");
		
		Integer user = userDetails.getUserId();
		
		cService.removeUserProduct(productId, user);
		
		return "You have removed the productfrom your shopping cart.";
	}

}

