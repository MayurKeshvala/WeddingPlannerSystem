package wedding.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import wedding.dto.EmailDto;
import wedding.input.UserInput;
import wedding.service.UserService;


@RestController
public class UserRestController {

	@Autowired
	private UserService userService;

	@PostMapping("/registers")
	public ResponseEntity<EmailDto> getUserByEmail(@RequestBody UserInput userInput) {
		
		EmailDto emailDto = userService.getUserByEmail(userInput.getEmail());

		return new ResponseEntity<EmailDto>(emailDto, HttpStatus.OK);
		
	}
	
}
