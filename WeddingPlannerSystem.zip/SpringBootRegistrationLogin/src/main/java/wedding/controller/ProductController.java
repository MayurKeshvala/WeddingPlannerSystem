package wedding.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.util.Strings;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import wedding.exception.ProductNotFoundException;
import wedding.exception.UserNotFoundException;
import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.CurrencySettingBag;
import wedding.model.DateRangeValidator;
import wedding.model.GeoCoder;
import wedding.model.GeocodeResponse;
import wedding.model.OrderDetail;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Roles;
import wedding.model.Setting;
import wedding.model.SettingBag;
import wedding.model.ShippingRate;
import wedding.model.User;
import wedding.repo.CartItemRepository;
import wedding.repo.CategoryRepository;
import wedding.repo.OrderDetailRepository;
import wedding.repo.OrderRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.ReviewRepository;
import wedding.repo.ShippingRateRepository;
import wedding.repo.UserRepository;
import wedding.service.ProductService;
import wedding.service.ReviewService;
import wedding.service.SettingService;
import wedding.service.ShippingRateService;
import wedding.service.UserService;
import wedding.utility.CustomUserDetails;
import wedding.utility.FileUploadUtil;
import wedding.utility.ProductSaveHelper;

@Controller
public class ProductController {
	
	@Autowired private ProductService productService;
	@Autowired private UserService userService;
	@Autowired private CategoryRepository cRepo;
	@Autowired private ProductRepository pRepo;
	@Autowired private ShippingRateService srService;
	@Autowired private ShippingRateRepository srRepo;
	@Autowired private UserRepository uRepo;
	@Autowired private ReviewService reviewService;
	@Autowired private QuestionRepository qRepo;
	@Autowired private SettingService setService;
	@Autowired private OrderDetailRepository oRepo;
	@Autowired private CartItemRepository cartRepo;
	@Autowired private ReviewRepository rRepo;
	
	@GetMapping("/c/{id}")
	public String listProductByCatFirstPage(Model model, @PathVariable("id") Integer id) throws UserNotFoundException {
		
		return listProductByCatPage(id, 1, model, "name", "asc", null, 0);
		
	}
	
	@GetMapping("/c/{id}/page_number/{pageNum}")
	public String listProductByCatPage(Integer id,
			@PathVariable(name = "pageNum") int pageNum, Model model,
			@Param("sortChosenField") String sortChosenField, @Param("sortDirection") String sortDirection,
			@Param("keyWord") String keyWord,
			@Param("categoryId") Integer categoryId
			) throws UserNotFoundException {
		
		Page<Product> page = productService.listByPageCustomer(pageNum, sortChosenField, sortDirection, keyWord, categoryId, id);
		
		List<Product> listProducts = page.getContent();
		
		Iterable<Category> listCategory = cRepo.findAll();
		
		long startOfCount = (pageNum - 1) * ProductService.PRODUCTS_PER_PAGE + 1;
		
		long endOfCount = startOfCount + ProductService.PRODUCTS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		if (categoryId != null) model.addAttribute("categoryId", categoryId); 
			
		boolean dateCheck = false;
		
		for(Category c : listCategory) {
			
			if(c.getId() == id && c.isService() == true) {
				
				dateCheck = true;
				
			} else {
				
				dateCheck = false;
				
			}
		}
		
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		model.addAttribute("currency", currency);
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("keyWord", keyWord);		
		model.addAttribute("listProducts", listProducts);
		model.addAttribute("listCategory", listCategory);		
		model.addAttribute("categoryIdNull", id);
		model.addAttribute("serviceCheck", dateCheck);
		model.addAttribute("URL", "/customer_products");
		
		return "customer/products_by_cat";		
	}
	
	@GetMapping("/customer_products")
	public String listForCustomersByPage(Model model) throws JsonSyntaxException, JsonIOException, MalformedURLException, IOException {
		
		return listForCustomersByPage(1, model, "name", "asc", null, 0, null, null, null, null, null, null);
		
	}
	
	@GetMapping("/customer_products/page_number/{pageNum}")
	public String listForCustomersByPage(
			@PathVariable(name = "pageNum") int pageNum, Model model,
			@Param("sortChosenField") String sortChosenField, @Param("sortDirection") String sortDirection,
			@Param("keyWord") String keyWord,
			@Param("categoryId") Integer categoryId,
			@Param("serviceDate") String serviceDate,
			@Param("serviceDate2") String serviceDate2,
			@Param("fromPrice") Double fromPrice,
			@Param("toPrice") Double toPrice,
			@Param("location") String location,
			@Param("miles") Double miles
			) throws JsonSyntaxException, JsonIOException, MalformedURLException, IOException{

		List<Integer> viableVenue = new ArrayList<>();
		
		viableVenue.add(0);
		
System.out.println(Strings.isNotEmpty("hello"));
	System.out.println("+" + location + "+");
if(Strings.isNotEmpty(location) == true) {	
	
	System.out.println("it went through but why?");

    final int R = 6371;	
	//user's Location
	Gson gson = new Gson();
		
GeocodeResponse res = new GeocodeResponse();

GeoCoder geo = new GeoCoder();

res = geo.getLocation(location);

String result = gson.toJson(res);

JSONObject json = new JSONObject(result); 

JSONArray jsonArray = json.getJSONArray("results");  

JSONObject resultArray = jsonArray.getJSONObject(0).getJSONObject("geometry").getJSONObject("location");


double userLat = ((BigDecimal) resultArray.get("lat")).doubleValue();

double userLng = ((BigDecimal) resultArray.get("lng")).doubleValue();

System.out.println(userLat + " and " + userLng);


List<Product> productServiceList = pRepo.listService();


for(Product p : productServiceList) {
	
//Venue Location
Gson gson2 = new Gson();

GeocodeResponse res2 = new GeocodeResponse();

GeoCoder geo2 = new GeoCoder();

res2 = geo2.getLocation(p.getAddress());

String result2 = gson2.toJson(res2);

JSONObject json2 = new JSONObject(result2); 

JSONArray jsonArray2 = json2.getJSONArray("results");  

JSONObject resultArray2 = jsonArray2.getJSONObject(0).getJSONObject("geometry").getJSONObject("location");

double venueLng = ((BigDecimal) resultArray2.get("lng")).doubleValue();

double venueLat = ((BigDecimal) resultArray2.get("lat")).doubleValue();

System.out.println(venueLat + " and " + venueLng);

Double latDistance = toRad(venueLat-userLat);

Double lonDistance = toRad(venueLng-userLng);

Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + 
Math.cos(toRad(userLat)) * Math.cos(toRad(venueLat)) * 
Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
Double distance = R * c;

System.out.println(distance);
//distance = (distance/1.609)/100;

if(distance <= miles) {
	viableVenue.add(p.getId());
}
System.out.println(viableVenue);
}
}
		
		System.out.println("MAYOOOOOOOOOOO" + serviceDate);
		List <Integer> idList = new ArrayList<Integer>();
		
		if(serviceDate != null && serviceDate2 != null) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	      Date startDate;
	      
		try {
			startDate = sdf.parse(serviceDate);
			  Date endDate = sdf.parse(serviceDate2);
			  System.out.println("startDate : " + sdf.format(startDate));
			  System.out.println("endDate : " + sdf.format(endDate));
		      DateRangeValidator checker = new DateRangeValidator(startDate, endDate);

//		      Date testDate = sdf.parse("2022-05-14");
		      Iterable<Product> product = pRepo.findAll();
		      for(Product p : product) {
		    	  if(p.isService() == true) {
		    	  for(String date : p.getDate()) {
		    		 Date testDate = sdf.parse(date);  
		    		  if(checker.isWithinRange(testDate)){
		    			  idList.add(p.getId());
				          System.out.println(idList);

				          System.out.println("testDate is within the date range.");
				          System.out.println(startDate + "-" + testDate + "-" + endDate);
				      }else{
				          System.out.println("testDate is NOT within the date range.");
				          System.out.println(startDate + "-" + testDate + "-" + endDate);
				      }
		    	  }
		    	 
		      }
		      }
//		      System.out.println("testDate : " + sdf.format(testDate));
//
//		      if(checker.isWithinRange(testDate)){
//		          System.out.println("testDate is within the date range.");
//		      }else{
//		          System.out.println("testDate is NOT within the date range.");
//		      }
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}

	      

	
		
		if(serviceDate == "") {
			System.out.println("INTERESTING");
			serviceDate = null;
		}
		
		if(serviceDate == null) {
			System.out.println("SASHHHIII");
		}
		
		if(serviceDate != null) {
			System.out.println("REENNNAAAA");
		}
//		String newstring = null;
//		
//		if(serviceDate != null) {
//			
//		Date date;
//		
//		try {
//			
//			date = new SimpleDateFormat("yyyy-MM-dd").parse(serviceDate);
//			
//			newstring = new SimpleDateFormat("dd/MM/yyyy").format(date);
//			
//			System.out.println(newstring);
//			
//		} catch (ParseException e) {
//
//			e.printStackTrace();
//			
//		}
//
//		}
//		
//		System.out.println(minBudget);
		
		Page<Product> page = productService.listByPageCustomer(pageNum, sortChosenField, sortDirection, keyWord, categoryId, serviceDate, serviceDate2, idList, fromPrice, toPrice, viableVenue);
		
		List<Product> listProducts = page.getContent();
		
		Iterable<Product> checkService = pRepo.findAll();
		
		boolean dateCheck = false;
		
		for(Product e : checkService) {
			
			if(e.isService()) {
				
				dateCheck = true;
				System.out.println("it be true");
			} else {
				
				dateCheck = false;
				System.out.println("it be false");
			}
			
		}
		
		Iterable<Category> listCategory = cRepo.findAll();
		
		long startOfCount = (pageNum - 1) * ProductService.PRODUCTS_PER_PAGE + 1;
		
		long endOfCount = startOfCount + ProductService.PRODUCTS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		for(Category c : listCategory) {
			
			if(c.getId() == categoryId && c.isService() == true) {
				
				dateCheck = true;
				
			} else {
				
				dateCheck = false;
				
			}
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		if (categoryId != null) model.addAttribute("categoryId", categoryId); 
			
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		model.addAttribute("location", location);
		model.addAttribute("miles", miles);
		model.addAttribute("fromPrice", fromPrice);
		model.addAttribute("toPrice", toPrice);
		model.addAttribute("serviceDate2", serviceDate2);
		model.addAttribute("serviceDate", serviceDate);
		model.addAttribute("currency", currency);
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("keyWord", keyWord);		
		model.addAttribute("listProducts", listProducts);
		model.addAttribute("listCategory", listCategory);		
		model.addAttribute("categoryIdNull", categoryId);
		model.addAttribute("serviceCheck", dateCheck);
		model.addAttribute("URL", "/customer_products");
		
		return "customer/products";		
	}
	
	 private static Double toRad(Double value) {
		 return value * Math.PI / 180;
		 }
	
	
	@GetMapping("/p/{id}")
	public String viewProductDetail(@PathVariable("id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, Model model) throws ProductNotFoundException {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Product product = pRepo.findByProductId(id);
		
		
		boolean customerReviewed = reviewService.diduserReviewProduct(user, product.getId());
		
		if (customerReviewed) {
		
			model.addAttribute("customerReviewed", customerReviewed);
			
		} else {
			
			boolean customerCanReview = reviewService.canUserReviewProduct(user, product.getId());
			
			model.addAttribute("customerCanReview", customerCanReview);
			
		}
		
		long numberOfQuestions = qRepo.countAllQuestionsById(id);
		
		Iterable<Category> listCategory = cRepo.findAll();
		
		CurrencySettingBag currency = setService.getAllCurrencySettings();
	

		
		model.addAttribute("listCategory", listCategory);
		model.addAttribute("product", product);
		model.addAttribute("pageTitle", product.getShortName());
		model.addAttribute("URL", "/customer_products");
		model.addAttribute("sortChosenField", "name");
		model.addAttribute("numberOfQuestions", numberOfQuestions);
		model.addAttribute("sortDirection", "asc");
		model.addAttribute("currency", currency);
		
		return "customer/product_detail";
	}
	
//	@GetMapping("/search")
//	public String searchFirstPage(String keyWord, Model model) {
//		
//		return searchByPage(keyWord, 1, model);
//		
//	}
//	
//	@GetMapping("/search/page_number/{pageNum}")
//	public String searchByPage(String keyWord, @PathVariable("pageNum") int pageNum, Model model) {
//		
//		Page<Product> pageProducts = productService.search(keyWord, pageNum);
//		
//		List<Product> listResult = pageProducts.getContent();
//		
//		long startOfCount = (pageNum - 1) * ProductService.SEARCH_RESULTS_PER_PAGE + 1;
//		
//		long endOfCount = startOfCount + ProductService.SEARCH_RESULTS_PER_PAGE - 1;
//		
//		if (endOfCount > pageProducts.getTotalElements()) {
//			
//			endOfCount = pageProducts.getTotalElements();
//			
//		}
//		
//		model.addAttribute("currentPageNumber", pageNum);
//		model.addAttribute("totalNumPages", pageProducts.getTotalPages());
//		model.addAttribute("startOfCount", startOfCount);
//		model.addAttribute("endOfCount", endOfCount);
//		model.addAttribute("totalNumItems", pageProducts.getTotalElements());
//		model.addAttribute("pageTitle", keyWord + " - Search Result");
//		model.addAttribute("keyWord", keyWord);
//		model.addAttribute("searchKeyword", keyWord);
//		model.addAttribute("listResult", listResult);
//		
//		return "customer/search_result";
//	}		

	
	@GetMapping("/products")
	public String listFirstPage(Model model) {
		
		return listByPage(1, model, "name", "asc", null, 0);
		
	}
	
	@GetMapping("/products/page_number/{pageNum}")
	public String listByPage(
			@PathVariable(name = "pageNum") int pageNum, Model model,
			@Param("sortChosenField") String sortChosenField, @Param("sortDirection") String sortDirection,
			@Param("keyWord") String keyWord,
			@Param("categoryId") Integer categoryId
			) {
		
		Page<Product> page = productService.listByPageAdmin(pageNum, sortChosenField, sortDirection, keyWord, categoryId);
		
		List<Product> listProducts = page.getContent();
		
		Iterable<Category> listCategory = cRepo.findAll();
		
		long startOfCount = (pageNum - 1) * ProductService.PRODUCTS_PER_PAGE + 1;
		
		long endOfCount = startOfCount + ProductService.PRODUCTS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		if (categoryId != null) model.addAttribute("categoryId", categoryId); 
			
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("keyWord", keyWord);		
		model.addAttribute("listProducts", listProducts);
		model.addAttribute("listCategory", listCategory);		
		model.addAttribute("URL", "/products");
		model.addAttribute("nameOfEntity", "Product");
		
		return "admin/products";		
	}
	
	@GetMapping("/user_products")
	public String listFirstPageUser(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) throws UserNotFoundException {
		
		return listByPageUser(userDetails, 1, model, "name", "asc", null, 0);
		
	}
	
	@GetMapping("/user_products/page_number/{pageNum}")
	public String listByPageUser(@AuthenticationPrincipal CustomUserDetails userDetails,
			@PathVariable(name = "pageNum") int pageNum, Model model,
			@Param("sortChosenField") String sortChosenField, @Param("sortDirection") String sortDirection,
			@Param("keyWord") String keyWord,
			@Param("categoryId") Integer categoryId
			) throws UserNotFoundException {
		
		Integer ide = userDetails.getUserId();
		
		Page<Product> page = productService.listByPageUser(pageNum, sortChosenField, sortDirection, keyWord, categoryId, ide);
		
		List<Product> listProducts = page.getContent();
		
		Iterable<Category> listCategory = cRepo.findAll();
		
		long startOfCount = (pageNum - 1) * ProductService.PRODUCTS_PER_PAGE + 1;
		
		long endOfCount = startOfCount + ProductService.PRODUCTS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		if (categoryId != null) model.addAttribute("categoryId", categoryId); 
	
		boolean dateCheck = false;
		
		for(Category c : listCategory) {
			
			if(c.getId() == categoryId && c.isService() == true) {
				
				dateCheck = true;
				
			} else {
				
				dateCheck = false;
				
			}
		}	
		
		
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("keyWord", keyWord);		
		model.addAttribute("listProducts", listProducts);
		model.addAttribute("listCategory", listCategory);	
		model.addAttribute("categoryIdNull", categoryId);
		model.addAttribute("serviceCheck", dateCheck);
		model.addAttribute("URL", "/user_products");
		model.addAttribute("nameOfEntity", "Product");
		
		
		return "supplier/products";	
		
	}
	
	
//	@GetMapping("/products/new")
//	public String newProduct(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
//		
//		Iterable<Category> listCategory = cRepo.findAll();
//		
//		Product product = new Product();
//		
//		product.setEnabled(true);
//		
//		product.setInStock(true);
//		
//		
//		model.addAttribute("product", product);
//		model.addAttribute("userId", userDetails.getUserId());
//		model.addAttribute("listCategory", listCategory);
//		model.addAttribute("numberOfExistingExtraImages", 0);
//		
//		return "admin/product_form";
//	}
	
	//used by supplier and admin to create product
	@GetMapping("/products_supplier/new")
	public String newSupplierProduct(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		Iterable<Category> listCategory = cRepo.findAllByProduct();
		
		Product product = new Product();
		
		product.setEnabled(true);
		
		product.setInStock(true);
				
		User user = uRepo.findUserById(userDetails.getUserId());
		
		model.addAttribute("product", product);
		model.addAttribute("manageType", "Product");
		model.addAttribute("userId", userDetails.getUserId());
		model.addAttribute("role", user.hasRole("Admin"));
		model.addAttribute("listCategory", listCategory);
		model.addAttribute("numberOfExistingExtraImages", 0);
		
		return "supplier/product_form";
	}
	
	//used by supplier and admin to create product
	@GetMapping("/products_supplier/new_service")
	public String newSupplierService(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		Iterable<Category> listCategory = cRepo.findAllByService();
		
		Product product = new Product();
		
		product.setEnabled(true);
		
		product.setInStock(true);
		
		product.setService(true);
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		model.addAttribute("role", user.hasRole("Admin"));
		model.addAttribute("product", product);
		model.addAttribute("manageType", "Service");
		model.addAttribute("userId", userDetails.getUserId());
		model.addAttribute("listCategory", listCategory);
		model.addAttribute("numberOfExistingExtraImages", 0);
		
		return "supplier/product_form_service";
	}
	
	private static final int DIM_DIVISOR = 139;
	
	@PostMapping("/products/save/{id}")
	public String saveProduct(Product product, RedirectAttributes ra,
			@PathVariable(name = "id") int id,
			@RequestParam(value = "fileImage", required = false) MultipartFile mainImageMultipart,			
			@RequestParam(value = "extraImage", required = false) MultipartFile[] extraImageMultiparts,
			@RequestParam(name = "detailIDs", required = false) String[] detailIDs,
			@RequestParam(name = "detailNames", required = false) String[] detailNames,
			@RequestParam(name = "detailValues", required = false) String[] detailValues,
			@RequestParam(name = "imageIDs", required = false) String[] imageIDs,
			@RequestParam(name = "imageNames", required = false) String[] imageNames, @AuthenticationPrincipal CustomUserDetails userDetails
			) throws IOException, UserNotFoundException {

		
		ProductSaveHelper.setMainImageName(mainImageMultipart, product);
		
		ProductSaveHelper.setExistingExtraImageNames(imageIDs, imageNames, product);
		
		ProductSaveHelper.setNewExtraImageNames(extraImageMultiparts, product);
		
		ProductSaveHelper.setProductDetails(detailIDs, detailNames, detailValues, product);
		
		float dimWeight = (product.getLength() * product.getWidth() * product.getHeight()) / DIM_DIVISOR;
		
		product.setDimWeight(dimWeight);
		
		float finalWeight = product.getWeight() > dimWeight ? product.getWeight() : dimWeight;
		
		Iterable<ShippingRate> allshippingRate = srRepo.findAll();
		
		for (ShippingRate s : allshippingRate) {
			
			if (finalWeight <= s.getWeight()) {
				
				System.out.println(finalWeight + "is less than or equal to" + s.getWeight());
				
				product.setShippingrate(s);
				
				break;
				
			} else {
				
				ShippingRate ships = srService.getShippingRateById(3);
				
				product.setShippingrate(ships);
				
			}
			
		}
		
		User user = uRepo.findUserById(id);
		
		product.setUser(user);
		
		product.setService(false);
		
		product.setEnabled(true);
		
		Product savedProduct = productService.save(product);
		
		ProductSaveHelper.saveUploadedImages(mainImageMultipart, extraImageMultiparts, savedProduct);
		
		ProductSaveHelper.deleteExtraImagesWeredRemovedOnForm(product);
		
		System.out.println(product.getDate());
		
		ra.addFlashAttribute("message", "The product has been saved successfully.");
		
		if(user.hasRole("Supplier")) {
		return "redirect:/user_products";
		}
		return "redirect:/products";
	}

	@PostMapping("/products/save_service/{id}")
	public String saveService(Product product, RedirectAttributes ra,
			@PathVariable(name = "id") int id,
			@RequestParam(value = "fileImage", required = false) MultipartFile mainImageMultipart,			
			@RequestParam(value = "extraImage", required = false) MultipartFile[] extraImageMultiparts,
			@RequestParam(name = "detailIDs", required = false) String[] detailIDs,
			@RequestParam(name = "detailNames", required = false) String[] detailNames,
			@RequestParam(name = "detailValues", required = false) String[] detailValues,
			@RequestParam(name = "imageIDs", required = false) String[] imageIDs,
			@RequestParam(name = "imageNames", required = false) String[] imageNames, @AuthenticationPrincipal CustomUserDetails userDetails
			) throws IOException, UserNotFoundException {

		
		ProductSaveHelper.setMainImageName(mainImageMultipart, product);
		
		ProductSaveHelper.setExistingExtraImageNames(imageIDs, imageNames, product);
		
		ProductSaveHelper.setNewExtraImageNames(extraImageMultiparts, product);
		
		ProductSaveHelper.setProductDetails(detailIDs, detailNames, detailValues, product);
		
		User user = uRepo.findUserById(id);
		
		product.setUser(user);
		
		product.setService(true);
		
		product.setEnabled(true);
		
		Product savedProduct = productService.save(product);
		
		ProductSaveHelper.saveUploadedImages(mainImageMultipart, extraImageMultiparts, savedProduct);
		
		ProductSaveHelper.deleteExtraImagesWeredRemovedOnForm(product);
		
		System.out.println(product.getDate());
		
		ra.addFlashAttribute("message", "The product has been saved successfully.");
		
		if(user.hasRole("Supplier")) {
		return "redirect:/user_products";
		}
		return "redirect:/products";
	}
	
//	@PostMapping("/admin/save_service/{id}")
//	public String saveAdminService(Product product, RedirectAttributes ra,
//			@PathVariable(name = "id") int id,
//			@RequestParam(value = "fileImage", required = false) MultipartFile mainImageMultipart,			
//			@RequestParam(value = "extraImage", required = false) MultipartFile[] extraImageMultiparts,
//			@RequestParam(name = "detailIDs", required = false) String[] detailIDs,
//			@RequestParam(name = "detailNames", required = false) String[] detailNames,
//			@RequestParam(name = "detailValues", required = false) String[] detailValues,
//			@RequestParam(name = "imageIDs", required = false) String[] imageIDs,
//			@RequestParam(name = "imageNames", required = false) String[] imageNames, @AuthenticationPrincipal CustomUserDetails userDetails
//			) throws IOException, UserNotFoundException {
//
//		
//		ProductSaveHelper.setMainImageName(mainImageMultipart, product);
//		
//		ProductSaveHelper.setExistingExtraImageNames(imageIDs, imageNames, product);
//		
//		ProductSaveHelper.setNewExtraImageNames(extraImageMultiparts, product);
//		
//		ProductSaveHelper.setProductDetails(detailIDs, detailNames, detailValues, product);
//		
//		User user = uRepo.findUserById(id);
//		
//		product.setUser(user);
//		
//		product.setService(true);
//		
//		product.setEnabled(true);
//		
//		Product savedProduct = productService.save(product);
//		
//		ProductSaveHelper.saveUploadedImages(mainImageMultipart, extraImageMultiparts, savedProduct);
//		
//		ProductSaveHelper.deleteExtraImagesWeredRemovedOnForm(product);
//		
//		System.out.println(product.getDate());
//		
//		ra.addFlashAttribute("message", "The product has been saved successfully.");
//		
//		return "redirect:/products";
//	}
	
	@PostMapping("/admin/product/{id}")
	public String saveAdminProduct(Product product, RedirectAttributes ra,
			@PathVariable(name = "id") int id,
			@RequestParam(value = "fileImage", required = false) MultipartFile mainImageMultipart,			
			@RequestParam(value = "extraImage", required = false) MultipartFile[] extraImageMultiparts,
			@RequestParam(name = "detailIDs", required = false) String[] detailIDs,
			@RequestParam(name = "detailNames", required = false) String[] detailNames,
			@RequestParam(name = "detailValues", required = false) String[] detailValues,
			@RequestParam(name = "imageIDs", required = false) String[] imageIDs,
			@RequestParam(name = "imageNames", required = false) String[] imageNames, @AuthenticationPrincipal CustomUserDetails userDetails
			) throws IOException, UserNotFoundException {

		
		ProductSaveHelper.setMainImageName(mainImageMultipart, product);
		
		ProductSaveHelper.setExistingExtraImageNames(imageIDs, imageNames, product);
		
		ProductSaveHelper.setNewExtraImageNames(extraImageMultiparts, product);
		
		ProductSaveHelper.setProductDetails(detailIDs, detailNames, detailValues, product);
		
		User user = uRepo.findUserById(id);
		
		product.setUser(user);
		
		product.setService(false);
		
		product.setEnabled(true);
		
		Product savedProduct = productService.save(product);
		
		ProductSaveHelper.saveUploadedImages(mainImageMultipart, extraImageMultiparts, savedProduct);
		
		ProductSaveHelper.deleteExtraImagesWeredRemovedOnForm(product);
		
		System.out.println(product.getDate());
		
		ra.addFlashAttribute("message", "The product has been saved successfully.");
		
		return "redirect:/products";
	}
	
	@GetMapping("/products/{id}/enabled/{status}")
	public String updateProductEnabledStatus(@PathVariable("id") Integer id,
			@PathVariable("status") boolean enabled, RedirectAttributes redirect) {

		Product product = pRepo.findByProductId(id);
		
		product.setEnabled(enabled);
		
		pRepo.save(product);

		String status = enabled ? "enabled" : "disabled";
		
		String message = "The Product ID " + id + " has been " + status;
		
		redirect.addFlashAttribute("message", message);
		
		return "redirect:/products";
	}
	
	
//	@GetMapping("/user_products/delete/{id}")
//	public String deleteUserProduct(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirect) {
//		
//		try {
//			
//			productService.delete(id);
//			
//			String extraimagesProductDirectoryectory = "../product-images/" + id + "/extras";
//			
//			String imagesProductDirectory = "../product-images/" + id;
//			
//			FileUploadUtil.removeDirectory(extraimagesProductDirectoryectory);
//			
//			FileUploadUtil.removeDirectory(imagesProductDirectory);
//			
//			redirect.addFlashAttribute("message", "The product ID " + id + " has been deleted successfully");
//		
//		} catch (ProductNotFoundException ex) {
//			
//			redirect.addFlashAttribute("message", ex.getMessage());
//			
//		}
//		
//		return "redirect:/user_products";
//	}
	
	
//	@GetMapping("/user_products/edit/{id}")
//	public String editUserProduct(@PathVariable("id") Integer id, Model model, RedirectAttributes ra) {
//		
//		try {
//			
//			Iterable<Category> listCategory = cRepo.findAll();
//			
//			Product product = productService.get(id);
//			
//			List<User> listUsers = userService.listAll();
//			
//			Integer numberOfExistingExtraImages = product.getImages().size();
//			
//			model.addAttribute("listCategory", listCategory);
//			model.addAttribute("product", product);
//			model.addAttribute("listUsers", listUsers);
//			model.addAttribute("pageTitle", "Edit Product (ID: " + id + ")");
//			model.addAttribute("numberOfExistingExtraImages", numberOfExistingExtraImages);
//			
//			return "supplier/product_form";
//			
//		} catch (ProductNotFoundException e) {
//			
//			ra.addFlashAttribute("message", e.getMessage());
//			
//			return "redirect:/user_products";
//			
//		}
//		
//	}
	
	//both the admin and supplier use this to delete a service or product
	@GetMapping("/products/delete/{id}")
	public String deleteProduct(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirect, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		try {
			Product product = pRepo.findByProductId(id);
			List <OrderDetail> order = oRepo.findAllOrderDetailByProduct(id);
			
			for(OrderDetail o : order) {
				if(o.getProduct() == product) {
					o.setProduct(null);
					oRepo.save(o);
				}
			}
			
			List <CartItem> cartItem = cartRepo.findAllCartItemByProductId(id);
			
			for(CartItem c : cartItem) {
				if(c.getProduct() == product) {
					c.setProduct(null);
					cartRepo.save(c);
				}
			}
			
			List <Review> reviews = rRepo.findAllReviewByReviewId(id);
			
			for(Review r : reviews) {
				if(r.getProduct() == product) {
					r.setProduct(null);
					rRepo.save(r);
				}
			}
			
			List <Question> questions = qRepo.findAllQuestionByProductId(id);
			
			for(Question q : questions) {
				if(q.getProduct() == product) {
					q.setProduct(null);
					qRepo.save(q);
				}
			}
			
				productService.delete(id);
			
		
			
			String extraimagesProductDirectoryectory = "../product-images/" + id + "/extras";
			
			String imagesProductDirectory = "../product-images/" + id;
			
			FileUploadUtil.removeDirectory(extraimagesProductDirectoryectory);
			
			FileUploadUtil.removeDirectory(imagesProductDirectory);
			
			redirect.addFlashAttribute("message", "The product ID " + id + " has successfully been deleted");
		
		} catch (ProductNotFoundException ex) {
			
			redirect.addFlashAttribute("message", ex.getMessage());
			
		}
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		if(user.hasRole("Supplier")) {
		return "redirect:/user_products";
		}
		return "redirect:/products";
	}
	
	//both the admin and supplier use this to edit a service or product
	@GetMapping("/products/edit/{id}")
	public String editProduct(@PathVariable("id") Integer id, Model model, RedirectAttributes ra, @AuthenticationPrincipal CustomUserDetails userDetails) throws ParseException {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		try {
			
			Product product = productService.get(id);
			
			List<User> listUsers = userService.listAll();
			
			Integer numberOfExistingExtraImages = product.getImages().size();
			
			Iterable<Category> listCategory = null;
			
			if(product.isService() == false) {
				
			listCategory = cRepo.findAll();
			
			}
			
			int dateLength = product.getDate().size();
			
		
			
			model.addAttribute("role", user.hasRole("Admin"));
			model.addAttribute("listCategory", listCategory);
			model.addAttribute("product", product);
			model.addAttribute("listUsers", listUsers);
			model.addAttribute("userId", product.getUser().getUserID());
			model.addAttribute("pageTitle", "Edit Product (ID: " + id + ")");
			model.addAttribute("numberOfExistingExtraImages", numberOfExistingExtraImages);
			
			if(product.isService() == true) {
				
//				List<String> copyDate = new ArrayList<>();
//				
//				final String OLD_FORMAT = "dd/MM/yyyy";
//				
//				final String NEW_FORMAT = "yyyy-MM-dd";
//				
//				String newDateString;
//				
//				for(String e : product.getDate()) {
//				
//					System.out.println(e);	
//					
//					SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
//					
//					Date d = sdf.parse(e);
//					
//					sdf.applyPattern(NEW_FORMAT);
//					
//					newDateString = sdf.format(d);
//					
//					copyDate.add(newDateString);
//					
//					System.out.println(copyDate);
//					
//				}
				
				listCategory = cRepo.findAllByService();
				
				
				
				model.addAttribute("listCategory", listCategory);
				
//				model.addAttribute("copyDate", copyDate);
				
				model.addAttribute("dateLength", dateLength);
				
				return "supplier/product_form_service";	
				
			}

			if(user.hasRole("Supplier")) {
			return "redirect:/user_products";
			}
			return "redirect:/products";
			
		
			
		} catch (ProductNotFoundException e) {
			
			ra.addFlashAttribute("message", e.getMessage());
			
			
			
			if(user.hasRole("Supplier")) {
			return "redirect:/user_products";
			}
			return "redirect:/products";
			
		}
		
	}
	
	
	@GetMapping("/products/detail/{id}")
	public String viewProductDetails(@PathVariable("id") Integer id, Model model,RedirectAttributes ra) {
		
		try {
			
			Product product = productService.get(id);	
			
			model.addAttribute("product", product);		
			
			return "admin/product_detail_modal";
			
		} catch (ProductNotFoundException e) {
			
			ra.addFlashAttribute("message", e.getMessage());
			
			return "redirect:/products";
			
		}
		
	}
	
}
