package wedding.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import wedding.exception.ReviewNotFoundException;
import wedding.model.Product;
import wedding.model.Review;
import wedding.model.User;
import wedding.repo.ProductRepository;
import wedding.repo.ReviewRepository;
import wedding.repo.UserRepository;
import wedding.service.ReviewService;
import wedding.utility.CustomUserDetails;


@Controller
public class ReviewController {
	private String defaultRedirectURL = "redirect:/reviews/page_number/1?sortChosenField=reviewTime&sortDirection=desc";
	
	@Autowired private ReviewService reviewService;
	@Autowired private UserRepository uRepo;
	@Autowired private ReviewRepository rRepo;
	@Autowired private ProductRepository pRepo;
	
	@GetMapping("/reviews")
	public String listFirstPage(Model model) {
		
		return defaultRedirectURL;
		
	}
	
	@GetMapping("/reviews/page_number/{pageNum}") 
	public String listReviewsByuserByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails,  HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String keyWord, String sortChosenField, String sortDirection) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Page<Review> page = reviewService.listByuserByPage(user, keyWord, pageNum, sortChosenField, sortDirection);		
		
		List<Review> listReviews = page.getContent();
		
		model.addAttribute("listReviews", listReviews);

		long startOfCount = (pageNum - 1) * ReviewService.REVIEWS_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + ReviewService.REVIEWS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("URL", "/reviews");
		
		return "reviews/reviews_user";
	}
	
	@GetMapping("/reviews/detail/{id}")
	public String viewReview(@PathVariable("id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, Model model, RedirectAttributes ra, HttpServletRequest request) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		try {
			
			Review review = reviewService.getByuserAndId(user, id);
			
			model.addAttribute("review", review);
			
			return "reviews/review_detail_modal";
			
		} catch (ReviewNotFoundException ex) {
			
			ra.addFlashAttribute("message", ex.getMessage());
			
			return defaultRedirectURL;		
			
		}
		
	}
	
	@GetMapping("/ratings/{productId}/page_number/{pageNum}") 
	public String listByProductByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails, @PathVariable(name = "productId") Integer productId, @PathVariable(name = "pageNum") int pageNum, String sortChosenField, String sortDirection, HttpServletRequest request) {
		
		Product product = null;
		
		product = pRepo.findByProductId(productId);
		
		Page<Review> page = reviewService.listByProduct(product, pageNum, sortChosenField, sortDirection);
		
		List<Review> listReviews = page.getContent();
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		long startOfCount = (pageNum - 1) * ReviewService.REVIEWS_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + ReviewService.REVIEWS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("pageTitle", "Reviews for " + product.getShortName());
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("listReviews", listReviews);
		model.addAttribute("product", product);
		model.addAttribute("URL", "/reviews");
		
		return "reviews/reviews_product";
		
	}
	
	@GetMapping("/ratings/{productId}")
	public String listByProductFirstPage(@PathVariable(name = "productId") Integer productId,  @AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {
		
		return listByProductByPage(model, userDetails, productId, 1, "reviewTime", "desc", request);
	
	}	
	
	@GetMapping("/write_review/product/{productId}")
	public String showReviewForm(@PathVariable("productId") Integer productId, @AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {
		
		Review review = new Review();
		
		Product product = null;
		
		product = pRepo.findByProductId(productId);
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		boolean userReviewStatus = reviewService.diduserReviewProduct(user, product.getId());
		
		if (userReviewStatus) {
			
			model.addAttribute("userReviewStatus", userReviewStatus);
			
		} else {
			
			boolean userEligible = reviewService.canUserReviewProduct(user, product.getId());
			
			if (userEligible) {
				
				model.addAttribute("userEligible", userEligible);				
			
			} else {
				model.addAttribute("NoReviewPermission", true);
				
			}
			
		}		
		
		model.addAttribute("product", product);
		
		model.addAttribute("review", review);
		
		return "reviews/review_form";
	}
	
	@PostMapping("/post_review")
	public String saveUserReview(Model model, Review review, @AuthenticationPrincipal CustomUserDetails userDetails, Integer productId, HttpServletRequest request) {

		User user = uRepo.findUserById(userDetails.getUserId());
		
		Product product = null;
		
		product = pRepo.findByProductId(productId);
		
		review.setProduct(product);
		
		review.setUser(user);
		
		Review savedReview = reviewService.save(review);
		
		model.addAttribute("review", savedReview);
		
		return "reviews/review_done";
	}
	

	@GetMapping("/delete_review/{reviewId}")
	public String deleteUserReview(@PathVariable("reviewId") Integer reviewId, Model model, Review review, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		Review theReview = rRepo.findReviewById(reviewId);

		 rRepo.deleteById(reviewId);
		 
		 reviewService.updateRating(theReview.getProduct().getId());
		 
		return "reviews/reviews_user";
		
	}
	
}
