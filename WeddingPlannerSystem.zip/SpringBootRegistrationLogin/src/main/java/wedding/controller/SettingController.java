package wedding.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import wedding.model.Currency;
import wedding.model.GeneralSettingBag;
import wedding.model.Setting;
import wedding.repo.CurrencyRepository;
import wedding.service.SettingService;



@Controller
public class SettingController {

	@Autowired private SettingService service;
	
	@Autowired private CurrencyRepository currencyRepo;
	
	@GetMapping("/settings")
	public String listAll(Model model) {
		
		List<Setting> listAllSettings = service.listAllSettings();
		
		List<Currency> listAllCurrencies = currencyRepo.findAllByOrderByNameAsc();
		
		model.addAttribute("listCurrencies", listAllCurrencies);
		
		for (Setting s : listAllSettings) {
			
			model.addAttribute(s.getKey(), s.getValue());
			
		}
		
		return "settings/settings";
		
	}
	
	@PostMapping("/settings/save_general")
	public String saveGeneralSettings(HttpServletRequest httpRequest, RedirectAttributes redirect) throws IOException {
		
		GeneralSettingBag settingBag = service.getGeneralSettings();
		
		saveAllCurrency(httpRequest, settingBag);
		
		updateAllSettingValuesFromForm(httpRequest, settingBag.list());
		
		redirect.addFlashAttribute("message", "The general settings has been saved.");
		
		return "redirect:/settings";
		
	}
	
	private void saveAllCurrency(HttpServletRequest httpRequest, GeneralSettingBag settingBag) {
		Integer currencyId = Integer.parseInt(httpRequest.getParameter("CURRENCY_ID"));
		
		Optional<Currency> findResultId = currencyRepo.findById(currencyId);
		
		if (findResultId != null) {
			
			Currency currency = findResultId.get();
			
			settingBag.updateCurrencySymbol(currency.getSymbol());
			
		}
		
	}
	
	private void updateAllSettingValuesFromForm(HttpServletRequest httpRequest, List<Setting> listSettings) {
;
		for (Setting setting : listSettings) {
			
			String value = httpRequest.getParameter(setting.getKey());

			if (value != null) {
				
				setting.setValue(value);
				
			}
			
		}
		
		service.saveAll(listSettings);
		
	}
	
	@PostMapping("/settings/save_mail_server")
	public String saveMailServerSetttings(HttpServletRequest httpRequest, RedirectAttributes redirect) {
		
		List<Setting> mailServerSettings = service.getMailServerSettings();
		
		updateAllSettingValuesFromForm(httpRequest, mailServerSettings);
		
		redirect.addFlashAttribute("message", "The mail server settings has been saved");
		
		return "redirect:/settings#mailServer";
		
	}
	
	@PostMapping("/settings/save_mail_templates")
	public String saveAllMailTemplateSetttings(HttpServletRequest httpRequest, RedirectAttributes redirect) {
		
		List<Setting> mailTemplateSettings = service.getMailTemplateSettings();
		
		updateAllSettingValuesFromForm(httpRequest, mailTemplateSettings);
		
		redirect.addFlashAttribute("message", "The mail template settings has been saved");
		
		return "redirect:/settings#mailTemplates";
		
	}
	
	@PostMapping("/settings/save_payment")
	public String saveAllPaymentSetttings(HttpServletRequest httpRequest, RedirectAttributes redirect) {
	
		List<Setting> paymentSettings = service.getPaymentSettings();
		
		updateAllSettingValuesFromForm(httpRequest, paymentSettings);

		redirect.addFlashAttribute("message", "The payment settings has been saved");
		
		return "redirect:/settings#payment";
		
	}		
	
}
