package wedding.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import wedding.exception.UserNotFoundException;
import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.OrderDetail;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Sales;
import wedding.repo.CartItemRepository;
import wedding.repo.CategoryRepository;
import wedding.repo.OrderDetailRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.ReviewRepository;
import wedding.repo.SalesRepository;
import wedding.service.CategoryService;
import wedding.utility.FileUploadUtil;

@Controller
public class CategoryController {
	
	@Autowired 
	private CategoryService cService;
	
	@Autowired
	private CategoryRepository cRepo;
	
	@Autowired private OrderDetailRepository oRepo;
	@Autowired private CartItemRepository cartRepo;
	@Autowired private ReviewRepository rRepo;
	@Autowired private QuestionRepository qRepo;
	@Autowired private SalesRepository sRepo;
	@Autowired private ProductRepository pRepo;
	
	@GetMapping("/category")
	public String listFirstPage(Model model) {
		return listByPage(null, 1, model, "asc", "name");
	}

	
	@GetMapping("/category/page_number/{pageNumber}")
	public String listByPage(@Param("keyWord") String keyWord, @PathVariable(name = "pageNumber") int pageNumber, Model model, @Param("sortDirection") String sortDirection, @Param("sortChosenField") String sortChosenField
			
			) {
		
		Page<Category> pageContent = cService.listByCategoryPage(keyWord, sortChosenField, sortDirection, pageNumber);
		
		long startOfCount = (pageNumber - 1) * CategoryService.CATEGORY_PER_PAGE + 1;
		
		long endOfCount = startOfCount + CategoryService.CATEGORY_PER_PAGE - 1;
		
		if (endOfCount > pageContent.getTotalElements()) {
			
			endOfCount = pageContent.getTotalElements();
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		List<Category> listCategory = pageContent.getContent();	
		
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", pageContent.getTotalElements());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("listCategory", listCategory);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("currentPageNumber", pageNumber);
		model.addAttribute("totalNumPages", pageContent.getTotalPages());
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("URL", "/category");
		model.addAttribute("nameOfEntity", "Category");
		return "admin/category";		
	}
	
	
	@GetMapping("/category/new")
	public String newCategory(Model model) {
		
		Category category = new Category();
		
		Iterable<Category> listAllCategory = cRepo.findAll();
		
		model.addAttribute("category", category);
		
		model.addAttribute("listAllCategory", listAllCategory);

		return "admin/category_form";
	}
	
	
	@PostMapping("/category/save")
	public String saveCategory(RedirectAttributes redirect, Category category, 
			@RequestParam("fileImage") MultipartFile copyFileContent) throws IOException {

		
		if (!copyFileContent.isEmpty()) {
			
			String nameofFile = StringUtils.cleanPath(copyFileContent.getOriginalFilename());
			
			category.setPhotos(nameofFile);
			
			Category savedCategory = cRepo.save(category);
			
			String uploadDirectory = "../category-images/" + savedCategory.getId();
			
			FileUploadUtil.cleanDirectory(uploadDirectory);
			
			FileUploadUtil.saveFile(uploadDirectory, nameofFile, copyFileContent);
			
		} else {
			
			if (category.getPhotos().isEmpty()) category.setPhotos(null);
			
			cRepo.save(category);
			
		}
		
		redirect.addFlashAttribute("message", "The category has been saved successfully.");
		
		return "redirect:/category";
	}
	
	@GetMapping("/category/edit/{id}")
	public String editCategory(@PathVariable(name = "id") Integer id, RedirectAttributes redirect, Model model) {
		Category category = cRepo.findCategoryById(id);
		
		model.addAttribute("category", category);
		
		model.addAttribute("pageTitle", "You are editing category with (ID: " + id + ")");
		
		return "admin/category_form";
	}
	
	@GetMapping("/category/{id}/enabled/{status}")
	public String updateCategoryStatus(@PathVariable("id") Integer id,  RedirectAttributes redirect, @PathVariable("status") boolean enable) {
//		
//		cService.updateCategoryEnabledStatus(id, enable);
		
		Category category = cRepo.findCategoryById(id);
		
		if(enable == true) {
			category.setEnabled(true);
		}
		if(enable == false) {
			category.setEnabled(false);
		}
		cRepo.save(category);
		
		String status = enable ? "enabled" : "disabled";
		
		String changeMessage = "The category with ID " + id + " has been changed to" + status;
		
		redirect.addFlashAttribute("message", changeMessage);
		
		return "redirect:/category";
	}
	
	@GetMapping("/category/delete/{id}")
	public String deleteACategory(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirect) throws UserNotFoundException {
		
		Category category = cRepo.findCategoryById(id);
		
		List <Product> listProduct = pRepo.findProductByCategory(id);
		
		List <Review> reviews = rRepo.findAllReviewByReviewId(id);
	
		List <OrderDetail> order = oRepo.findAllOrderDetailByProduct(id);
		
		List <CartItem> cartItem = cartRepo.findAllCartItemByProductId(id);
		
		List <Question> questions = qRepo.findAllQuestionByProductId(id);
		
		List <Sales> sales = sRepo.findAllSalesByProductId(id);
		
		for(Product product : listProduct) {
		
		for(OrderDetail o : order) {
			if(o.getProduct() == product) {
				o.setProduct(null);
				oRepo.save(o);
			}
		}
		
		
		
		for(CartItem c : cartItem) {
			if(c.getProduct() == product) {
				c.setProduct(null);
				cartRepo.save(c);
			}
		}
		
	
		
		for(Review r : reviews) {
			if(r.getProduct() == product) {
				r.setProduct(null);
				rRepo.save(r);
			}
		}
		
	
		
		for(Question q : questions) {
			if(q.getProduct() == product) {
				q.setProduct(null);
				qRepo.save(q);
			}
		}
			
		for(Sales s : sales) {
			if(s.getProduct() == product) {
				s.setProduct(null);
				sRepo.save(s);
				}
		}
		
		product.setCategory(null);
		pRepo.save(product);
		}
		
		
		
		
		cRepo.delete(category);
		
		String categoryDirectory = "../category-images/" + id;
		
		FileUploadUtil.removeDirectory(categoryDirectory);
		
		redirect.addFlashAttribute("message", "The category with ID " + id + " has been successfully deleted");
		
		return "redirect:/category";
	}
}