package wedding.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import wedding.exception.ProductNotFoundException;
import wedding.exception.UserNotFoundException;
import wedding.model.Answer;
import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.CurrencySettingBag;
import wedding.model.EmailSettingBag;
import wedding.model.Order;
import wedding.model.OrderDetail;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Roles;
import wedding.model.Sales;
import wedding.model.Suspension;
import wedding.model.User;
import wedding.repo.AnswerRepository;
import wedding.repo.CartItemRepository;
import wedding.repo.OrderDetailRepository;
import wedding.repo.OrderRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.ReviewRepository;
import wedding.repo.RolesRepository;
import wedding.repo.SalesRepository;
import wedding.repo.ShippingRateRepository;
import wedding.repo.SuspensionRepository;
import wedding.repo.UserRepository;
import wedding.service.AddressService;
import wedding.service.CheckoutService;
import wedding.service.OrderService;
import wedding.service.PayPalService;
import wedding.service.SettingService;
import wedding.service.ShippingRateService;
import wedding.service.ShoppingCartService;
import wedding.service.UserService;
import wedding.utility.CustomUserDetails;
import wedding.utility.FileUploadUtil;
import wedding.utility.UserExcelExporter;
import wedding.utility.Utility;


@Controller
public class UsersController {

	@Autowired
	private UserService service;
	
	@Autowired
	private RolesRepository rRepo;
	
	@Autowired
	private UserRepository uRepo;
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired private SalesRepository salesRepo;
	
	@Autowired
	private SuspensionRepository sRepo;
	
	@Autowired
	private ProductRepository pRepo;
	
	@Autowired private ReviewRepository revRepo;

	@Autowired private OrderDetailRepository oRepo;
	@Autowired private CartItemRepository cartRepo;
	@Autowired private AnswerRepository aRepo;
	@Autowired private QuestionRepository qRepo;

	
	@GetMapping("/users")
	public String listFirstPage(Model model, @RequestParam(name = "userid", required = false) String id, @RequestParam(name = "status", required = false) String status) {
		
		return listByPage(1, model, "firstName", "asc", null, id, status);
		
	}
	
	@GetMapping("/users/page_number/{currentPageNumber}")
	public String listByPage(@PathVariable(name = "currentPageNumber") int currentPageNumber, Model model, @Param("sortChosenField") String sortChosenField, @Param("sortDirection") String sortDirection, @Param("keyWord") String keyWord, @RequestParam(name = "id", required = false) String id, @RequestParam(name = "status", required = false) String status) {

		Page<User> page = service.listByPage(currentPageNumber, sortChosenField, sortDirection, keyWord);
		
		List<User> listUsers = page.getContent();
		
		long startOfCount = (currentPageNumber - 1) * UserService.USERS_PER_PAGE + 1;
		
		long endOfCount = startOfCount + UserService.USERS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		String reverseSortDirection = sortDirection.equals("asc") ? "desc" : "asc";
		
		model.addAttribute("currentPageNumber", currentPageNumber);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("startOfCount", startOfCount);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("listUsers", listUsers);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", reverseSortDirection);
		model.addAttribute("keyWord", keyWord);
	    model.addAttribute("URL", "/users");
	    
    	System.out.println(id + "trueee");
    	System.out.println(status + "trueeee");
    	
	    if(id != null || status != null) {
	    	System.out.println("true and true");
	    model.addAttribute("message", "The user ID with the: " + id + ", has been disabled");
	    }
	    
	    return "admin/users";		
		
	}
	
	
	@GetMapping("/users/new")
	public String createNewUser(Model model) {
		
		List<Roles> listRoles = service.listRoles();
		
		User user = new User();
		
	    Roles sNameRole = rRepo.findByName("Supplier");
	    Roles cNameRole = rRepo.findByName("Customer");
	    Roles aNameRole = rRepo.findByName("Admin");
	    
	    Integer sNameId = sNameRole.getId();
	    Integer cNameId = cNameRole.getId();
	    Integer aNameId = aNameRole.getId();
	    
	    
	    model.addAttribute("listRoles", listRoles);
	    model.addAttribute("sNameId", sNameId);
	    model.addAttribute("sNameRole", sNameRole);
	    model.addAttribute("cNameId", cNameId);
	    model.addAttribute("cNameRole", cNameRole);
	    model.addAttribute("aNameId", aNameId);
	    model.addAttribute("aNameRole", aNameRole);
		model.addAttribute("user", user);
		model.addAttribute("listRoles", listRoles);
		model.addAttribute("pageTitle", "Create New User");
	    model.addAttribute("URL", "/users");
	    
		return "admin/user_form";
		
	}
	
	@GetMapping("/users/{id}/enabled/{status}")
	public String updateAnUserEnabledStatus(@PathVariable("id") Integer userid, Model model, @PathVariable("status") boolean status, RedirectAttributes redirect) throws UnsupportedEncodingException, MessagingException {
		
		String userStatus = null;
		
		User user = uRepo.findUserById(userid);
		
		System.out.println(status);
		

		if(status == true) {
		
//		service.updateUserEnabledStatus(userid, status);
		
		String currentStatus = status ? "enabled" : "disabled";
		
		String responseMessage = "The user has been " + currentStatus;
		
		user.setSuspension(null);
		
		user.setEnabled(true);
		
		uRepo.save(user);
		
		userStatus = "unsuspended";
		
		Suspension userSuspension = sRepo.findSuspensionReasonById(userid);
		
		service.sendUserNotification(user, userStatus, userSuspension.getReason());
		
		sRepo.delete(userSuspension);
		
		redirect.addFlashAttribute("message", responseMessage);
		
		return "redirect:/users";	
		}
		
		if(status == false) {
		
		model.addAttribute("user", user);
		model.addAttribute("userId", userid);
		model.addAttribute("status", status);

		
		return "admin/user_suspension_modal";
		}
		
		return "redirect:/users";	
	}
	
	@GetMapping("/user/detail/{id}")
	public String viewUserDetails(@PathVariable("id") Integer id, Model model,RedirectAttributes ra) {
		
		User user = uRepo.findUserById(id);
		
		model.addAttribute("user", user);		
		
		System.out.println("SUIIII");
		return "admin/suspension_detail_modal";
		
	}
	
//	@GetMapping("/userReponseMessage")
//	public String vieuserReponseMessage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request,  RedirectAttributes redirect) {
//		
//		redirect.addFlashAttribute("message", "The user ID with the: " + userid + ", has been " + currentStatus);
//		
//		return "redirect:/admin/users";
//		
//	}
	
	@PostMapping("/users/save")
	public String saveAnUser(User user, RedirectAttributes redirect, @RequestParam("image") MultipartFile multiFile) throws IOException {
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		
		user.setPassword(encodedPassword);
		
		if (!multiFile.isEmpty()) {
			
			String nameOfFile = StringUtils.cleanPath(multiFile.getOriginalFilename());
			
			user.setPhotos(nameOfFile);
			
			User savedUser = service.save(user);
			
			String uploadDirectory = "user-photos/" + savedUser.getUserID();
			
			FileUploadUtil.cleanDirectory(uploadDirectory);
			
			FileUploadUtil.saveFile(uploadDirectory, nameOfFile, multiFile);
			
		} else {
			
			if (user.getPhotos().isEmpty()) user.setPhotos(null);
			
			service.save(user);
			
		}
		
		redirect.addFlashAttribute("message", "The user has been saved successfully.");
		
		return "redirect:/users";
		
	}
	
	@GetMapping("/users/edit/{id}")
	public String editAnUser(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirect) {
	
		try {
			
			User user = service.get(id);
			
			List<Roles> listRoles = service.listRoles();
			
			model.addAttribute("user", user);
			
			model.addAttribute("pageTitle", "Edit User (ID: " + id + ")");

		    Roles sNameRole = rRepo.findByName("Supplier");
		    Roles cNameRole = rRepo.findByName("Customer");
		    Roles aNameRole = rRepo.findByName("Admin");
		    
		    Integer sNameId = sNameRole.getId();
		    Integer cNameId = cNameRole.getId();
		    Integer aNameId = aNameRole.getId();
		    
		    model.addAttribute("listRoles", listRoles);
		    model.addAttribute("sNameId", sNameId);
		    model.addAttribute("sNameRole", sNameRole);
		    model.addAttribute("cNameId", cNameId);
		    model.addAttribute("cNameRole", cNameRole);
		    model.addAttribute("aNameId", aNameId);
		    model.addAttribute("aNameRole", aNameRole);
			model.addAttribute("listRoles", listRoles);
			
			return "admin/user_form";
			
		} catch (UserNotFoundException ex) {
			
			redirect.addFlashAttribute("message", ex.getMessage());
			
			return "redirect:/admin/users";
			
		}
		
	}
	
	@GetMapping("/users/delete/{id}")
	public String deleteAnUser(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirect) {
		
				
		Iterable<Product> listProduct = pRepo.findAll();
		
		
		List <Answer> answer = aRepo.findAnswerByUserId(id);
		aRepo.deleteAll(answer);	
		
		
		
//		for(Product p : listProduct) {
//			if(p.getUser().getUserID() == id) {
//				qRepo.findAllQuestionByProductId(p.getId());
//			
//			}
//		}
		
		List <Product> product = pRepo.listProductByUser(id);
		pRepo.deleteAll(product);
		
		List <Question> questions = qRepo.findAllQuestionByUserId(id);
		qRepo.deleteAll(questions);
		
				List <Sales> sales = salesRepo.findAllSalesByUserId(id);
		salesRepo.deleteAll(sales);
		
//		List <Review> reviews = revRepo.findAllReviewsByUserId(id);
//		revRepo.deleteAll(reviews);
		
//		
		
//		
//
//		
//		List <CartItem> cartItem = cartRepo.findAllCartItemById(id);
//		cartRepo.deleteAll(cartItem);
//		

//		
//		List <Order> orders = orderRepo.findAllOrderByUserId(id);
//		orderRepo.deleteAll(orders);
				
		


		
	
//		List <Options> options = 
//		
//		for(Product product : listProduct) {
//		
//		for(OrderDetail o : order) {
//			if(o.getProduct() == product) {
//				o.setProduct(null);
//				oRepo.save(o);
//			}
//		}
//		
//		
//		
//		for(CartItem c : cartItem) {
//			if(c.getProduct() == product) {
//				c.setProduct(null);
//				cartRepo.save(c);
//			}
//		}
//		
//	
//		
//		for(Review r : reviews) {
//			if(r.getProduct() == product) {
//				r.setProduct(null);
//				revRepo.save(r);
//			}
//		}
//		
//	
//		
//		for(Question q : questions) {
//			if(q.getProduct() == product) {
//				q.setProduct(null);
//				qRepo.save(q);
//			}
//		}
//			
//		product.getSales().clear();
//		
//		
//		for(Sales s : sales) {
//			if(s.getProduct() == product) {
//				s.setProduct(null);
//				s.setUser(null);
//				salesRepo.save(s);
//				}
//		}
//		
//		product.getSales().clear();
//		product.setUser(null);
//		pRepo.save(product);
//		}
		
		try {
			
			User a = service.get(id);
			
			a.setRoles(null);
			
			service.delete(id);
			
			redirect.addFlashAttribute("message", "The user ID " + id + " has been deleted successfully");
		
		} catch (UserNotFoundException ex) {
			
			redirect.addFlashAttribute("message", ex.getMessage());
		
		}
		
		return "redirect:/users";
	}
	
	
	
	@GetMapping("/users/export/excel")
	public void exportToExcel(HttpServletResponse response) throws IOException {
	
		List<User> listUsers = service.listAll();
		
		UserExcelExporter exporter = new UserExcelExporter();
		
		exporter.export(listUsers, response);
		
	}
	

	
}
