package wedding.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import wedding.model.Category;
import wedding.model.CurrencySettingBag;
import wedding.model.Notification;
import wedding.model.Product;
import wedding.model.Sales;
import wedding.model.User;
import wedding.repo.NotificationRepository;
import wedding.repo.UserRepository;
import wedding.service.CategoryService;
import wedding.service.NotificationService;
import wedding.service.QuestionService;
import wedding.utility.CustomUserDetails;
import wedding.utility.FileUploadUtil;

@Controller
public class NotificationController {

	private String defaultRedirectURL = "redirect:/admin_view_notification/page_number/1?sortChosenField=id&sortDirection=asc";
	
	private String listRedirectURL = "redirect:/admin_notification_list/page_number/1?sortChosenField=id&sortDirection=asc";
	
	@Autowired private NotificationRepository nRepo;
	
	@Autowired private NotificationService nService;
	
	@Autowired
	private UserRepository uRepo;
	
	@GetMapping("/admin_notification")
	public String sendAdminNotification(Model model) {
		Notification notification = new Notification();
		
		model.addAttribute(notification);
		return "notification/notification";
	}
	
	@GetMapping("/admin_view_notification/{id}")
	public String viewNotification(Model model, @PathVariable(name = "id") int id) {

		return "redirect:/admin_view_notification/" + id + "/page_number/1?sortChosenField=date&sortDirection=asc";
	}
	
	@GetMapping("/admin_notification_list")
	public String listNotification(Model model) {

		return listRedirectURL;
	}
	
	@GetMapping("/admin_view_notification/{id}/page_number/{pageNum}") 
	public String listReviewsByuserByPage(Model model, @PathVariable(name = "id") int id, @AuthenticationPrincipal CustomUserDetails userDetails,  HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String keyWord, String sortChosenField, String sortDirection) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		System.out.println(userDetails.getUserId());
		System.out.println(pageNum);
		System.out.println(keyWord);
		System.out.println(sortChosenField);
		System.out.println(sortDirection);
		
		Page<Notification> page = nService.listByUserByPage(id, user, keyWord, pageNum, sortChosenField, sortDirection);		
		

		
		List<Notification> listNotification = page.getContent();
		
		
		
		model.addAttribute("listNotification", listNotification);

		long startOfCount = (pageNum - 1) * nService.NOTIFICATION_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + NotificationService.NOTIFICATION_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}

		

        //for each product, if product equals sales product get all sales
        //profit
//        for(Product p : allUserProducts) {
//        	for(Sales s : allUserSales) {
//        		if(p.getId() == s.getProduct().getId()) {
//        			
//        		}
//        	}
//        }
        
  
//        graphData.put("2016", 147);
//        graphData.put("2017", 1256);

		System.out.println("Yay");

		Notification notifications = new Notification();
		
		model.addAttribute("userNotificationID", id);
		model.addAttribute("notifications", notifications);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("URL", "/admin_view_notification");
		
		return "admin/notifications";
	}
	
	
	@PostMapping("/send_notification_reply/{id}")
	public String replyNotification(Notification notification, @PathVariable(name = "id") int id, @AuthenticationPrincipal CustomUserDetails userDetails, RedirectAttributes redirect){
		
		Notification newNotification = new Notification();

		
		User user = uRepo.findUserById(userDetails.getUserId());

		
		User user2 = uRepo.findUserById(id);
		
		user2.getContacted().add(user2);
		user2.getRespondee().add(user);
		System.out.println("YYYYAYYY!!!!!");
		uRepo.save(user2);
				
//		System.out.println(loggedUser.getUserID());
//		
//		System.out.println(recipient.getUserID());
		
//		for(User e : users) {
//			System.out.println(e.getUserID() + "errrrrrr");
//		}
//		
//		for(User e : test) {
//			System.out.println(e.getUserID() + "hmmmmm");
//		}
//		
//		if(!recipient.getContacted().contains(loggedUser)) {
//			System.out.println("it went through mayoo");
//			recipient.getContacted().add(findout);
//			uRepo.save(recipient);
//		}
		
//		for(User e : users) {
//				if(e.getUserID() == recipient.getUserID()) {
//					System.out.println(e.getUserID() + "first");
//					break;
//				}
//				if(e.getUserID() == loggedUser.getUserID()) {
//					System.out.println(e.getUserID() + "second");
//				break;
//				}
//				System.out.println("didnt skip");
//				users.add(loggedUser);
//				recipient.setContacted(users);
//				System.out.println("YYYYAYYY!!!!!");
//				System.out.println("why?");
//				uRepo.save(recipient);
//		} 
		
//		
//		for(User e : test) {
//				if(e.getUserID() == recipient.getUserID()) {
//					System.out.println(e.getUserID() + "first");
//					break;
//				}
//				if(e.getUserID() == loggedUser.getUserID()) {
//					System.out.println(e.getUserID() + "second");
//				break;
//				}
//				System.out.println("didnt skip");
//				users.add(loggedUser);
//				recipient.setContacted(users);
//				System.out.println("YYYYAYYY!!!!!");
//				System.out.println("why?");
//				uRepo.save(recipient);
//			} 
		
		
	
		
//		for(User u : listAdmin) {
//			if(u.hasRole("Admin")) {
//				currentUser.add(u);
//		List <User>	users =	u.getContacted();
		
		
//		if(!users.contains(loggedUser) || !test.contains(recipient) || !users.contains(recipient) || !test.contains(loggedUser)) {
//		users.add(loggedUser);
//		recipient.setContacted(users);
//		System.out.println("YYYYAYYY!!!!!");
//		System.out.println("why?");
//		uRepo.save(recipient);
//		}
//			}
//		}
		newNotification.setHeadLine(notification.getHeadLine());
		newNotification.setMessage(notification.getMessage());
		newNotification.setDate(new Date());
		newNotification.getUser().add(user2);//reciever
		newNotification.setUser_sender(user);//sender
		newNotification.setUser_contact(user2);
		newNotification.setStatus(true);
//
//
		nRepo.save(newNotification);
		
		redirect.addFlashAttribute("message", "The user has been saved successfully.");
		

		
		return "redirect:/admin_view_notification/"+ id;
		
	}
	
	@GetMapping("/notification_reply/detail/{id}")
	public String sendUserNotification(Model model, @PathVariable(name = "id") int id) {
		
		Notification notification = new Notification();
		
		model.addAttribute(notification);
		model.addAttribute("id", id);
		return "notification/user_notification";
	}
	
	
	@GetMapping("/admin_notification_list/page_number/{pageNum}") 
	public String listNoitifcationByuserByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails,  HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String keyWord, String sortChosenField, String sortDirection) {
		
//		 user = uRepo.findUserById(userDetails.getUserId());
		
		System.out.println(userDetails.getUserId());
		System.out.println(pageNum);
		System.out.println(keyWord);
		System.out.println(sortChosenField);
		System.out.println(sortDirection);
		
		Page<User> page = nService.listByNotificationListByPage(userDetails.getUserId(), keyWord, pageNum, sortChosenField, sortDirection);		
		

		
		List<User> listUser = page.getContent();
		
		
		
		model.addAttribute("listUser", listUser);

		long startOfCount = (pageNum - 1) * nService.NOTIFICATION_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + NotificationService.NOTIFICATION_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}

		

        //for each product, if product equals sales product get all sales
        //profit
//        for(Product p : allUserProducts) {
//        	for(Sales s : allUserSales) {
//        		if(p.getId() == s.getProduct().getId()) {
//        			
//        		}
//        	}
//        }
        
  
//        graphData.put("2016", 147);
//        graphData.put("2017", 1256);

		System.out.println("Yay");

		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("URL", "/admin_notification_list");
		
		return "admin/list_user_notifications";
	}
	
	@PostMapping("/send_admin_notification")
	public String sendNotification(Notification notification, @AuthenticationPrincipal CustomUserDetails userDetails, RedirectAttributes redirect){
		
		List <User> listAdmin = uRepo.findAll();

		User user = uRepo.findUserById(userDetails.getUserId());

		Set<User> currentUser = new HashSet<User>();
		
		
		Random randomizer = new Random();
		User randomAdmin = listAdmin.get(randomizer.nextInt(listAdmin.size()));

		for(User u : listAdmin) {
			if(u.hasRole("Admin")) {
		if(!u.getContacted().contains(user)) {
		u.getContacted().add(u);
		u.getRespondee().add(user);
		System.out.println("YYYYAYYY!!!!!");
		uRepo.save(u);
		break;
		}
			}
		}
		
		notification.setDate(new Date());
		notification.getUser().add(user);//who recieves it
		notification.setUser_sender(user);//who is sending
		notification.setStatus(true);

		nRepo.save(notification);
		
		redirect.addFlashAttribute("message", "The user has been saved successfully.");
		
		return "redirect:/admin_notification";
		
	}
	
//	@GetMapping("/admin_notification")
//	public String sendAdminNotification(Model model) {
//		Notification notification = new Notification();
//		
//		model.addAttribute(notification);
//		return "notification/notification";
//	}

}
