package wedding.controller;

import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import wedding.model.Answer;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.User;
import wedding.repo.AnswerRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.UserRepository;
import wedding.service.QuestionService;
import wedding.service.ReviewService;
import wedding.utility.CustomUserDetails;

@Controller
public class QuestionController {

	private String defaultRedirectURL = "redirect:/questions/page_number/1?sortChosenField=questionHeader&sortDirection=desc";
	
	@Autowired private UserRepository uRepo;
	@Autowired private ProductRepository pRepo;
	@Autowired private QuestionRepository qRepo;
	@Autowired private QuestionService qService;
	@Autowired private AnswerRepository aRepo;
	
	
	@GetMapping("/questions")
	public String listFirstPage(Model model) {
		
		return defaultRedirectURL;
		
	}
	

	@GetMapping("/questions/page_number/{pageNum}") 
	public String listReviewsByuserByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails,  HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String keyWord, String sortChosenField, String sortDirection) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Page<Question> page = qService.listByUserByPage(user, keyWord, pageNum, sortChosenField, sortDirection);		
		

		
		List<Question> listQuestions = page.getContent();
		
		model.addAttribute("listQuestions", listQuestions);

		long startOfCount = (pageNum - 1) * QuestionService.QUESTIONS_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + QuestionService.QUESTIONS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		

		
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("URL", "/questions");
		
		return "questions/questions_user";
	}
	
	@GetMapping("/product/question/write/{productId}")
	public String showViewForm(@PathVariable("productId") Integer productId, @AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {
		
		Question question = new Question();
		
		Product product = null;
		
		product = pRepo.findByProductId(productId);
			
		model.addAttribute("product", product);
		model.addAttribute("question", question);
		
		return "questions/question_form";
		
	}
	
	@PostMapping("/post_question")
	public String saveQuestion(Model model, Question question, @AuthenticationPrincipal CustomUserDetails userDetails, Integer productId, HttpServletRequest request) {

		User user = uRepo.findUserById(userDetails.getUserId());
		
		Product product = null;
		
		product = pRepo.findByProductId(productId);
		
		question.setProduct(product);
		
		question.setUser(user);
		
		qService.save(question);
		
		model.addAttribute("product", product);
		
		return "redirect:/p/" + productId;
	}
	
	
	
	
	@GetMapping("/product/question/{productId}")
	public String listByProductFirstPage(@PathVariable(name = "productId") Integer productId,  @AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {
		
		return listByProductByPage(model, userDetails, productId, 1, "questionTime", "desc", request);
	
	}	

	@GetMapping("/question/{productId}/page_number/{pageNum}") 
	public String listByProductByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails,
				@PathVariable(name = "productId") Integer productId,
				@PathVariable(name = "pageNum") int pageNum,
				String sortChosenField, String sortDirection,
				HttpServletRequest request) {
		
		Product product = null;
		
		long numberOfQuestions = qRepo.countAllQuestionsById(productId);
		
		product = pRepo.findByProductId(productId);
		
		Page<Question> page = qService.listByProduct(product, pageNum, sortChosenField, sortDirection);
		
		List<Question> listQuestions = page.getContent();

		long startOfCount = (pageNum - 1) * qService.QUESTIONS_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + qService.QUESTIONS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		
		
		
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("userId", userDetails.getUserId());
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("pageTitle", "Reviews for " + product.getShortName());
		model.addAttribute("listQuestions", listQuestions);
		model.addAttribute("product", product);
		model.addAttribute("numberOfQuestions", numberOfQuestions);
		model.addAttribute("URL", "/questions");
		
		return "questions/questions_product";
	}
	
	@GetMapping("/questions/detail/{id}")
	public String viewQuestionDetails(Model model, @PathVariable(name = "id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {

		Optional<Question> question = qRepo.findById(id);
		
		String questionHeader = question.get().getQuestionHeader();
		
		Answer answer = new Answer();

		model.addAttribute("questionHeader", questionHeader);
		model.addAttribute("answer", answer);
		model.addAttribute("questionID", id);
		
		return "questions/question_modal";
		
	}
	
	@GetMapping("/questions/delete/{id}")
	public String deleteQuestion(Model model, @PathVariable(name = "id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
	

		Question question = qRepo.findQuestionById(id);
		
		System.out.println(question.getQuestionId());
		
		Integer productId = question.getProduct().getId();
		question.setProduct(null);
		question.setUser(null);
		qRepo.save(question);
		qService.delete(id);
		qService.deleteFromDatabase(id);
		
		return "redirect:/product/question/" + productId;
	}
	
	@GetMapping("/answer/delete/{id}")
	public String deleteAnswer(Model model, @PathVariable(name = "id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		Answer answer = aRepo.findAnswerById(id);
		
		Integer productId = answer.getQuestion().getProduct().getId();
		
		aRepo.delete(answer);
		
		return "redirect:/product/question/" + productId;
	}
	
	@GetMapping("/answer/detail/{id}/{questionId}")
	public String viewAnswerDetails(Model model, @PathVariable(name = "id") Integer id, @PathVariable(name = "questionId") Integer questionId, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		Optional<Answer> answers = aRepo.findById(id);
		
		String answerHeader = answers.get().getAnswer();
		
		Answer answer = new Answer();

		model.addAttribute("answerHeader", answerHeader);
		model.addAttribute("answer", answer);
		model.addAttribute("answerId", id);
		model.addAttribute("questionId", questionId);
		
		return "questions/answer_modal";
		
	}	
	
}
