package wedding.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import wedding.model.Answer;
import wedding.model.CurrencySettingBag;
import wedding.model.Product;
import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Sales;
import wedding.model.User;
import wedding.repo.AnswerRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.SalesRepository;
import wedding.repo.UserRepository;
import wedding.service.QuestionService;
import wedding.service.ReviewService;
import wedding.service.SalesService;
import wedding.service.SettingService;
import wedding.utility.CustomUserDetails;

@Controller
public class SalesController {

	private String defaultRedirectURL = "redirect:/sales/page_number/1?sortChosenField=lastSold&sortDirection=asc";
	
	@Autowired private UserRepository uRepo;
	@Autowired private ProductRepository pRepo;
	@Autowired private QuestionRepository qRepo;
	@Autowired private QuestionService qService;
	@Autowired private AnswerRepository aRepo;
	@Autowired private SalesService sService;
	@Autowired private SettingService setService;
	@Autowired private SalesRepository sRepo;
	
	@GetMapping("/sales")
	public String listFirstPage(Model model) {
		
		return defaultRedirectURL;
		
	}
	

	@GetMapping("/sales/page_number/{pageNum}") 
	public String listReviewsByuserByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails,  HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String keyWord, String sortChosenField, String sortDirection) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Page<Sales> page = sService.listByUserByPage(user, keyWord, pageNum, sortChosenField, sortDirection);		
		

		
		List<Sales> listSales = page.getContent();
		
		model.addAttribute("listSales", listSales);

		long startOfCount = (pageNum - 1) * SalesService.SALES_PER_PAGE + 1;
		
		model.addAttribute("startOfCount", startOfCount);
		
		long endOfCount = startOfCount + SalesService.SALES_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		
        Map<String, Integer> graphProfit = new TreeMap<>();
        Map<String, Integer> graphSales = new TreeMap<>();
        List<Sales> allUserSales = sRepo.findSalesByUserId(userDetails.getUserId());
        
        List<Product> allUserProducts = pRepo.findAllByUser(userDetails.getUserId());
        
        //for each product, if product equals sales product get all sales
        //profit
//        for(Product p : allUserProducts) {
//        	for(Sales s : allUserSales) {
//        		if(p.getId() == s.getProduct().getId()) {
//        			
//        		}
//        	}
//        }
        
        for(Product p : allUserProducts) {
        	Integer totalProfit = sRepo.sumQuantities(p.getId());
        	System.out.println(totalProfit);
        	graphProfit.put(p.getName(), totalProfit);
        }
        
        for(Product p : allUserProducts) {
        	Integer totalSales = sRepo.sumSales(p.getId());
        	graphSales.put(p.getName(), totalSales);
        }
        
//        graphData.put("2016", 147);
//        graphData.put("2017", 1256);
//        graphData.put("2018", 3856);
//        graphData.put("2019", 19807);
        model.addAttribute("graphProfit", graphProfit);
        model.addAttribute("graphSales", graphSales);

		model.addAttribute("currency", currency);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("URL", "/sales");
		
		return "supplier/sales";
	}
	
    @GetMapping("/sales_report")
    public String getPieChart(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
        Map<String, Integer> graphProfit = new TreeMap<>();
        Map<String, Integer> graphSales = new TreeMap<>();
        List<Sales> allUserSales = sRepo.findSalesByUserId(userDetails.getUserId());
        
        List<Product> allUserProducts = pRepo.findAllByUser(userDetails.getUserId());
        
        //for each product, if product equals sales product get all sales
        //profit
//        for(Product p : allUserProducts) {
//        	for(Sales s : allUserSales) {
//        		if(p.getId() == s.getProduct().getId()) {
//        			
//        		}
//        	}
//        }
        
        for(Product p : allUserProducts) {
        	Integer totalProfit = sRepo.sumQuantities(p.getId());
        	System.out.println(totalProfit);
        	graphProfit.put(p.getName(), totalProfit);
        }
        
        for(Product p : allUserProducts) {
        	Integer totalProfit = sRepo.sumSales(p.getId());
        	graphSales.put(p.getName(), totalProfit);
        }
        
//        graphData.put("2016", 147);
//        graphData.put("2017", 1256);
//        graphData.put("2018", 3856);
//        graphData.put("2019", 19807);
        model.addAttribute("graphProfit", graphProfit);
        model.addAttribute("graphSales", graphSales);
        
        return "supplier/sales_modal";
    }
	
}
