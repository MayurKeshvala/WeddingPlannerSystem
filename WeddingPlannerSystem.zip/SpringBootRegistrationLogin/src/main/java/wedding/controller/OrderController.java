package wedding.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import wedding.model.CurrencySettingBag;
import wedding.model.Order;
import wedding.model.OrderDetail;
import wedding.model.Product;
import wedding.model.User;
import wedding.repo.UserRepository;
import wedding.service.OrderService;
import wedding.service.ReviewService;
import wedding.service.SettingService;
import wedding.utility.CustomUserDetails;

@Controller
public class OrderController {
	
	@Autowired 
	private OrderService oService;
	
	@Autowired 
	private ReviewService rService;
	
	@Autowired 
	private UserRepository uRepo;
	
	@Autowired 
	private SettingService setService;
	
	@GetMapping("/orders")
	public String listFirstPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		return listOrdersByPage(model, userDetails, request, 1, "orderTime", "desc", null);
	
	}
	
	@GetMapping("/orders/page_number/{pageNum}")
	public String listOrdersByPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request, @PathVariable(name = "pageNum") int pageNum, String sortChosenField, String sortDirection, String keyWord) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Page<Order> page = oService.listForuserByPage(user, pageNum, sortChosenField, sortDirection, keyWord);
		
		List<Order> listOrders = page.getContent();
		
		long startOfCount = (pageNum - 1) * OrderService.ORDERS_PER_PAGE + 1;
		

		
		long endOfCount = startOfCount + OrderService.ORDERS_PER_PAGE - 1;
		
		if (endOfCount > page.getTotalElements()) {
			
			endOfCount = page.getTotalElements();
			
		}
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		model.addAttribute("currency", currency);
		model.addAttribute("endOfCount", endOfCount);
		model.addAttribute("totalNumPages", page.getTotalPages());
		model.addAttribute("totalNumItems", page.getTotalElements());
		model.addAttribute("currentPageNumber", pageNum);
		model.addAttribute("listOrders", listOrders);
		model.addAttribute("sortChosenField", sortChosenField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("keyWord", keyWord);
		model.addAttribute("URL", "/orders");
		model.addAttribute("reverseSortDirection", sortDirection.equals("asc") ? "desc" : "asc");
		model.addAttribute("startOfCount", startOfCount);
				
		return "orders/orders_user";
		
	}

	@GetMapping("/orders/detail/{id}")
	public String viewOrderDetails(Model model,
			@PathVariable(name = "id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		Order order = oService.getOrder(id, user);
		
		setProductReviewableStatus(user, order);
		
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		model.addAttribute("currency", currency);
		model.addAttribute("order", order);
		
		return "orders/order_details_modal";
		
	}	
	
	private void setProductReviewableStatus(User user, Order order) {
		
		Iterator<OrderDetail> allOrderDetail = order.getOrderDetails().iterator();
		
		while(allOrderDetail.hasNext()) {
			
			OrderDetail orderDetail = allOrderDetail.next();
			
			Product product = orderDetail.getProduct();
			
			Integer productId = product.getId();
			
			boolean didUserReviewProduct = rService.diduserReviewProduct(user, productId);
			
			product.setReviewedByCustomer(didUserReviewProduct);
			
			if (!didUserReviewProduct) {
				
				boolean canUserReviewProduct = rService.canUserReviewProduct(user, productId);
				
				product.setCustomerCanReview(canUserReviewProduct);
				
			}
			
		}
		
	}
	
}
