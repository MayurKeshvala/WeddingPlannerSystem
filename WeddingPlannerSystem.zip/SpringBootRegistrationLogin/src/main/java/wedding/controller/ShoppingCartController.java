package wedding.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.CurrencySettingBag;
import wedding.model.User;
import wedding.repo.CategoryRepository;
import wedding.repo.UserRepository;
import wedding.service.SettingService;
import wedding.service.ShoppingCartService;
import wedding.utility.CustomUserDetails;


@Controller
public class ShoppingCartController {

	@Autowired 
	private ShoppingCartService cartService;

	@Autowired
	private UserRepository uRepo;
	
	@Autowired private CategoryRepository cRepo;
	
	@Autowired private SettingService setService;
	
	@GetMapping("/cart")
	public String viewCart(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		List<CartItem> cartItems = cartService.listCartItems(userDetails.getUserId());
		
		float estimatedTotal = 0.0F;
		
		for (CartItem item : cartItems) {
			
			if(item.getProduct().isService() == false) {
				
			estimatedTotal += item.getSubtotal();
			
			} else if(item.getProduct().isService() == true) {
				
				estimatedTotal += item.getProduct().getPrice();
				
			}
			
		}
		
		boolean useThePrimaryAddress = false;
		
		Iterable<Category> listCategory = cRepo.findAllByProduct();
		
		CurrencySettingBag currency = setService.getAllCurrencySettings();
		
		model.addAttribute("listCategory", listCategory);
		
		model.addAttribute("currency", currency);
		
		model.addAttribute("usePrimaryAddressAsDefault", useThePrimaryAddress);
		
		model.addAttribute("cartItems", cartItems);
		
		model.addAttribute("estimatedTotal", estimatedTotal);
		
		model.addAttribute("URL", "/customer_products");
		
		model.addAttribute("URL", "/customer_products");
		
		model.addAttribute("sortChosenField", "name");
		
		model.addAttribute("sortDirection", "asc");
		
		return "cart/shopping_cart";
	}
	
	@GetMapping("/account_details")
	public String viewUserAccountDetails(Model model, @AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		User user = uRepo.findUserById(userDetails.getUserId());

		model.addAttribute("user", user);

		return "customer/user_form";
		
	}
	
	

}
