package wedding.controller;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import wedding.exception.PayPalApiException;
import wedding.model.Address;
import wedding.model.CartItem;
import wedding.model.CheckoutInfo;
import wedding.model.CurrencySettingBag;
import wedding.model.EmailSettingBag;
import wedding.model.Order;
import wedding.model.PaymentMethod;
import wedding.model.PaymentSettingBag;
import wedding.model.Product;
import wedding.model.Sales;
import wedding.model.ShippingRate;
import wedding.model.User;
import wedding.repo.ProductRepository;
import wedding.repo.SalesRepository;
import wedding.repo.ShippingRateRepository;
import wedding.repo.UserRepository;
import wedding.service.AddressService;
import wedding.service.CheckoutService;
import wedding.service.OrderService;
import wedding.service.PayPalService;
import wedding.service.SettingService;
import wedding.service.ShippingRateService;
import wedding.service.ShoppingCartService;
import wedding.utility.CustomUserDetails;
import wedding.utility.Utility;

@Controller
public class CheckoutController {

	@Autowired private CheckoutService checkoutService;
	@Autowired private AddressService addressService;
	@Autowired private ShoppingCartService cartService;
	@Autowired private OrderService orderService;
	@Autowired private SettingService settingService;
	@Autowired private PayPalService paypalService;
	@Autowired private UserRepository uRepo;
	@Autowired private ShippingRateRepository sRepo;
	@Autowired private ShippingRateService srService;
	@Autowired private ProductRepository pRepo;
	@Autowired private SalesRepository salesRepo;
	
	@GetMapping("/checkout")
	public String showCheckoutPage(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		Integer user = userDetails.getUserId();
		
		User objectUser = uRepo.findUserById(userDetails.getUserId());
		
		List<CartItem> cartItems = cartService.listCartItems(user);
		
		Address defaultAddress = addressService.getDefaultAddress(user);
		
		ShippingRate shippingRate = null;
		
		float totalWeight = 0;
		
		int numberOfProducts = 0;
		
		Iterable<ShippingRate> overallshippingRate = sRepo.findAll();
		
		if (defaultAddress != null) {
			
			model.addAttribute("shippingAddress", defaultAddress.toString());
			
			
		}
			
			for(CartItem c : cartItems) {
				
				if(c.getProduct().isService() == true) {
					
					
					
					System.out.println(totalWeight);
					
				} else if(c.getProduct().isService() == false){
					
				Product product = c.getProduct();
				
				float maxWeight = Math.max(product.getDimWeight(), product.getWeight());
				
				totalWeight =+ (maxWeight * c.getQuantity());	
				
				System.out.println(totalWeight);
				
				numberOfProducts =+ 1;
				}
				
			}
			
			ShippingRate minWeight = sRepo.findShippingRateById(1);
			
			ShippingRate middleWeight = sRepo.findShippingRateById(2);
			
			ShippingRate maxWeight = sRepo.findShippingRateById(3);
			
			
			if(numberOfProducts >= 1) {
				if(totalWeight <= minWeight.getWeight()) {
					
					System.out.println(totalWeight + " less than or equal to " + minWeight.getWeight());
					shippingRate = minWeight;
				} else if(totalWeight <= middleWeight.getWeight()) {
					
					System.out.println(totalWeight + " less than or equal to " + middleWeight.getWeight());
					shippingRate = middleWeight;
				} else if(totalWeight <= maxWeight.getWeight()) {
					
					System.out.println(totalWeight + " less than or equal to " + maxWeight.getWeight());
					shippingRate = maxWeight;
				} else {
					
					System.out.println(totalWeight + " less than or equal to " + maxWeight.getWeight());
					shippingRate = maxWeight;
				}
			} 

		if(defaultAddress == null) {
			
			model.addAttribute("shippingAddress", objectUser.toString());
		}
			
//			for(CartItem c : cartItems) {
//				
//				if(c.getProduct().isService() == true) {
//					
//					totalWeight =+ 0;
//					
//				} else if(c.getProduct().isService() == false){
//					
//				Product product = c.getProduct();
//				
//				float maxWeight = Math.max(product.getDimWeight(), product.getWeight());
//				
//				totalWeight =+ (maxWeight * c.getQuantity());	
//				
//				}
//			
//			}
//			
//			for(ShippingRate s : overallshippingRate) {
//				
//				if (totalWeight <= s.getWeight()) {
//					
//					shippingRate = s;
//					
//					break;
//					
//				} else {
//					
//					ShippingRate ships = srService.getShippingRateById(3);
//					
//					shippingRate = ships;
//
//				}
//				
//			}
//
//		}
		
		
		CheckoutInfo checkoutInfo = checkoutService.prepareCheckout(cartItems, shippingRate);
		
		String currencyCode = settingService.getCurrencyCode();
		
		PaymentSettingBag paymentSettings = settingService.getAllPaymentSettings();
		
		String paypalClientId = paymentSettings.getClientID();
		
		CurrencySettingBag currency = settingService.getAllCurrencySettings();
	
		
		model.addAttribute("numberOfProducts", numberOfProducts);
		model.addAttribute("currency", currency);
		model.addAttribute("paypalClientId", paypalClientId);
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("checkoutInfo", checkoutInfo);
		model.addAttribute("currencyCode", currencyCode);
		model.addAttribute("shippingRates", overallshippingRate);
		model.addAttribute("totalWeight", totalWeight);
		model.addAttribute("user", objectUser);
		
		return "checkout/checkout";
	}
	
	@PostMapping("/place_order")
	public String placeOrder(HttpServletRequest request, @AuthenticationPrincipal CustomUserDetails userDetails) 
			throws UnsupportedEncodingException, MessagingException, ParseException {
		
		String paymentType = request.getParameter("paymentMethod");
		
		PaymentMethod paymentMethod = PaymentMethod.valueOf(paymentType);
		
		Integer user = userDetails.getUserId();
		
		User objectUser = uRepo.findUserById(userDetails.getUserId());
		
		List<CartItem> cartItems = cartService.listCartItems(user);
		
		Address defaultAddress = addressService.getDefaultAddress(user);
		
		ShippingRate shippingRate = null;
		
		float totalWeight = 0;
		
		Iterable<ShippingRate> overallshippingRate = sRepo.findAll();
		
			for(CartItem c : cartItems) {
				
				if(c.getProduct().isService() == false) {
					
				Product product = c.getProduct();
				
				float maxWeight = Math.max(product.getDimWeight(), product.getWeight());
				
				totalWeight =+ (maxWeight * c.getQuantity());
				
				Integer newQuantity = 0;
				
				Integer cartQuantity = c.getQuantity();
				
				Integer productQuantity = c.getProduct().getQuantity();
				
				newQuantity = productQuantity - cartQuantity;
				
				c.getProduct().setQuantity(newQuantity);
				
				if(newQuantity == 0) {
			   
					c.getProduct().setInStock(false);
				
				}

				sendSupplierNotification(c.getQuantity(), product, c.getSubtotal());
		
				pRepo.save(product);
		
				}
				
			}
		
			for(ShippingRate s : overallshippingRate) {
			
				if(totalWeight == 0) {
			
					shippingRate = null;
			
				} else if(totalWeight <= s.getWeight()) {
			
					shippingRate = s;
			
					break;
			
				} else if(totalWeight >= s.getWeight()){
			
					shippingRate = s;
				
					break;
					
				}
			
			}



		CheckoutInfo checkoutInfo = checkoutService.prepareCheckout(cartItems, shippingRate);
		
		Order createdOrder = orderService.createOrder(objectUser, defaultAddress, cartItems, paymentMethod, checkoutInfo);
		
		
		
		for(CartItem c : cartItems) {
			boolean ans = false;
			if(c.getProduct().isService() == true) {
				System.out.println("yayyyy");
				System.out.println(c.getDate());

				Date initDate = new SimpleDateFormat("yyyy/MM/dd").parse(c.getDate());
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				String parsedDate = formatter.format(initDate);
				
				
				List<String> copy = new ArrayList<>(c.getProduct().getDate());
			
				copy.remove(parsedDate);
				
				System.out.println(parsedDate);
				
				c.getProduct().setDate(copy);
		        
				pRepo.save(c.getProduct());
				ans = copy.isEmpty();
			}
				if (ans == true) {
		        
					c.getProduct().setInStock(false);
		        
					pRepo.save(c.getProduct());
				}
	;
				
			} 
		
		
		
		for(CartItem c : cartItems) {
			
		Sales sale = new Sales();
		
		sale.setLastSold(new Date());
		
		System.out.println(sale.getLastSold() + "YAAAAAAAAAAAAAAAY");
		
		sale.setProduct(c.getProduct());	
		
		System.out.println(sale.getProduct() + "YAAAAAAAAAAAAAAAY");
		
		sale.setUser(c.getProduct().getUser());
		
		System.out.println(sale.getUser() + "YAAAAAAAAAAAAAAAY");
		
		if(c.getProduct().isService() == false) {
		sale.setTotalSales(c.getQuantity());
		sale.setTotalProfit(c.getSubtotal());
		}
		if(c.getProduct().isService() == true) {
			sale.setTotalSales(1);
			
			System.out.println(sale.getTotalSales() + "YAAAAAAAAAAAAAAAY");
			
			sale.setTotalProfit(c.getProduct().getPrice() );
			
			System.out.println(sale.getTotalProfit() + "YAAAAAAAAAAAAAAAY");
		}

		
		Product product = c.getProduct();
		
		product.getSales().add(sale);
		salesRepo.save(sale);
		pRepo.save(product);
		}
		
//		List<Product> product = pRepo.findAllByUser(1);
//		
//		for(Product p : product) {
//			for(Sales s : p.getSales()) {
//				System.out.println(s.getProduct().getName());
//			}
//		}

		
		cartService.deleteByUser(user);
		
		sendOrderConfirmationEmail(request, createdOrder);
		

		
		return "checkout/order_completed";
		
	}

	private void sendSupplierNotification(Integer quantity, Product product, double subtotal) throws MessagingException, UnsupportedEncodingException {
		
		EmailSettingBag emailSettings = settingService.getAllEmailSettings();
		
		JavaMailSenderImpl sendMail = Utility.prepareMailSender(emailSettings);
		
		sendMail.setDefaultEncoding("utf-8");

		String toAddress = product.getUser().getEmail();
		
		String emailSubject = emailSettings.getSupplierConfirmationSubject();
		
		emailSubject = emailSubject.replace("[[name]]", product.getName());
		
		String contentOfEmail = emailSettings.getSupplierConfirmationContent();
		
		LocalDateTime currentDateTime = LocalDateTime.now();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss E, dd MMM yyyy");

		String formattedDateTime = currentDateTime.format(formatter);
		   
		MimeMessage message = sendMail.createMimeMessage();
		
		MimeMessageHelper mmHelper = new MimeMessageHelper(message);
		
		mmHelper.setFrom(emailSettings.getFromAddress(), emailSettings.getSenderName());
		
		mmHelper.setSubject(emailSubject);
		
		mmHelper.setTo(toAddress);
		
		CurrencySettingBag currencySettings = settingService.getAllCurrencySettings();
		
		String totalAmount = Utility.formatCurrency((float) subtotal, currencySettings);
		
		String strQuantity = quantity.toString();
		
		contentOfEmail = contentOfEmail.replace("[[quanitity]]",  strQuantity);
		
		contentOfEmail = contentOfEmail.replace("[[subtotal]]",  totalAmount);
			
		contentOfEmail = contentOfEmail.replace("[[name]]", product.getName());
		
		contentOfEmail = contentOfEmail.replace("[[orderTime]]", formattedDateTime);
		
		mmHelper.setText(contentOfEmail, true);
		
		sendMail.send(message);	
		
	}
	
	private void sendOrderConfirmationEmail(HttpServletRequest request, Order order) throws UnsupportedEncodingException, MessagingException {
		
		EmailSettingBag emailSettings = settingService.getAllEmailSettings();
		
		JavaMailSenderImpl sendMail = Utility.prepareMailSender(emailSettings);
		
		sendMail.setDefaultEncoding("utf-8");
		
		String toAddress = order.getuser().getEmail();
		
		String emailSubject = emailSettings.getOrderConfirmationSubject();
		
		String contentOfEmail = emailSettings.getOrderConfirmationContent();
		
		emailSubject = emailSubject.replace("[[orderId]]", String.valueOf(order.getOrderID()));
		
		MimeMessage message = sendMail.createMimeMessage();
		
		MimeMessageHelper mmHelper = new MimeMessageHelper(message);
		
		mmHelper.setFrom(emailSettings.getFromAddress(), emailSettings.getSenderName());
		
		mmHelper.setTo(toAddress);
		
		mmHelper.setSubject(emailSubject);
		
		DateFormat dateFormatter =  new SimpleDateFormat("HH:mm:ss E, dd MMM yyyy");
		
		String orderTime = dateFormatter.format(order.getOrderTime());
		
		CurrencySettingBag currencySettings = settingService.getAllCurrencySettings();
		
		String totalAmount = Utility.formatCurrency(order.getTotal(), currencySettings);
		
		contentOfEmail = contentOfEmail.replace("[[shippingAddress]]", order.getShippingAddress());
		
		contentOfEmail = contentOfEmail.replace("[[total]]", totalAmount);
		
		contentOfEmail = contentOfEmail.replace("[[paymentMethod]]", order.getPaymentMethod().toString());
		
		contentOfEmail = contentOfEmail.replace("[[name]]", order.getuser().getFullName());
		
		contentOfEmail = contentOfEmail.replace("[[orderId]]", String.valueOf(order.getOrderID()));
		
		contentOfEmail = contentOfEmail.replace("[[orderTime]]", orderTime);
		
		mmHelper.setText(contentOfEmail, true);
		
		sendMail.send(message);		
	
	}
	
	@PostMapping("/process_paypal_order")
	public String processPayPalOrder(HttpServletRequest request, @AuthenticationPrincipal CustomUserDetails userDetails, Model model) throws UnsupportedEncodingException, MessagingException, ParseException {
		String orderId = request.getParameter("orderId");
		
		String pageTitle = "Checkout Failure";
		
		String message = null;
		
		try {
			
			if (paypalService.validateOrder(orderId)) {
				
				return placeOrder(request, userDetails);
				
			} else {
				
				pageTitle = "Checkout Failure";
				
				message = "ERROR: your order information is incorrect, so your transaction has not gone through.";
			
			}
		} catch (PayPalApiException e) {
			
			message = "ERROR: there was a transaction failure: " + e.getMessage();
		
		}
		
		model.addAttribute("pageTitle", pageTitle);
		
		model.addAttribute("title", pageTitle);
		
		model.addAttribute("message", message);
		
		return "message";
		
	}
	
}
