package wedding.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import wedding.model.Address;
import wedding.model.User;
import wedding.repo.UserRepository;
import wedding.service.AddressService;
import wedding.utility.CustomUserDetails;

@Controller
public class AddressController {

	@Autowired
	private AddressService aService;

	@Autowired
	private UserRepository uRepo;

	//Show all user's addresses
	@GetMapping("/address")
	public String showAddresses(Model model, @AuthenticationPrincipal CustomUserDetails userDetails) {
		
		User user = uRepo.findUserById(userDetails.getUserId());
		
		List<Address> listAddress = aService.listAddressBook(userDetails.getUserId());

		boolean useDefault = true;
		
		for (Address address : listAddress) {
		
			if (address.isDefaultForShipping()) {
			
				useDefault = false;
				
				break;
			
			}
		
		}

		model.addAttribute("listAddress", listAddress);
		
		model.addAttribute("user", user);
		
		model.addAttribute("primaryAddressDefault", useDefault);

		return "address/addresses";
	}

	//Create a new address
	@GetMapping("/address/new")
	public String newAddress(Model model) {

		model.addAttribute("address", new Address());
		
		model.addAttribute("titlePage", "Add a new address");

		return "address/address_form";
	}

	//Save address
	@PostMapping("/address/save")
	public String saveAddress(Address address, HttpServletRequest request, @AuthenticationPrincipal CustomUserDetails userDetails, RedirectAttributes ra) {
		
		User user = uRepo.findUserById(userDetails.getUserId());

		address.setUser(user);
		
		aService.save(address);

//		String redirect = request.getParameter("redirect");
//		
//		String URL = "redirect:/address";
//
//		if ("checkout".equals(redirect)) {
//			URL += "?redirect=checkout";
//		}

		ra.addFlashAttribute("message", "The address has been saved successfully.");

		return "redirect:/address";
		
	}
	
	//Save primary address
	@PostMapping("/primary_address/save")
	public String savePrimaryAddress(User user, HttpServletRequest request, @AuthenticationPrincipal CustomUserDetails userDetails, RedirectAttributes ra) {
		
		User currentUser = uRepo.findUserById(userDetails.getUserId());
		
		currentUser.setFirstName(user.getFirstName());
		
		currentUser.setLastName(user.getLastName());
		
		currentUser.setPhoneNumber(user.getPhoneNumber());
		
		currentUser.setAddressLine(user.getAddressLine());
		
		currentUser.setCity(user.getCity());
		
		currentUser.setCountry(user.getCountry());
		
		currentUser.setPostalCode(user.getPostalCode());
		
		uRepo.save(currentUser);

		ra.addFlashAttribute("message", "The address has been saved successfully.");

		return "redirect:/address";
	}

	//Primary address form
	@GetMapping("/primary_address/edit")
	public String editPrimaryAddress(
			@AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {

		model.addAttribute("user", new User());

		model.addAttribute("titlePage", "Edit primary address");

		return "address/primary_address_form";
	}
	
	//Modify address - edit
	@GetMapping("/address/edit/{id}")
	public String editAddress(@PathVariable("id") Integer id,
			@AuthenticationPrincipal CustomUserDetails userDetails, Model model, HttpServletRequest request) {

		Address address = aService.get(id, userDetails.getUserId());

		model.addAttribute("address", address);

		model.addAttribute("titlePage", "Edit an address");

		return "address/address_form";
	}

	//Modify address - delete
	@GetMapping("/address/delete/{id}")
	public String deleteAddress(@PathVariable("id") Integer id, @AuthenticationPrincipal CustomUserDetails userDetails, RedirectAttributes ra, HttpServletRequest request) {

		aService.delete(id, userDetails.getUserId());

		ra.addFlashAttribute("message", "The address, with ID " + id + ", has been deleted.");

		return "redirect:/address";
	}

	//Set address to default
	@GetMapping("/address/default/{id}")
	public String setAddressDefault(@PathVariable("id") Integer id,
			@AuthenticationPrincipal CustomUserDetails userDetails, HttpServletRequest request) {
		
		aService.setDefaultAddress(id, userDetails.getUserId());

		String redirect = request.getParameter("redirect");
		
		String URL = "redirect:/address";

		if ("cart".equals(redirect)) {
			
			URL = "redirect:/cart";
			
		} else if ("checkout".equals(redirect)) {
			
			URL = "redirect:/checkout";
			
		}

		return URL;
	}
}
