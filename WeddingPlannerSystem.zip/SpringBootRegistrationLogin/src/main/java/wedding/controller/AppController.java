package wedding.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.List;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import wedding.model.Category;
import wedding.model.EmailSettingBag;
import wedding.model.GeoCoder;
import wedding.model.GeocodeResponse;
import wedding.model.Location;
import wedding.model.Roles;
import wedding.model.User;
import wedding.repo.CategoryRepository;
import wedding.repo.RolesRepository;
import wedding.repo.UserRepository;
import wedding.service.SettingService;
import wedding.service.UserService;
import wedding.utility.FileUploadUtil;
import wedding.utility.Utility;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private RolesRepository roleRepo;

	@Autowired
	private UserService service;

	@Autowired
	private CategoryRepository cRepo;
	
	@Autowired 
	private SettingService settingService;
	
	//Home page for customer, show all categories.
	@GetMapping("/customer")
	public String viewHomePage(Model model) {
		
		Iterable<Category> listCategories = cRepo.findAllEnabled();
		
		model.addAttribute("listCategories", listCategories);

		return "customer/index";
	}

	//Registration page.
	@RequestMapping("/register")
	public String showRegistrationForm(Model model) throws JsonSyntaxException, JsonIOException, MalformedURLException, IOException {

		//All selectable roles.
		List<Roles> listRoles = service.listRoles();
		
		Roles sNameRole = roleRepo.findByName("Supplier");
		Roles cNameRole = roleRepo.findByName("Customer");

		Integer sNameId = sNameRole.getId();
		Integer cNameId = cNameRole.getId();
		
		GeoCoder geo = new GeoCoder();
		
		Location leo = new Location();
		
		GeocodeResponse res = new GeocodeResponse();
		JsonParser parser = new JsonParser();
		
//		JsonObject rootObj = parser.parse(json).getAsJsonObject();
//		JsonObject locObj = rootObj.getAsJsonObject("result")
//		    .getAsJsonObject("geometry").getAsJsonObject("location");
//
//		String status = rootObj.get("status").getAsString();
//		String lat = locObj.get("lat").getAsString();
//		String lng = locObj.get("lng").getAsString();
//
//		System.out.printf("Status: %s, Latitude: %s, Longitude: %s\n", status,
//		        lat, lng);
				Gson gson = new Gson();
				
		
		res = geo.getLocation("LE49EF", "Leicester");
		
//		JSONObject objects = getArray.getJSONObject(i);
		
		String result = gson.toJson(res);
		
        JSONObject json = new JSONObject(result); 
        JSONArray jsonArray = json.getJSONArray("results");  
        
        JSONObject resultArray = jsonArray.getJSONObject(0).getJSONObject("geometry").getJSONObject("location");
//        String location = json.getString("lat");

        final int R = 6371;
        
        double userLng = ((BigDecimal) resultArray.get("lng")).doubleValue();
        
        double userLat = ((BigDecimal) resultArray.get("lat")).doubleValue();
        
        double venueLat = 52.04960140000001;
        
        double venueLng = -0.6841801;
        
        System.out.println(userLat);  
        
        System.out.println(resultArray.get("lng"));  
        
        System.out.println(resultArray.get("lat"));  
        
        Double latDistance = toRad(venueLat-userLat);
        Double lonDistance = toRad(venueLng-userLng);
        Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + 
        Math.cos(toRad(userLat)) * Math.cos(toRad(venueLat)) * 
        Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        Double distance = R * c;

//        distance = (distance/1.609)/100;
        
//        double latDistance = Math.toRadians(userLat - venueLat);
//        
//        double lngDistance = Math.toRadians(userLng - venueLng);
//        
//        double a = (Math.sin(latDistance / 2) * Math.sin(latDistance / 2)) +
//                        (Math.cos(Math.toRadians(userLat))) *
//                        (Math.cos(Math.toRadians(venueLat))) *
//                        (Math.sin(lngDistance / 2)) *
//                        (Math.sin(lngDistance / 2));
//
//        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//
//        double dist = 6371 * c;             
        

        
        
        System.out.println(distance);
        
//        System.out.println(c); 
//        
//        
//        System.out.println(dist); 
        
        if (distance<50){
            System.out.println("yayyyy"); 
            /* Include your code here to display your records */ 
        }
//        String ageJohn = json.getString("lat");
        
//        System.out.println(ageJohn);
//        for (Iterator key=name1.keys();key.hasNext();) {
//            JSONObject name = name1.get(key.next());
//            //now name contains the firstname, and so on... 
//        }
        
        for (int i = 0; i < jsonArray.length(); i++) {  
            
            // store each object in JSONObject  
            JSONObject explrObject = jsonArray.getJSONObject(i);  
              
            // get field value from JSONObject using get() method  
//            System.out.println(explrObject.get("address_components"));  
        }      
        
//	      System.out.println(result);
//	      String prettyJson = geo.toJson("LE14");
//	      System.out.println(prettyJson);
		

		
		model.addAttribute("listRoles", listRoles);
		model.addAttribute("sNameId", sNameId);
		model.addAttribute("sNameRole", sNameRole);
		model.addAttribute("cNameId", cNameId);
		model.addAttribute("cNameRole", cNameRole);
		model.addAttribute("user", new User());
		return "signup_form";
	}
	
	 private static Double toRad(Double value) {
		 return value * Math.PI / 180;
		 }

	@PostMapping("/process_register")
	public String processRegister(User user, @RequestParam("image") MultipartFile multiFile) throws IOException, MessagingException {
		
		//Password encryption
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);

		//Check if the image is empty
		if (!multiFile.isEmpty()) {

			//Name of the file
			String nameFile = StringUtils.cleanPath(multiFile.getOriginalFilename());
			
			user.setPhotos(nameFile);
			User savedUser = userRepo.save(user);

			//Where to save file
			String uploadDir = "user-photos/" + savedUser.getUserID();

			//Clean directory then save
			FileUploadUtil.cleanDirectory(uploadDir);
			FileUploadUtil.saveFile(uploadDir, nameFile, multiFile);

		} else {
			
			if (user.getPhotos().isEmpty())
				
				user.setPhotos(null);
			
			user.setEnabled(true);
			
			userRepo.save(user);
			
		}
		
		sendConfirmationEmail(user); 
		
		return "login";
	}
	

	private void sendConfirmationEmail(User user) 
			throws UnsupportedEncodingException, MessagingException {
		EmailSettingBag emailSettings = settingService.getAllEmailSettings();
		JavaMailSenderImpl mailSender = Utility.prepareMailSender(emailSettings);
		mailSender.setDefaultEncoding("utf-8");
		
		String toAddress = user.getEmail();
		String subject = emailSettings.getCustomerVerifySubject();
		String content = emailSettings.getCustomerVerifyContent();
		
		subject = subject.replace("[[name]]", user.getFullName());
		
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		
		helper.setFrom(emailSettings.getFromAddress(), emailSettings.getSenderName());
		helper.setTo(toAddress);
		helper.setSubject(subject);
		
		content = content.replace("[[name]]", user.getFullName());

		
		helper.setText(content, true);
		mailSender.send(message);		
	}

	@GetMapping("/")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("/logout")
	public String logout() {
		
		return "login";
	}
}
