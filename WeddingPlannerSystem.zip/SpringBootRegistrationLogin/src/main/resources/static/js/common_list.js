function clearKeywordFilter() {
	window.location = URL;	
}

function showDeleteConfirmModal(link, entityName) {

	entityId = link.attr("entityId");
	
	$("#yesButton").attr("href", link.attr("href"));	
	
	$("#confirmText").text("You are about to delete " + entityName + "with ID " + entityId);
	
	$("#confirmModal").modal();	
}