$(document).ready(function() {

	$(".linkMinus").on("click", function(evt) {
	
		evt.preventDefault();
		
		minusQuantity($(this));
		
	});
	
	$(".linkPlus").on("click", function(evt) {
	
		evt.preventDefault();
		
		plusQuantity($(this));
		
	});
	
	$(".linkRemove").on("click", function(evt) {
	
		evt.preventDefault();
		
		removeProduct($(this));
		
	});		
	
});

function minusQuantity(link) {

	productId = link.attr("pid");
	
	inputQuantity = $("#quantity" + productId);
	
	quantityChange = parseInt(inputQuantity.val()) - 1;
	
	if (quantityChange > 0) {
	
		inputQuantity.val(quantityChange);
		
		updateQuantity(productId, quantityChange);
		
	} else {
	
		showWarningModal('Minimum quantity is 1');
		
	}	
	
}

function plusQuantity(link) {

		productId = link.attr("pid");
		
		maxQuantity = link.attr("value");
		
		console.log(productId);
		
		inputQuantity = $("#quantity" + productId);
		
		quantityChange = parseInt(inputQuantity.val()) + 1;
		
		if (quantityChange <= maxQuantity) {
		
			inputQuantity.val(quantityChange);
			
			updateQuantity(productId, quantityChange);
			
		} else {
		
			showWarningModal('Maximum quantity is ' + maxQuantity);
		
		}	

}

function updateQuantity(productId, quantity) {

	url = contextPath + "cart/update/" + productId + "/" + quantity;
	
	$.ajax({
	
		type: "POST",
		
		url: url
		
	}).done(function(newSubtotal) {
	
		updateSubtotal(newSubtotal, productId);
		
		newTotal();
		
	}).fail(function() {
	
		showErrorModal("Error while updating product quantity.");
	
	});	
	
}

function updateSubtotal(newSubtotal, productId) {

	formattedSubtotal = $.number(newSubtotal, decimalDigits);
	
	if(symbolPosition == 'before'){
	
	$("#subtotal" + productId).text(priceSymbol + " " + formattedSubtotal);
	
	}
	
	if(symbolPosition == 'after'){
	
	$("#subtotal" + productId).text(formattedSubtotal + " " + priceSymbol);
	
	}

}

function newTotal() {

	total = 0.0;
	
	productCount = 0;
	
	$(".subtotal").each(function(index, element) {
	
		productCount++;
		
		total += parseFloat(element.innerHTML.replaceAll(",", ""));
	
	});
	
	if (productCount < 1) {
	
		showEmptyShoppingCart();
		
	} else {
	
		formattedTotal = $.number(total, decimalDigits);
		
		if(symbolPosition == 'before'){
		
		$("#total").text(priceSymbol + formattedTotal);	
			
		}
		
		
	if(symbolPosition == 'after'){
	
	$("#subtotal" + productId).text(formattedSubtotal + " " + priceSymbol);
	
	}
	
	}
	
}

function showEmptyShoppingCart() {

	$("#sectionTotal").hide();
	
	$("#sectionEmptyCartMessage").removeClass("d-none");
	
}

function removeProduct(link) {

	url = link.attr("href");

	$.ajax({
	
		type: "DELETE",
		
		url: url
		
	}).done(function(response) {
	
		rowNumber = link.attr("rowNumber");
		
		removeProductHTML(rowNumber);
		
		newTotal();
		
		updateCountNumbers();
		
		showModalDialog("Shopping Cart", response);
		
	}).fail(function() {
	
		showErrorModal("Error while removing product.");
		
	});				
	
}

function removeProductHTML(rowNumber) {

	$("#row" + rowNumber).remove();
	
	$("#blankLine" + rowNumber).remove();
	
}

function updateCountNumbers() {

	$(".divCount").each(function(index, element) {
	
		element.innerHTML = "" + (index + 1);
		
	}); 
	
}