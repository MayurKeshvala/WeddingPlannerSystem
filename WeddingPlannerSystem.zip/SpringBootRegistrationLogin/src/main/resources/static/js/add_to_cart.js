$(document).ready(function() {

	$("#buttonAdd2Cart").on("click", function(evt) {
	
		addToCart();
		
	});
	
});




$(document).ready(function() {

	$("#buttonAddServiceCart").on("click", function(evt) {
	
		addServiceToCart();
		
	});
	
});




function addToCart() {

	quantity = $("#quantity" + productId).val();
	
	url = contextPath + "cart/add/" + productId + "/" + quantity;
	
	$.ajax({
	
		type: "POST",
		
		url: url
		
	}).done(function(response) {
	
		showModalDialog("Shopping Cart", response);
		
	}).fail(function() {
	
		showErrorModal("Error while adding product to shopping cart.");
	
	});
	
}




function addServiceToCart() {

var e = document.getElementById("allDates");

var date = e.options[e.selectedIndex].text;

const newUrl = date.replace(/\//g, '-');

	url = contextPath + "cart/addService/" + productId + "/" + newUrl;
	
	$.ajax({
	
		type: "POST",
		
		url: url
		
	}).done(function(response) {
	
		showModalDialog("Shopping Cart", response);
		
	}).fail(function() {
	
		showErrorModal("Error whilst attempting to add to shopping cart.");
	
	});
	
}