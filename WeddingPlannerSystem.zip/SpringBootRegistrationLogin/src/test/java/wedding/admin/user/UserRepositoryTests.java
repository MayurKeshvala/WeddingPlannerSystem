package wedding.admin.user;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.annotation.Rollback;



import wedding.model.Roles;
import wedding.model.User;
import wedding.repo.RolesRepository;
import wedding.repo.UserRepository;

@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {
	@Autowired
	private UserRepository repo;
	
	@Autowired 
	private RolesRepository roleRepo;
	
	@Autowired
	private TestEntityManager entityManager;
	
	
	
	@Test
	public void testCreateNewUserWithOneRole() {
		Roles admin = new Roles("Admin");
		
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setPassword("password");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		assertThat(savedUser.getUserID()).isGreaterThan(0);
	}
	
	@Test
	public void testCreateNewUserWithTwoRoles() {
		Roles admin = new Roles("Admin");
		
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setPassword("password");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		newUser.addRole(admin);
		newUser.addRole(supplier);
		
		User savedUser = repo.save(newUser);
		
		assertThat(savedUser.getUserID()).isGreaterThan(1);
	}
	
	@Test
	public void testListAllUsers() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setCity("London");
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");

		User newUser2 = new User();
		newUser2.setCity("Leicester");
		newUser2.setFirstName("Sarah");
		newUser2.setLastName("Jane");
		newUser2.setAddressLine("Micheal");
		newUser2.setPhoneNumber("07395827492");
		newUser2.addRole(supplier);
		newUser2.setPassword("password");
		newUser2.setPostalCode("LE4 7JK");
		newUser2.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		User savedUser2 = repo.save(newUser2);
		
		Iterable<User> listUsers = repo.findAll();
		listUsers.forEach(user -> System.out.println(user));
	}
	
	@Test
	public void testGetUserById() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		User findUser = repo.findById(1).get();
		System.out.println(findUser);
		assertThat(findUser).isNotNull();
	}
	
	@Test
	public void testUpdateUserDetails() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		User findUser = repo.findById(1).get();
		findUser.setEnabled(true);
		findUser.setEmail("findUser@hotmail.co.uk");
		
		repo.save(findUser);
	}
	
	@Test
	public void testUpdateUserRoles() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		User findUser = repo.findById(1).get();
		
		findUser.getRoles().remove(admin);
		findUser.addRole(supplier);
		
		repo.save(findUser);
	}
	
	@Test
	public void testDeleteUser() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		Integer userId = 1;
		repo.deleteById(userId);
		
	}
	
	@Test
	public void testGetUserByEmail() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		String email = "Wedding@hotmail.co.uk";
		User user = repo.getUserByEmail(email);
		
		assertThat(user).isNotNull();
	}
	
	@Test
	public void testCountById() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		Integer id = 1;
		Long countById = repo.countByuserID(id);
		
		assertThat(countById).isNotNull().isGreaterThan(0);
	}
	
	@Test
	public void testDisableUser() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		Integer id = 1;
		repo.updateEnabledStatus(id, false);
		
	}
	
	@Test
	public void testEnableUser() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		
		Integer id = 1;
		repo.updateEnabledStatus(id, true);
		
	}	
	
	@Test
	public void testListFirstPage() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		int pageNumber = 0;
		
		int pageSize = 1;
		
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		
		Page<User> page = repo.findAll(pageable);
		
		List<User> listUsers = page.getContent();
		
		listUsers.forEach(user -> System.out.println(user));
		
		assertThat(listUsers.size()).isEqualTo(pageSize);
	}
	
	@Test
	public void testSearchUsers() {
		Roles admin = new Roles("Admin");
		Roles supplier = new Roles("Supplier");
		Roles customer = new Roles("Customer");
		
		roleRepo.saveAll(List.of(admin, supplier, customer));
		
		User newUser = new User();
		newUser.setFirstName("Dan");
		newUser.setLastName("Schneider");
		newUser.setAddressLine("01 Pho Road");
		newUser.setPhoneNumber("079384754832");
		newUser.addRole(admin);
		newUser.setCity("London");
		newUser.setPassword("password");
		newUser.setPostalCode("LE7 9LO");
		newUser.setEmail("Wedding@hotmail.co.uk");
		
		User savedUser = repo.save(newUser);
		
		String keyword = "Davidson";
	
		int pageNumber = 0;
		int pageSize = 4;
		
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		
		Page<User> page = repo.findAll(keyword, pageable);
		
		List<User> listUsers = page.getContent();
		
		listUsers.forEach(user -> System.out.println(user));	
		
		assertThat(listUsers.size()).isGreaterThan(0);
	}
}
