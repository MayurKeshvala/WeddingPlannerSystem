package wedding.category;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import wedding.model.CartItem;
import wedding.model.Category;
import wedding.model.OrderDetail;
import wedding.model.Product;
import wedding.model.Category;

import wedding.model.Question;
import wedding.model.Review;
import wedding.model.Roles;
import wedding.model.Sales;
import wedding.repo.CartItemRepository;
import wedding.repo.CategoryRepository;
import wedding.repo.OrderDetailRepository;
import wedding.repo.ProductRepository;
import wedding.repo.QuestionRepository;
import wedding.repo.ReviewRepository;
import wedding.repo.SalesRepository;


@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class ProductTest {


	
	@Autowired
	private TestEntityManager entityManager;
	


	@Autowired private CategoryRepository cRepo;

	@Autowired private OrderDetailRepository oRepo;
	@Autowired private CartItemRepository cartRepo;
	@Autowired private ReviewRepository rRepo;
	@Autowired private QuestionRepository qRepo;
	@Autowired private SalesRepository sRepo;
	@Autowired private ProductRepository pRepo;
	



	
	@Test
	public void testCreateCategory() {


		
		Category category = new Category();
		category.setName(null);
		category.setEnabled(true);
		category.setPhotos("cat.jpg");
		category.setService(false);
		
		Category savedCategory = cRepo.save(category);
		
		assertThat(savedCategory).isNotNull();
		assertThat(savedCategory.getId()).isGreaterThan(0);
	}
	
	@Test
	public void testListAllCategory() {
		Iterable<Category> iterableCategory = cRepo.findAll();
		
		iterableCategory.forEach(System.out::println);
	}
	
	@Test
	public void testGetCategory() {
		Integer id = 1;
		Category category = cRepo.findById(id).get();
		System.out.println(category);
		
		assertThat(category).isNotNull();
	}
	
	@Test
	public void testUpdateCategory() {
		Integer id = 1;
		Category category = cRepo.findById(id).get();
		category.setName("Tables");
		
		cRepo.save(category);
		
		Category updatedProduct = entityManager.find(Category.class, id);
		
		assertThat(updatedProduct.getName()).isEqualTo("Tables");
	}
	
	@Test
	public void testDeleteCategory(){
		Integer id = 1;

		Category category = cRepo.findCategoryById(id);
	
List <Product> listProduct = pRepo.findProductByCategory(id);
		
		List <Review> reviews = rRepo.findAllReviewByReviewId(id);
	
		List <OrderDetail> order = oRepo.findAllOrderDetailByProduct(id);
		
		List <CartItem> cartItem = cartRepo.findAllCartItemByProductId(id);
		
		List <Question> questions = qRepo.findAllQuestionByProductId(id);
		
		List <Sales> sales = sRepo.findAllSalesByProductId(id);
		
		for(Product product : listProduct) {
		
		for(OrderDetail o : order) {
			if(o.getProduct() == product) {
				o.setProduct(null);
				oRepo.save(o);
			}
		}
		
		
		
		for(CartItem c : cartItem) {
			if(c.getProduct() == product) {
				c.setProduct(null);
				cartRepo.save(c);
			}
		}
		
	
		
		for(Review r : reviews) {
			if(r.getProduct() == product) {
				r.setProduct(null);
				rRepo.save(r);
			}
		}
		
	
		
		for(Question q : questions) {
			if(q.getProduct() == product) {
				q.setProduct(null);
				qRepo.save(q);
			}
		}
			
		for(Sales s : sales) {
			if(s.getProduct() == product) {
				s.setProduct(null);
				sRepo.save(s);
				}
		}
		
		product.setCategory(null);
		pRepo.save(product);
		}
		
		
		
		
		cRepo.delete(category);
		
			cRepo.delete(category);
		
		Optional<Category> result = cRepo.findById(id);
		
		assertThat(!result.isPresent());
	}
	
	

}
