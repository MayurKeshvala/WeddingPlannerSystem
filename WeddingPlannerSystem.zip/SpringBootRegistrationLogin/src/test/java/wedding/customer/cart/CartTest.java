package wedding.customer.cart;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.annotation.Rollback;

import wedding.model.CartItem;
import wedding.model.Product;
import wedding.model.Roles;
import wedding.model.User;
import wedding.repo.CartItemRepository;
import wedding.repo.RolesRepository;
import wedding.repo.UserRepository;

@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class CartTest {
	@Autowired private CartItemRepository repo;
	@Autowired private TestEntityManager entityManager;
	
	@Test
	public void testSaveItem() {
		Integer userId = 2;
		Integer productId = 1;
		
		User user = entityManager.find(User.class, userId);
		Product product = entityManager.find(Product.class, productId);
		
		CartItem newItem = new CartItem();
		newItem.setUser(user);
		newItem.setProduct(product);
		newItem.setQuantity(1);
		
		CartItem savedItem = repo.save(newItem);
		
		assertThat(savedItem.getId()).isGreaterThan(0);
	}
	
	@Test
	public void testSave2Items() {
		Integer userId = 2;
		Integer productId = 1;
		
		User user = entityManager.find(User.class, userId);
		Product product = entityManager.find(Product.class, productId);
		
		CartItem item1 = new CartItem();
		item1.setUser(user);
		item1.setProduct(product);
		item1.setQuantity(2);
		
		CartItem item2 = new CartItem();
		item2.setUser(new User(userId));
		item2.setProduct(new Product(2));
		item2.setQuantity(3);
		
		Iterable<CartItem> iterable = repo.saveAll(List.of(item1, item2));
		
		assertThat(iterable).size().isGreaterThan(0);
	}
	
	@Test
	public void testFindByCustomer() {
		Integer userId = 2;
		List<CartItem> listItems = repo.findAllCartItemById(userId);
		
		listItems.forEach(System.out::println);
		
		assertThat(listItems.size()).isEqualTo(2);
	}
	
	@Test
	public void testFindByCustomerAndProduct() {
		Integer userId = 2;
		Integer productId = 1;
		
		CartItem item = repo.findByUserAndProduct(new User(userId), new Product(productId));
		
		assertThat(item).isNotNull();
		
		System.out.println(item);
	}
	
	@Test
	public void testUpdateQuantity() {
		Integer userId = 2;
		Integer productId = 1;
		Integer quantity = 4;
		
		repo.updateQuantity(quantity, userId, productId);
		
		CartItem item = repo.findByUserAndProduct(new User(userId), new Product(productId));
		
		assertThat(item.getQuantity()).isEqualTo(4);
	}
	
	@Test
	public void testDeleteByCustomerAndProduct() {
		Integer userId = 2;
		Integer productId = 1;
		
		repo.deleteByUserAndProduct(userId, productId);
		
		CartItem item = repo.findByUserAndProduct(new User(userId), new Product(productId));
		
		assertThat(item).isNull();
	}
}
