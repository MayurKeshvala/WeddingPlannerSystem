package wedding.customer.registration;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.test.annotation.Rollback;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import wedding.model.Address;
import wedding.model.PayPalOrderResponse;
import wedding.model.User;
import wedding.repo.AddressRepository;


@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class RegistrationTest {
	@Autowired private AddressRepository repo;
	
	@Test
	public void testAddNew() {
		Integer customerId = 1;

		
		Address newAddress = new Address();
		newAddress.setUser(new User(customerId));
		newAddress.setFirstName("Tobie");
		newAddress.setLastName("Abel");
		newAddress.setPhoneNumber("19094644165");
		newAddress.setAddressLine("4213 Gordon Street");
		newAddress.setCity("Chino");
		newAddress.setCountry("United Kingdom");
		newAddress.setPostalCode("91710");
		
		Address savedAddress = repo.save(newAddress);
		
		assertThat(savedAddress).isNotNull();
		assertThat(savedAddress.getId()).isGreaterThan(0);
	}
	
	@Test
	public void testFindByUser() {
		Integer userId = 1;
		List<Address> listAddresses = repo.findAllAddressById(userId);
		assertThat(listAddresses.size()).isGreaterThan(0);
		
		listAddresses.forEach(System.out::println);
	}
	
	@Test
	public void testFindByIdAndUser() {
		Integer addressId = 1;
		Integer customerId = 1;
		
		Address address = repo.findByIdAnduser(addressId, customerId);
		
		assertThat(address).isNotNull();
		System.out.println(address);
	}
	
	@Test
	public void testUpdate() {
		Integer addressId = 1;
		String phoneNumber = "646-232-3932";
		
		Address address = repo.findById(addressId).get();
		address.setPhoneNumber(phoneNumber);

		Address updatedAddress = repo.save(address);
		assertThat(updatedAddress.getPhoneNumber()).isEqualTo(phoneNumber);
	}
	
	@Test
	public void testDeleteByIdAndUser() {
		Integer addressId = 1;
		Integer customerId = 1;
		
		repo.deleteByIdAnduser(addressId, customerId);
		
		Address address = repo.findByIdAnduser(addressId, customerId);
		assertThat(address).isNull();
	}	
	
	@Test
	public void testSetDefault() {
		Integer addressId = 1;
		repo.setDefaultAddress(addressId);
		
		Address address = repo.findById(addressId).get();
		assertThat(address.isDefaultForShipping()).isTrue();
	}
	
	@Test
	public void testSetNonDefaultAddresses() {
		Integer addressId = 1;
		Integer customerId = 1;
		repo.setNonDefaultForOthers(addressId, customerId);			
	}
	
	@Test
	public void testGetDefault() {
		Integer customerId = 1;
		Address address = repo.findDefaultByuser(customerId);
		assertThat(address).isNotNull();
		System.out.println(address);
	}
	
}
