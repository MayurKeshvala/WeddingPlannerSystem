package wedding.customer.review;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.test.annotation.Rollback;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import wedding.model.Address;
import wedding.model.PayPalOrderResponse;
import wedding.model.Product;
import wedding.model.Review;
import wedding.model.User;
import wedding.repo.AddressRepository;
import wedding.repo.ReviewRepository;


@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class RegistrationTest {
	@Autowired private ReviewRepository repo;
	
	@Test
	@Order(5)  
	public void testCreateReview() {
		Integer productId = 1;
		Product product = new Product(productId);
		
		Integer customerId = 1;
		User customer = new User(customerId);
		
		Review review = new Review();
		review.setProduct(product);
		review.setUser(customer);
		review.setReviewTime(new Date());
		review.setHeadline("Perfect for my needs. Loving it!");
		review.setComment("Nice to have: wireless remote, iOS app, GPS...");
		review.setRating(5);
		
		Review savedReview = repo.save(review);
		
		assertThat(savedReview).isNotNull();
		assertThat(savedReview.getId()).isGreaterThan(0);		
	}
	
	@Test
	 @Order(4)  
	public void testListReviews() {
		List<Review> listReviews = repo.findAll();
		
		assertThat(listReviews.size()).isGreaterThan(0);
		
		listReviews.forEach(System.out::println);
	}
	
	@Test
	 @Order(3)  
	public void testGetReview() {
		Integer id = 1;
		Review review = repo.findById(id).get();
		
		assertThat(review).isNotNull();
		
		System.out.println(review);
	}
	
	@Test
	 @Order(2)  
	public void testUpdateReview() {
		Integer id = 1;
		String headline = "An awesome camera at an awesome price";
		String comment = "Overall great camera and is highly capable...";
		
		Review review = repo.findById(id).get();
		review.setHeadline(headline);
		review.setComment(comment);
		
		Review updatedReview = repo.save(review);
		
		assertThat(updatedReview.getHeadline()).isEqualTo(headline);
		assertThat(updatedReview.getComment()).isEqualTo(comment);
	}
	
	@Test
	 @Order(1) 
	public void testDeleteReview() {
		Integer id = 1;
		repo.deleteById(id);
		
		Optional<Review> findById = repo.findById(id);
		
		assertThat(findById).isNotPresent();
	}
	
}
